<?php include('header.php'); 


if ( isset($_GET['del'])) {
	
	$del_id = intval($_GET['del']);
	$this_conv = get_conversation_info($del_id);
	
	if (isset($this_conv['id'])) {

		delete_messages($this_conv['id'],'conv_id');
	
		$delete = mysql_query("DELETE FROM `conversations` WHERE `id` = " . $this_conv['id']);
		if ($delete) {
			$message = "Conversation Deleted!";
		} else {
			$error[] = "Error: " . mysql_error();
		}
	
	}
	
}
?>
<h2 class="main_title">Manage Users</h2>

<div class="box">
	
    <div class="left sort_links">
    <a href="conversations.php">All <span>(<?php echo count_all_orders('','',true); ?>)</span></a> | 
    <a href="conversations.php?search_by=status&search_term=Active">Active <span>(<?php echo count_all_orders('status','Active'); ?>)</span></a> | 
    <a href="conversations.php?search_by=status&search_term=Pending">Pending <span>(<?php echo count_all_orders('status','Active'); ?>)</span></a> | 
    <a href="conversations.php?search_by=status&search_term=Cancelled">Cancelled <span>(<?php echo count_all_orders('status','Cancelled'); ?>)</span></a>
    </div>
    <div class="right">
    <form action="conversations.php" method="get">
    <?php
		if ( isset($_GET['search_by']) && ( $_GET['search_by'] == 'username' || $_GET['search_by'] == 'email')  ) {
			$search_value = $_GET['search_term'];
		} else {
			$search_value = '';
		}
		
	?>
    <input type="text" name="search_term" value="<?php echo $search_value; ?>">
    <select name="search_by" style="width:140px">
    	<option value="number">Order Number</option>
        <option value="seller_id">Seller</option>
        <option value="buyer_id">Buyer</option>
    </select>
    <input type="submit" value="Search">
    </form>
    </div>
    <div class="clear"></div>
</div><!-- .box -->



<?php

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = $set['per_page'];
	$startpoint = ($page * $limit) - $limit;
 	
	if (isset($_GET['sort_by'])) $sort_by = mres($_GET['sort_by']); else  $sort_by = "id";
	if (isset($_GET['sort'])) $sort = mres($_GET['sort']); else  $sort = "DESC";
	
	if (isset($_GET['search_by']) && isset($_GET['search_term'])) {
		
		$statement = "`conversations` WHERE `".mres($_GET['search_by'])."` = '".mres($_GET['search_term'])."' ORDER BY `updated` DESC";
	} else {
		$statement = "`conversations` ORDER BY `updated` DESC";
	}
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	confirm_query($result);
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['sort']))
		$url .= 'sort='. $_GET['sort']. '&';
	if (isset($_GET['sort_by']))
		$url .= 'sort_by='. $_GET['sort_by']. '&';
	if (isset($_GET['search_term']) && isset($_GET['search_by']))
		$url .= 'search_by='. $_GET['search_by']. '&search_term='. $_GET['search_term'].'&';
		
	echo pagination($statement,$limit,$page, $url);
	
 ?>

<div class="wrap_box">

<?php display_error(); display_message(); ?>

	<?php if ($result_count !=0) { ?>
    <table class="form_table">
    	<tr class="head">
        	<td>Conversation</td>
            <td width="150">To User</td>
            <td width="150">From user</td>
            <td class="100">Updated</td>
            <td width="90"></td>
    	</tr>
        <?php
			 $count = 0;
		 	while($row = mysql_fetch_array($result)) : ?>
        <tr class="<?php if($count%2) echo "odd"; else echo "even" ?>">
        	<td><a href="view-messages.php?id=<?php echo $row['id']; ?>">View Conversations</a></td>
            <td>
            <?php $buyer = get_user_info($row['to_id']); ?>
			<?php the_flag($buyer['last_ip'],1); ?>&nbsp;<a href="edit_user.php?id=<?php echo $buyer['id']; ?>"><?php echo $buyer['username']; ?></a></td> 
            <td>
			<?php $seller = get_user_info($row['from_id']); ?>
			<?php the_flag($seller['last_ip'],1); ?>&nbsp;<a href="edit_user.php?id=<?php echo $seller['id']; ?>"><?php echo $seller['username']; ?></a></td>
            <td><?php datetime($row['datetime']); ?></td>
            <td><a href="vew-messages.php?id=<?php echo $row['id']; ?>">Edit</a> | <a href="conversations.php?del=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to deelte?')" class="del_link">Delete</a></td>
        </tr>
        <?php
		 $count++;
		 endwhile;
		 ?>
    </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->

<?php echo pagination($statement,$limit,$page, $url); ?>

<?php include('footer.php'); ?>



