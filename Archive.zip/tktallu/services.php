<?php 
include('header.php'); 

if (isset($_GET['approve'])) {
	$id = intval($_GET['approve']);
	$approve = mysql_query("UPDATE `services` SET `status` = 'Active' WHERE `id` = ".$id);
	if ($approve) {
		$message = "Service Approved!";
		
		$this_service = get_service_info($id);
		$this_user = get_user_info($this_service['user_id']);
		
		$noti_desc = 'Cngrats! Your service "'.$this_service['title'].'" has been approved and live now!';
  	    $noti_url = service_permalink($this_service['id']);
  	    $to_id = $this_user['id'];
  	    add_noti($noti_desc,$to_id,$noti_url,'Service Approved!');
		
	} else {
		$error[] = "Error updating service:" . mysql_error();
	}
}

if (isset($_GET['disapprove'])) {
	$id = intval($_GET['disapprove']);
	$approve = mysql_query("UPDATE `services` SET `status` = 'Pending' WHERE `id` = ".$id);
	if ($approve)
		$message = "Service Disapproved!";
	else
		$error[] = "Error updating service:" . mysql_error();
}

?>

<h2 class="main_title">Services</h2>

<div class="box">
	
    <div class="left sort_links">
    <a href="services.php">All <span>(<?php echo count_all_services('','',true); ?>)</span></a> | 
    <a href="services.php?search_by=status&search_term=Active">Active <span>(<?php echo count_all_services('status','Active'); ?>)</span></a> | 
    <a href="services.php?search_by=status&search_term=Pending">Pending <span>(<?php echo count_all_services('status','Pending'); ?>)</span></a> | 
    <a href="services.php?search_by=status&search_term=Paused">Paused <span>(<?php echo count_all_services('status','Paused'); ?>)</span></a> | 
    <a href="services.php?search_by=status&search_term=Requires-Modefication">Requires Modification <span>(<?php echo count_all_services('status','Requires Modification'); ?>)</span></a> | 
    </div>
    <div class="right">
    <form action="services.php" method="get">
    <input type="text" name="search_query" value="<?php if (isset($_GET['search_query'])) echo $_GET['search_query']; ?>">
    <input type="submit" value="Search">
    </form>
    </div>
    <div class="clear"></div>
</div><!-- .box -->

<?php

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;
 	
	if (isset($_GET['sort_by'])) $sort_by = mres($_GET['sort_by']); else  $sort_by = "id";
	if (isset($_GET['sort'])) $sort = mres($_GET['sort']); else  $sort = "DESC";
	
	if (isset($_GET['search_by']) && isset($_GET['search_term'])) {
		$statement = "`services` WHERE `".mres($_GET['search_by'])."` = '".mres($_GET['search_term'])."' ORDER BY `".$sort_by."` ".$sort;
	} else {
		$statement = "`services` ORDER BY `".$sort_by."` ".$sort;
	}
	
	if (isset($_GET['search_query'])) {
		$statement = "`services` WHERE `title` LIKE '%".mres($_GET['search_query'])."%' ORDER BY `".$sort_by."` ".$sort;
	}
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['user_id']))
		$url .= 'user_id='. $_GET['user_id']. '&';
	if (isset($_GET['sort']))
		$url .= 'sort='. $_GET['sort']. '&';
	if (isset($_GET['sort_by']))
		$url .= 'sort_by='. $_GET['sort_by']. '&';
	if (isset($_GET['search_term']) && isset($_GET['search_by']))
		$url .= 'search_by='. $_GET['search_by']. '&search_term='. $_GET['search_term'].'&';
		
	if (isset($_GET['search_query']))
		$url = '?search_query='. $_GET['search_query']. '&';
	echo pagination($statement,$limit,$page, $url);
	
 ?>

<div class="wrap_box">

<?php display_error(); display_message(); ?>


	<?php if ($result_count !=0) { ?>
    <table class="form_table">
        	<tr class="head">
            	<td width="40">ID</td>
                <td width="350">Title</td>
        		<td width="40" class="aligncenter">Price</td>
                <td width="40" class="aligncenter">Sales</td>
                <td width="150">User</td>
                <td width="250">Category</td>
                <td width="100">Status</td>
                <td width="150">Added</td>
                <td></td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
				$service_user = get_user_info($row['user_id']);
			?>
            <tr class="<?php if($count%2) echo "even"; else echo "odd"; if ($row['status'] != 'Active') echo " pending"; ?>">
            	<td><?php echo $row['id']; ?></td>
                <td class="alignleft">
                <?php 
				if ($row['status'] != 'Active') {
					echo $row['title'];
				} else {
					echo "<a href='".service_permalink($row['id'])."'>".$row['title']."<a/>";
				}
					 ?>
                </td>
                <td class="aligncenter"><strong>$<?php echo $row['price']; ?></strong></td>
                <td class="aligncenter"><strong><?php echo $row['sales']; ?></strong></td>
                <td><a href="edit_user.php?id=<?php echo $service_user['id']; ?>"><strong><?php echo $service_user['username']; ?></strong></a> - 
                <a href="services.php?user_id=<?php echo $service_user['id']; ?>"><small>View All</small></a></td>
                <td><?php the_category($row); ?></td>
                <td><?php echo $row['status']; ?></td>
                <td><?php datetime($row['datetime']); ?></td>
                <td>
                <?php if ($row['status'] == 'Active') { ?>
                	<a href="services.php?disapprove=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to disapprove?');">Disapprove</a>
                <?php } else { ?>
                	<a href="services.php?approve=<?php echo $row['id']; ?>">Approve</a>
                <?php } ?> | 
                <a href="edit-service.php?id=<?php echo $row['id']; ?>" class="del_link">Edit</a></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->
<?php echo pagination($statement,$limit,$page, $url); ?>
<?php include('footer.php'); ?>