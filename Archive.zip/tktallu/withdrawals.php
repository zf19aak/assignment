<?php include('header.php'); ?>
<?php

if (isset($_GET['view_json'])) {
	
	$pay_id = intval($_GET['view_json']);
	$get_result = mysql_query("SELECT * FROM `withdrawals` WHERE `id` = " . $pay_id);
	$get_row = mysql_fetch_array($get_result);
	
	$response_json = $get_row['response_json'];
	
}

if (isset($_GET['simple_pay'])) {
	$pay_id = intval($_GET['simple_pay']);
	$get_result = mysql_query("SELECT * FROM `withdrawals` WHERE `id` = " . $pay_id);
	$get_row = mysql_fetch_array($get_result);
	$pay_amount = $get_row['amount'];
	$pay_method = 'Manually';
	$pay_user_id = $get_row['user_id'];
	
	if ($get_row['completed'] == 1) $error[] = "You have already paid this user";
	
	if (empty($error)):
		$update = mysql_query("UPDATE `withdrawals` SET `method` = '".$pay_method."', `completed` = 1, `completed_time` = '".date("Y-m-d H:i:s")."' WHERE `id` = ".$pay_id);
		$paying_user = get_user_info($pay_user_id);
		$total_withdrawn = $paying_user['total_withdrawn'] + $pay_amount;
		$update = mysql_query("UPDATE `users` SET `total_withdrawn` = '".$total_withdrawn."' WHERE `id` = ".$pay_user_id);
		$new_set = $set['total_paid'] + $pay_amount;
		$update_set = mysql_query("UPDATE `options` SET `option_value` = '".$new_set."' WHERE `option_name` = 'total_paid'");
		if (confirm_query($update) && confirm_query($update) && confirm_query($update_set)) {
			$message = "Simple Withdrawal of $".$pay_amount." was completed successfully!";
			add_noti("Your withdrawal of <strong>($".$pay_amount.")</strong> has been successfully completed!", $pay_user_id,'Withdrawal Completed!');
		}
endif;
	
}

if (isset($_GET['pay'])) {

	$pay_id = intval($_GET['pay']);
	$get_result = mysql_query("SELECT * FROM `withdrawals` WHERE `id` = " . $pay_id);
	$get_row = mysql_fetch_array($get_result);
	
	if ($get_row['completed'] == 1) $error[] = "You have already paid this user";
	
	$pay_amount = $get_row['amount'];
	$pay_method = $get_row['method'];
	$pay_user_id = $get_row['user_id'];
	
	$to_user = get_user_info($pay_user_id);
	
if ($pay_method == "paypal"){
	
	if ($to_user['paypal_email'] == '') {
		$error[] = "User's paypal email is empty";
	}
	if (empty($error)):
		include('pay/inc_paypal.php');
		$data = array(
		    'actionType' => 'PAY',
		    'currencyCode' => 'USD',
			'senderEmail' => 'etallu_new@paypal.com',
			'feesPayer' => 'SENDER',
		    'receiverList' => array(
			  'receiver' => array(
						array(
							'amount' => $pay_amount,
							'email' => $to_user['paypal_email']
						)
				  )
			),
		    'returnUrl' => $set['home'],
		    'cancelUrl' => $set['home'],
		    'requestEnvelope' => array(
		            'errorLanguage' => 'en_US',
		            'detailLevel' => 'ReturnAll'
		        )
		);	
		
		$data =  json_encode($data);
		$response_json = pay_now($data,true);
		$received = json_decode($response_json,true);
		
		if (isset($response_json['error'])) {
			$error[] = $received['error'][0]['message'];
		} elseif( $received['responseEnvelope']['ack'] == "Success" && $received['paymentExecStatus'] == "COMPLETED") {
			include('includes/update_withdrawal_request.php');
		}
		
	endif;	
	
} elseif($pay_method == "payza"){
	
	if ($to_user['payza_email'] == '') {
		$error[] = "User's Payza email is empty";
	}
	
	if (empty($error)):
	
	include_once('pay/payza-sendmoney-class.php');

	$do = new SendMoneyClient($set['payza_email'],'3Iyvc0A9jwUmy4aN');
  	
	//for sanfbox
	//$do->setServer("sandbox.Payza.com");
	//$do->setUrl("/api/api.svc/sendmoney");
	
	// for live
	$do->setServer("api.payza.com/svc");
	$do->setUrl("/api.svc/sendmoney");
	
	$do->BuildPostVariables($pay_amount, 'USD', $to_user['payza_email'], $set['payza_email'],0,'',0);
	
	$output = $do->send();
	$do->parseResponse($output);
	$result = $do->getResponse();
	
	$response_json = json_encode($result);
	
	// Output variables
	
	if ($result['RETURNCODE'] != 100) {
		$error[] = $result['DESCRIPTION'];	
	} else {
		include('includes/update_withdrawal_request.php');
	}
	
	endif;
	
}
	
}

?>

<h2 class="main_title">Withdrawals</h2>

<div class="box">
	
    <div class="left sort_links">
    <a href="withdrawals.php">All <span>(<?php echo count_withdrawals('all'); ?>)</span></a> | 
    <a href="withdrawals.php?completed=0">Pending <span>(<?php echo count_withdrawals('pending'); ?>)</span></a> |
    <a href="withdrawals.php?completed=1">Completed <span>(<?php echo count_withdrawals('completed'); ?>)</span></a>
    </div>
    <div class="right">
    </div>
    <div class="clear"></div>
</div><!-- .box -->

<?php

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = $set['per_page'];
	$startpoint = ($page * $limit) - $limit;
 	
	$oderby = " ORDER BY `completed`, `id` DESC";
	$statement = "`withdrawals` " .$oderby;
	
	if (isset($_GET['id'])) {
		$statement = "`withdrawals` WHERE `user_id` = '".intval($_GET['id'])."' ".$oderby;
	} 
	
	if (isset($_GET['completed'])) {
		$statement = "`withdrawals` WHERE `completed` = '".intval($_GET['completed'])."' ".$oderby;
	}
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['id']))
		$url .= 'id='. $_GET['id']. '&';
	if (isset($_GET['completed']))
		$url .= 'completed='. $_GET['completed']. '&';
		
	echo pagination($statement,$limit,$page, $url);
	
 ?>

<?php if (isset($response_json)) { ?>
<div class="box response_json">
	<a class="view_json">JSON Code</a>
	<div class="json_code"><?php print_json($response_json); ?></div>
</div><!-- .box -->
<?php } ?>
	

<div class="wrap_box">

<?php display_message(); ?>
<?php display_error(); ?>
	
	<?php if ($result_count !=0) { ?>
    <table class="form_table">
        	<tr class="head">
            	<td width="40">ID</td>
                <td width="200">User</td>
        		<td>Amount</td>
                <td>Method</td>
                <td>Status</td>
                <td width="150">Manual Pay</td>
                <td width="150">Action</td>
                <td width="150">Completed</td>
                <td width="150">Requested</td>
                <td width="150"></td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
				$from_user = get_user_info($row['user_id']);
			?>
            <tr class="<?php if($count%2) echo "even"; else echo "odd"; ?> <?php if($row['completed'] == 0) echo "pending"; ?>" >
            	<td><?php echo $row['id']; ?></td>
                <td><a href="edit_user.php?id=<?php echo $from_user['id']; ?>"><strong><?php echo $from_user['username']; ?></strong></a> - 
                <a href="withdrawals.php?id=<?php echo $from_user['id']; ?>"><small>View All</small></a></td>
            	<td><strong>$<?php echo $row['amount']; ?></strong></td>
                <td><img src="<?php echo $set['home']; ?>/img/pmt-icons/<?php echo $row['method']; ?>.png" alt="" style="width:45px;"></td>
                <td><?php if ($row['completed'] == 1) echo "<strong class='active'>Completed!</strong>"; else echo "<strong class='pending'>Pending</strong>" ?></td>
                <td>
                 <?php if ($row['completed'] == 0) { ?>
                 <strong><a href="withdrawals.php?simple_pay=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to pay $<?php echo $row['amount']; ?> manualy to <?php echo $from_user['username']; ?>');">Pay Manually</a></strong>
                 <?php } else { ?>
                 	<strong class='active'>Paid!</strong>
                 <?php } ?>
                 </td>
                 <td>
                 <?php if ($row['completed'] == 0) { ?>
                 <strong><a href="withdrawals.php?pay=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to pay $<?php echo $row['amount']; ?> to <?php echo $from_user['username']; ?>');">Pay Now</a></strong>
                 <?php } else { ?>
                 	<strong class='active'>Paid!</strong>
                 <?php } ?>
                 </td>
                <td><?php  if ($row['completed_time'] != '0000-00-00 00:00:00') datetime($row['completed_time']); ?></td>
                <td><?php datetime($row['datetime']); ?></td>
               
                <td>
                <?php if ($row['response_json'] != '') { ?>
                	<a href="withdrawals.php?view_json=<?php echo $row['id']; ?>">View Response</a>
                <?php } ?>
                </td>
                
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->

<?php echo pagination($statement,$limit,$page, $url); ?>

<?php include('footer.php'); ?>



