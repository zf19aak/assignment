<?php include('header.php'); ?>

<h2 class="main_title">Stats</h2>

<div class="stat_wrap box">
	
    <table class="main_stats"> 
      <tr>
        <td><strong><?php echo count_users('all'); ?></strong><br> Total Registered Users</td>
        <td><strong><?php echo count_all_services('all','',true); ?></strong><br> Total Services Created</td>
        <td class="last"><strong><?php echo count_all_orders('','',true); ?></strong><br> Total Orders Created</td>
      </tr>
    </table>

    <div class="clear"></div>
</div><!-- .stat_wrap -->

<?php

$result = mysql_query("SELECT * FROM `users`");
$total_balance = 0;$total_withdrawn = 0; $total_used = 0; $total_deposit = 0; $total_purchase_balance = 0;
while ($row = mysql_fetch_array($result)) {
  
  $total_balance = $total_balance + $row['balance'];
  $total_withdrawn += $row['total_withdrawn'];
  $total_used += $row['total_used'];
  $total_deposit += $row['total_deposit'];
  $total_purchase_balance += $row['purchase_balance'];
  	
}

?>

<div class="stat_wrap box">
	<table class="main_stats"> 
          <tr>
            <td><strong>$<?php echo $total_balance; ?></strong><br>Total User's available Balance</td>
            <td><strong>$<?php echo $total_purchase_balance ?></strong><br>Total User's available Purchase Balance</td>
            <td><strong>$<?php echo $total_deposit ?></strong><br>Total User's Deposit<br>&nbsp;</td>
            <td><strong>$<?php echo $total_used; ?></strong><br>Total Balance used<br>&nbsp;</td>
            <td class="last"><strong>$<?php echo $total_withdrawn; ?></strong><br>Total Withdrawn<br>&nbsp;</td>
          </tr>
        </table>
</div>

    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      
	  function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['List', 'Users'],
		  <?php
	if (isset($_GET['chart_by'])) {
   $chart_by = $_GET['chart_by'];
	} else {
   $chart_by = 'day';
	}

if (isset($_GET['this_month'],$_GET['this_year'])) {
	
	if ($_GET['this_month'] == 'all' && $_GET['this_year'] == date('Y')) {
		$chart_by = "month";
	} elseif ($_GET['this_month'] == 'all') {
		$chart_by = "month";
		$date_from = $_GET['this_year'] . '-' . '12' . '-' . '31 ';
	} else {
		$chart_by = "day";	
		$date_from = $_GET['this_year'] . '-' . $_GET['this_month'] . '-' . '31 ';
	}
		
}

	  
  if ($chart_by == 'month') {
	$number = 12;
	$multiply_by_days = 31;
	$print_date_var = 'M Y';
	$showTextEvery = 0;
  } elseif($chart_by== 'year') {
	$number = 12;
	$multiply_by_days = 360;
	$print_date_var = 'Y';
	$showTextEvery = 0;
  } else {
	$number = 31;
	$multiply_by_days = 1;
	$print_date_var = 'd F Y';
	$showTextEvery = 8;
  }

if (!isset($date_from)) $date_from = '';

for ($i = 0 ; $i < $number ; $i++) {
	
	$new_i = ($i * $multiply_by_days);
	$timestamp = strtotime("$date_from-$new_i days");
	
	$by_year = date('Y', $timestamp);
	
	if ($chart_by == 'year') {
		$by_month = false;
	} else {
		$by_month = date('m', $timestamp);
	}
	
	if ($chart_by == 'day') {
		$by_day = date('d', $timestamp);
	} else {
		$by_day = false;
	}
	
	$count = users_by_date($by_year,$by_month, $by_day);
	$month = date($print_date_var, $timestamp);
	if (date('Y-m-d', $timestamp) < '2013-10-01') {
		echo "['Before etallu Launched',  0],\n";
		break;
	}
	echo "['$month',  $count],\n";
	
	
	
}
?>
    ]);


        var options = {
		  lineWidth: 4,
		  pointSize: 7,
		  colors: ['#02aeb1'],
		  areaOpacity: 0.15,
		  focusTarget: 'category',
		  //legend: {position: 'top', textStyle: {color: '#444', fontSize: 12}},
		  legend: 'none',
		  hAxis: {
			  	textStyle: { color: '#747474', fontName: 'Arial', fontSize: 11, bold: '400', italic: 'false' }, 
				direction: -1, 
				viewWindow:{ min: 0 }, 
				textPosition: 'out'
				<?php if ($showTextEvery> 0) { ?>,
				showTextEvery: <?php echo $showTextEvery; ?>
				<?php } ?>
				},
		  vAxis: {textStyle: { color: '#747474', fontName: 'Arial', fontSize: 11, bold: '400', italic: 'false' }, gridlines: {color: '#f1f1f1',count: 3}, textPosition: 'in',viewWindow:{ min: 0 },format: '#',minValue: 0},
		  tooltip: {textStyle: { color: '#444', fontName: 'Arial', fontSize: 12, bold: '400', italic: 'false' }},
		  chartArea: {width: '100%', height: '79%'},
		  axisTitlesPosition: 'in',
		  
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>

<h2 class="main_title">Registered Users</h2>

<div class="stat_wrap box">
<div class="chart_top">
	<div class="left">
    <form action="index.php" method="get">
    <select name="this_month">
    <?php if (isset($_GET['this_month'])) { if ($_GET['this_month'] != 'all') { $monthNum = $_GET['this_month']; ?>
    	<option value="<?php echo $_GET['this_month']; ?>" selected><?php echo date("F", mktime(0, 0, 0, $monthNum, 10)); ?></option>
    <?php } } ?>
    	
    	<option value="all">All Month</option>
        <option value="01">January</option>
        <option value="02">February</option>
        <option value="03">March</option>
        <option value="04">April</option>
        <option value="05">May</option>
        <option value="06">June</option>
        <option value="07">July</option>
        <option value="08">August</option>
        <option value="09">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>
     </select>
    <select name="this_year">
    <?php if (isset($_GET['this_year'])) { ?>
    	<option value="<?php echo $_GET['this_year']; ?>" selected><?php echo $_GET['this_year']; ?></option>
    <?php }   ?>
    	<option>2013</option>
        <option>2014</option>
    
        
    </select>
        <input type="submit" value="Go">
        <?php
		if ($chart_by == 'month') {
			$show_message = "Recent Months from " . date('Y');
		  } elseif($chart_by== 'year') {
			$show_message = "Recent years";
		  } else {
			$show_message = "Recent 31 Days";
		  }
		  if (isset($_GET['this_month'],$_GET['this_year'])) { 
		  	if ($_GET['this_month'] != 'all') {
				$add_month = date("F", mktime(0, 0, 0, $_GET['this_month'], 10));
			} else {
				$add_month = 'All Months';
			}
		  	$show_message = $add_month . " in " . $_GET['this_year'];
		  }
		?>
        <strong>Showing:</strong> <?php echo $show_message; ?>
    </form>       
        

    </div>
    <div class="right">
    <a href="index.php?chart_by=day" class="button<?php if ($chart_by == 'day') echo" current"; ?>">Day</a>
    <a href="index.php?chart_by=month" class="button<?php if ($chart_by == 'month') echo" current"; ?>">Month</a>
    <a href="index.php?chart_by=year" class="button<?php if ($chart_by == 'year') echo" current"; ?>">Year</a>
    </div>
    <div class="clear"></div>
</div>
	<div id="chart_div" class="chart_wrap"></div>
</div>

<?php include('footer.php'); ?>



