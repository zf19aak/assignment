<?php
session_start();
if (isset($_SESSION['admin_login'])) unset($_SESSION['admin_login']);
// session_unset(); session_destroy();
echo "<meta http-equiv=\"REFRESH\" content=\"0; url=index.php\">";
?>