<?php include('header.php'); 
 

if (isset($_GET['del'])) {
	$del_id = intval($_GET['del']);
	$query = mysql_query("DELETE FROM `forum_categories` WHERE `id` = " .$del_id);
	if (confirm_query($query)){
		$message = "Successfully Deleted!";
	}
}

// Edit Car
if (isset($_POST['update_cat'])) :

$id = intval($_GET['edit']);

$name = mres($_POST['name']);
$description = mres($_POST['description']);
$position = mres($_POST['position']);
$slug = mres($_POST['slug']);

$query = mysql_query("UPDATE `forum_categories` SET
	`name` = '".$name."',
	`description` = '".$description."',
	`position` = '".$position."',
	`slug` = '".$slug."'
 WHERE `id` = " . $id);

if ($query) {
		$message = "Category Updated!";
	} else {
		$error[] = "Error: ". mysql_error();	
	}

endif;

// Add new
if (isset($_POST['add_cat'])) :

$name = mres($_POST['name']);
$description = mres($_POST['description']);
$position = mres($_POST['position']);

if (empty($error)) {
	
	$query = mysql_query("INSERT INTO `forum_categories` (
		`name`,
		`description`,
		`position`
		) VALUES (
		'".$name."',
		'".$description."',
		'".$position."'
		)");
	
	if ($query) {
		$message = "Category Added!";
	} else {
		$error[] = "Error: ". mysql_error();	
	}
		
}

endif;

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = $set['per_page'];
	$startpoint = ($page * $limit) - $limit;
 	
	$sort_by = isset($_GET['sort_by'])? mres($_GET['sort_by']) : $sort_by = "id";
	$sort = isset($_GET['sort'])? mres($_GET['sort']) : $sort = "ASC";
	

	$statement = "`forum_categories` ORDER BY `position` ".$sort;
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['user_id']))
		$url .= 'user_id='. $_GET['user_id']. '&';
		
	echo pagination($statement,$limit,$page, $url);

?>

<h2 class="main_title">Notifications</h2>

<?php
if (isset($_GET['edit'])) :

$id = intval($_GET['edit']);
$edit_cat = get_forum_category_info($id);

?>

<div class="wrap_box edit_form_wrap add_cat_wrap">
<form method="post" action="forum-categories.php?edit=<?php echo $id; ?>">
    Name:	<input type="text" name="name" value="<?php echo $edit_cat['name']; ?>" placeholder="Name">
    Description: <input type="text" name="description" value="<?php echo $edit_cat['description']; ?>" placeholder="Description"> <br>
    Slug: <input type="text" name="slug" value="<?php echo $edit_cat['slug']; ?>" placeholder="Slug">
    Position: <input type="text" name="position" value="<?php echo $edit_cat['position']; ?>" style="width:80px" placeholder="Position">
    <input type="submit" value="Update" name="update_cat">
</form>
</div><!-- .wrap_box -->

<?php else : ?>

<div class="wrap_box edit_form_wrap add_cat_wrap">
<form method="post" action="forum-categories.php">
	<input type="text" name="name" placeholder="Name">
    <input type="text" name="description" placeholder="Description">
    <input type="text" name="position" value="" style="width:80px" placeholder="Position">
    <input type="submit" value="Add" name="add_cat">
</form>
</div><!-- .wrap_box -->

<?php endif;  ?>

<div class="wrap_box edit_form_wrap">

<?php display_error(); display_message(); ?>

	<?php if ($result_count !=0) { ?>
    <table class="form_table">
        	<tr class="head">
                <td class="alignleft">Name</td>
        		<td  class="alignleft">Description</td>
                <td width="100"></td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
			?>
            <tr class="odd" >
                <td><strong><?php echo $row['name']; ?></strong> | <?php echo $row['slug']; ?></td>
            	<td class="alignleft"><?php echo $row['description']; ?></td>
                <td><a href="forum-categories.php?edit=<?php echo $row['id']; ?>">Edit</a> | 
                <a href="forum-categories.php?del=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to delete?')" class="del_link">Delete</a></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->

<?php echo pagination($statement,$limit,$page, $url); ?>
<?php include('footer.php'); ?>