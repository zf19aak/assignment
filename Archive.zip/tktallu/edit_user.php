<?php include('header.php'); ?>
<?php

if (!isset($_GET['id'])) { redirect('users.php'); exit; }

$user_id = intval($_GET['id']);

if (isset($_GET['suspend'])) {
$suspend = intval($_GET['suspend']);

$suspend_result = mysql_query("UPDATE `users` SET `suspended` = '".$suspend."' WHERE `id` = '".$user_id."' LIMIT 2");
	if (confirm_query($suspend_result)) $message = "Successfully Done!";
}

if (isset($_POST['save_submit'])):

$this_user = get_user_info($user_id);
	
	$username = mres($_POST['username']);
	$first_name = mres($_POST['fist_name']);
	$last_name = mres($_POST['last_name']);
	$email = mres($_POST['email']);
	$paypal_email = mres($_POST['paypal_email']);
	$new_password = mres($_POST['new_password']);
	
	$balance = mres($_POST['balance']);
	$purchase_balance = mres($_POST['purchase_balance']);
	$referrer = mres($_POST['referrer']);

	$role = mres($_POST['role']);
	
	$deposit = mres($_POST['deposit']);
	$forum_mod = mres($_POST['forum_mod']); 

	
	$check_username = mysql_query("SELECT `username` FROM `users` WHERE `username` = '{$username}'");
	if (mysql_num_rows($check_username) != 0 && $username != $this_user['username']) {
		$error[] = "Sorry, This username is already being used.";
	}

	$check_email = mysql_query("SELECT `email` FROM `users` WHERE `email` = '{$email}'");
	if (mysql_num_rows($check_email) != 0 && $email != $this_user['email']) {
		$error[] = "Sorry, This email address is already being used.";
	}
	
	
		if ($deposit != 0) {
		$purchase_balance = $purchase_balance + $deposit;
		add_noti("etallu has deposited <strong>($".$deposit.")</strong> into your account.", $user_id,'Deposit Added');
		$new_deposit = $this_user['total_deposit'] + $deposit;
	}
	

	if (empty($error)){ 
	
	
		$update_sql = "UPDATE `users` SET
		`username` = '".$username."', 
		`first_name` = '".$first_name."',
		`last_name` = '".$last_name."',
		`email` = '".$email."',
		`balance` = '".$balance."',
		`purchase_balance` = '".$purchase_balance."',
		`referrer` = '".$referrer."',
		`role` = '".$role."',
		`forum_mod` = '".$forum_mod."',";
		
		
		if ($new_password != '') {
		$update_sql .= " `password` = '".sha1($new_password)."', ";
		}
		if (isset($new_deposit)) {
		$update_sql .= " `total_deposit` = '".$new_deposit."', ";
		}
		
		$update_sql .= " 
		`paypal_email` = '".$paypal_email."' 
		WHERE `id` = ". $user_id;
		
		$update_result = mysql_query($update_sql);
		if (confirm_query($update_result)) {
			$user = get_loggedin_info();
			$message = "Settings Saved!";
		}
		
	}
	
endif;

$this_user = get_user_info($user_id);

?>


<div class="wrap">

<?php if ($this_user['suspended']) display_error('<strong>NOTE:</strong> This User is Suspended!'); ?>

<?php display_error(); ?>
<?php display_message(); ?>
</div>

<div class="wrap_box edit_form_wrap">

<h2 class="main_title user_title">
<?php the_flag($this_user['last_ip'],1); ?>
<strong><?php echo $this_user['username']; ?> </strong>

<span class="left">
		
<small>
       &nbsp; <?php if ($this_user['email_verified'] == 1) echo "<strong style='color:green'>Email Verified</strong>"; else echo "<strong class='color:red'>Email Verification pending</strong>"; ?>  
           - <a href="notifications.php?id=<?php echo $this_user['id']; ?>">View History</a> 
         
        <?php if ($this_user['suspended'] == '0') { ?>
        -  <a href="edit_user.php?id=<?php echo $user_id; ?>&suspend=1" onClick="return confirm('Are you sure you want to suspend this user?')" class="button del_link">Suspend User</a>
        <?php } else { ?>
        <a href="edit_user.php?id=<?php echo $user_id; ?>&suspend=0" onClick="return confirm('Are you sure you want to un-suspend this user?')" class="button del_link">Un-suspend User</a>
        <?php } ?>

        
        </small>
	</span>
    <span class="right"><?php the_avatar($this_user['id']); ?> </span>
    <div class="clear"></div>
</h2>

</div><!-- .wrap_box .edit_form_wrap -->


<form action="edit_user.php?id=<?php echo $user_id; ?>" method="post">

<div class="wrap_box edit_form_wrap">


<div class="form_box">

	
    <table class="form_table edit_form">
    		<tr>
  				<td class="label">Username:</td>
                <td class="field"><input type="text" name="username" value="<?php echo $this_user['username']; ?>" /></td>
                <td class="label">Balance: (USD)</td>
                <td class="field"><input type="text" name="balance" value="<?php echo $this_user['balance']; ?>" /></td>
  			</tr>
            <tr>
  				<td class="label">First Name:</td>
                <td class="field"><input type="text" name="fist_name" value="<?php echo $this_user['first_name']; ?>" /></td>
				<td class="label">Purchase Balance: (USD)</td>
                <td class="field"><input type="text" name="purchase_balance" value="<?php echo $this_user['purchase_balance']; ?>" /></td>
  			</tr>
            <tr>
                <td class="label">Last Name:</td>
                <td class="field"><input type="text" name="last_name" value="<?php echo $this_user['last_name']; ?>" /></td>  
  				<td class="label"><?php $ref_row = get_user_info($this_user['referrer'],true); ?><a href="edit_user.php?id=<?php echo $ref_row['id']; ?>">Referrer</a></td>
                <td class="field"><input type="text" name="referrer" value="<?php echo $this_user['referrer']; ?>" /></td>    
  			</tr>
            <tr>	
            	<td class="label">Email:</td>
                <td class="field"><input type="email" name="email" value="<?php echo $this_user['email']; ?>" /></td>
                <td class="label">Paypal Email:</td>
                <td class="field"><input type="email" name="paypal_email" value="<?php echo $this_user['paypal_email']; ?>" /></td>
  			</tr>
            <tr>
  				<td class="label">Description:</td>
                <td class="field"><textarea name="description"><?php echo $this_user['description']; ?></textarea></td>
				<td class="label">Level:</td>
                <td class="field"><?php echo $this_user['level']; ?></td>
  			</tr>
            <tr>
  				<td class="label">Signup Date</td>
                <td class="field"><?php datetime($this_user['signup_date']) ?></td>
                <td class="label">Last Login:</td>
                <td class="field"><?php datetime($this_user['last_login']) ?></td>
  			</tr>
             <tr>
  				<td class="label">Role:</td>
                <td class="field"><select name="role">
                	<?php if ($this_user['role'] == "user") { ?>
	                    <option selected value="user">User</option>
	                    <option value="staff">Staff</option>
						<option value="admin">Admin</option>
					<?php } elseif ($this_user['role'] == "staff") {?>
	                    <option selected value="staff">Staff</option>
                        <option value="user">User</option>
						<option value="admin">Admin</option>
                    <?php } elseif ($this_user['role'] == "admin") { ?>
						<option selected value="admin">Admin</option>
                        <option value="user">User</option>
                        <option value="staff">Staff</option>
                    <?php } else { ?>
                	<option>Not Mentioned</option>
                    <?php } ?>
                    </select></td>
                <td class="label">Update Password:</td>
                <td class="field"><input type="password" name="new_password" /></td>
  			</tr>
            <tr>
                <td class="label">Add Deposit:</td>
                <td class="field"><input type="text" name="deposit" /></td>
                <td class="label">Forum Moderator?</td>
                <td class="field">
                	No <input type="radio" <?php if ($this_user['forum_mod'] == 0) echo 'checked'; ?>  name="forum_mod" value="0"> 
                	Yes <input type="radio" <?php if ($this_user['forum_mod'] == 1) echo 'checked'; ?> name="forum_mod" value="1"></td>
  			</tr>
            <tr>
            	<td class="label"></td>
                <td class="field"></td>
	    		<td class="label"></td>
	            <td class="field"><input type="submit" name="save_submit" value="Save"></td>
	    	</tr>
  		</table>
    	
</div><!-- .form_box -->

</div><!-- .wrap_box -->

<?php

$total_earnings = ($this_user['balance'] + $this_user['total_withdrawn']) - $this_user['total_deposit']; 
 if ($total_earnings < 0) $total_earnings = 0; 

$total_purchasing = $this_user['total_used'] - $this_user['total_deposit']; 
			if ($total_purchasing < 0) $total_purchasing = 0; 

$pending_count = mysql_query("SELECT `amount` FROM `earnings` WHERE `status` = 'Pending' AND `user_id` = " . $this_user['id']);
$total_pending = 0;
while ($count_row = mysql_fetch_array($pending_count)){
	$total_pending = $total_pending + $count_row['amount'];
}

$upcimming_count = mysql_query("SELECT `price` FROM `orders` WHERE `status` = 'Active' AND `seller_id` = " . $this_user['id']);
$total_upcoming = 0;
while ($count_row = mysql_fetch_array($upcimming_count)){
	$amount = get_seller_earning_amount($count_row['price']);
	$total_upcoming = $total_upcoming + $amount;
}

?>

<div class="stat_wrap box user_box">
<h2>Earnings</h2>
	<table class="main_stats"> 
          <tr>
            <td><strong>$<?php echo $this_user['balance']; ?></strong><br>Balance</td>
            <td><strong>$<?php echo $total_earnings; ?></strong><br>Total Earnings</td>
            <td><strong>$<?php echo $total_purchasing; ?></strong><br>Total Purchasing</td>
            <td><strong>$<?php echo $this_user['total_withdrawn']; ?></strong><br>Total Withdrawn</td>
            <td><strong>$<?php echo $this_user['total_deposit']; ?></strong><br>Total Deposit </td>
            <td><strong>$<?php echo $total_pending ?></strong><br>Pending Earnings</td>
            <td class="last"><strong>$<?php echo $total_upcoming ?></strong><br>Upcoming Ernings</td>
          </tr>
        </table>
</div><!-- .box -->

<div class="stat_wrap box user_box">
<h2><a href="orders.php?seller_id=<?php echo $this_user['id']; ?>"><?php echo $this_user['username']; ?>'s Sales</a></h2>
<table class="main_stats"> 
  <tr>
    <td><a href="orders.php?seller_id=<?php echo $this_user['id']; ?>"><strong><?php echo count_orders('all','seller_id',$this_user['id']); ?></strong><br>All Orders</a></td>
    <td><a href="orders.php?seller_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Active"><strong><?php echo count_orders('Active','seller_id',$this_user['id']); ?></strong><br>Active Orders</a></td>
    <td><a href="orders.php?seller_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Pending"><strong><?php echo count_orders('Pending','seller_id',$this_user['id']); ?></strong><br>Pending Orders</a></td>
    <td><a href="orders.php?seller_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Completed"><strong><?php echo count_orders('Completed','seller_id',$this_user['id']); ?></strong><br>Completed Orders</a></td>
    <td><a href="orders.php?seller_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Delivered"><strong><?php echo count_orders('Delivered','seller_id',$this_user['id']); ?></strong><br>Delivered Orders</a></td>
    <td class="last"><a href="orders.php?seller_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Cancelled"><strong><?php echo count_orders('Cancelled','seller_id',$this_user['id']); ?></strong><br>Cancelled Ordersd</a></td>
  </tr>
</table>
</div><!-- .box -->

<div class="stat_wrap box user_box">
<h2><a href="orders.php?buyer_id=<?php echo $this_user['id']; ?>"><?php echo $this_user['username']; ?>'s Shopping</a></h2>
<table class="main_stats"> 
  <tr>
    <td><a href="orders.php?buyer_id=<?php echo $this_user['id']; ?>"><strong><?php echo count_orders('all','buyer_id',$this_user['id']); ?></strong><br>All Orders</a></td>
    <td><a href="orders.php?buyer_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Active"><strong><?php echo count_orders('Active','buyer_id',$this_user['id']); ?></strong><br>Active Orders</a></td>
    <td><a href="orders.php?buyer_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Pending"><strong><?php echo count_orders('Pending','buyer_id',$this_user['id']); ?></strong><br>Pending Orders</a></td>
    <td><a href="orders.php?buyer_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Completed"><strong><?php echo count_orders('Completed','buyer_id',$this_user['id']); ?></strong><br>Completed Orders</a></td>
    <td><a href="orders.php?buyer_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Delivered"><strong><?php echo count_orders('Delivered','buyer_id',$this_user['id']); ?></strong><br>Delivered Orders</a></td>
    <td class="last"><a href="orders.php?buyer_id=<?php echo $this_user['id']; ?>&search_by=status&search_term=Cancelled"><strong><?php echo count_orders('Cancelled','buyer_id',$this_user['id']); ?></strong><br>Cancelled Ordersd</a></td>
  </tr>
</table>
</div><!-- .box -->

<div class="stat_wrap box user_box">
<h2><a href="services.php?user_id=<?php echo $this_user['id']; ?>"><?php echo $this_user['username']; ?>'s Services</a></h2>
	<table class="main_stats"> 
          <tr>
            <td><strong><?php echo count_services($this_user['id'],'Active'); ?></strong><br>Active<br>&nbsp;</td>
            <td><strong><?php echo count_services($this_user['id'],'Paused'); ?></strong><br>Paused<br>&nbsp;</td>
            <td><strong><?php echo count_services($this_user['id'],'Requires Modification'); ?></strong><br>Requires<br>Modification</td>
            <td><strong><?php echo count_services($this_user['id'],'Pending'); ?></strong><br>Pending<br>Approval</td>
            <td class="last"><strong><?php echo count_services($this_user['id'],'Denied'); ?></strong><br>Denied<br>&nbsp;</td>
          </tr>
        </table>
</div><!-- .box -->



<?php if ($set['show_google_analytics']) { ?>
<div class="stat_wrap box user_box">
<?php
 	if ($this_user['last_login'] != '') {
 	$ip = json_decode(ip_json($this_user['last_login']));
  ?>
<h2>Last Login <?php datetime($this_user['last_login']) ?> From:</h2>
 <?php $ip = json_decode(ip_json($this_user['last_ip'])); ?>
    <div class="total_box"> <strong><?php if (isset($ip->geoplugin_request)) echo $ip->geoplugin_request; else  echo$this_user['last_ip']; ?></strong><br> Login IP </div>
    <div class="total_box"> <strong><?php echo ucfirst(strtolower($ip->geoplugin_countryName)); ?> <?php the_flag($this_user['signup_ip'],1); ?></strong><br> Login Country </div>
    <div class="total_box"> <strong><?php if (isset($ip->geoplugin_city)) echo $ip->geoplugin_city; ?></strong><br> Login City </div>
    <div class="total_box no_right_border"> <strong><?php echo $ip->geoplugin_countryCode; ?></strong><br> Country Code </div>
    <div class="clear"></div>
<?php } else { echo "Last login column is empty"; } ?>      
</div><!-- .stat_wrap -->

<div class="stat_wrap box user_box">
<?php
 	if ($this_user['signup_ip'] != '') {
 	$ip = json_decode(ip_json($this_user['signup_ip']));
  ?>
<h2>Sign Up <?php datetime($this_user['signup_date']) ?></h2>
    <div class="total_box"> <strong><?php if (isset($ip->geoplugin_request)) echo $ip->geoplugin_request; else  echo$this_user['signup_ip']; ?></strong><br> Sign Up IP </div>
    <div class="total_box"> <strong><?php echo $ip->geoplugin_countryName; ?> <?php the_flag($this_user['signup_ip'],1); ?></strong><br> Sign up Country </div>
    <div class="total_box"> <strong><?php if (isset($ip->geoplugin_city)) echo $ip->geoplugin_city; ?></strong><br> Sign up City </div>
    <div class="total_box no_right_border"> <strong><?php echo $ip->geoplugin_countryCode; ?></strong><br> Country Code </div>
    <div class="clear"></div>
<?php } else { echo "Signup Date column is empty"; } ?>    
</div><!-- .stat_wrap -->
<?php } ?>
</form>

<?php include('footer.php'); ?>