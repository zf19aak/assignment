<?php include('header.php'); ?>
<?php

if (!isset($_GET['number'])) redirect('conversations.php');

$number = mres($_GET['number']);

$order = get_order_info($number);

if (!isset($order['id'])) redirect('conversations.php');

$buyer = get_user_info($order['buyer_id']);
$seller = get_user_info($order['seller_id']);
$service = get_service_info($order['service_id']);

if (isset($_GET['remove_reviews'])) :
	
	remove_reviews($order['number']);
	
	$message = "<strong>Done!</strong> Both Reviews are removed now!";
	
endif;

if (isset($_GET['cancel'])) :
	
	$got_payent = false;
	
	if ($order['status'] == 'Cancelled') $error[] = "This order is already Cancelled!";
	
	if ($order['status'] == 'Completed') { 
		
		$check_earnings = mysql_query("SELECT * FROM `earnings` WHERE `order_id` = ".$order['id']." AND `user_id` = ".$seller['id']);
		$earning_result = mysql_fetch_array($check_earnings);
		
		if ($earning_result['status'] == 'Pending') {
			
			$cancel_earning = mysql_query("UPDATE `earnings` SET `status` = 'Cancelled' WHERE `order_id` = ".$order['id']." AND `user_id` = ".$seller['id']);
			$got_payent = true;
			
		} elseif ($earning_result['status'] == 'Completed') {
			
			if ($seller['balance'] < $order['price']) {
				$error[] = "Seller doesn't have enough balance to refund the buyer. <strong>Balance is: $" . $seller['balance']. '</strong>';
			} else {
				$get_from_seller = mysql_query("UPDATE `users` SET `balance` = `balance` - " . $order['price'] . " WHERE `id` = " . $seller['id']);
				$got_payent = true;
			}
				
		} 
		
	} 
	
	if ($order['status'] == 'Active' || $order['status'] == 'Late' || $order['status'] == 'Pending') { 
		$got_payent = true;
	}
	
	if ($got_payent) {
		$send_to_buyer = mysql_query("UPDATE `users` SET `purchase_balance` = `purchase_balance` + " . $order['price'] . " WHERE `id` = " . $buyer['id']);
		if (!$send_to_buyer) echo 'Error: '.mysql_error();
		$refunded = true;
	} else {
		$refunded = false;	
	}

	
	
if ($refunded) {
	$cancel_order = mysql_query("UPDATE `orders` SET `status` = 'Cancelled' WHERE `id` = " . $order['id']);
	if (!$cancel_order) echo 'Error: ' . mysql_error();
	remove_reviews($order['number']);
	$cancelled = true;
}

if (isset($cancelled)){
	$message = "<strong>Done!</strong> Order is Cancelled now!";
	
	$noti_desc = 'Unfortunately, your order #'.$order['number'] . ' is now cancelled by etallu support and funds are refunded to the buyer.';
	$noti_url =  '/order/'.$order['number'].'/';
	add_noti($noti_desc,$seller['id'],$noti_url, 'Order #'.$order['number'] . ' is cancelled by etallu support');
	
	$noti_desc = 'Your order #'.$order['number'] . ' is now cancelled by etallu support and funds are added back to your purchase balance.';
	add_noti($noti_desc,$buyer['id'],$noti_url,'Order #'.$order['number'] . ' is cancelled by etallu support');
	
}

$order = get_order_info($number);

endif;

?>

<div class="wrap">
<?php display_error(); ?>
<?php display_message(); ?>
</div>


<div class="wrap_box edit_form_wrap aligncenter">
	
    <a href="view-order.php?number=<?php echo $order['number']; ?>&cancel=1" onClick="return confirm('Are you sure you want to cancel this order?')" class="button del_link">Cancel the order and refund to buyer.</a>
    <a href="view-order.php?number=<?php echo $order['number']; ?>&remove_reviews=1" onClick="return confirm('Are you sure you want to remove the reviews for this order?')" class="button">Remove Reviews</a>
    
</div><!-- .wrap_box -->

<div class="wrap_box edit_form_wrap">
<h2 class="left">Order #<?php echo $order['number']; ?>  <span>for</span> $<?php echo $order['price']; ?> </h2>
<h2 class="right"> Status: <?php echo $order['status']; ?></h2>

<div class="clear"></div>
<div class="order_meta">
	Buyer: <a href="edit_user.php?id=<?php echo $buyer['id']; ?>"><?php echo $buyer['username']; ?></a> &nbsp; - &nbsp;  
    Seller: <a href="edit_user.php?id=<?php echo $seller['id']; ?>"><?php echo $seller['username']; ?></a> &nbsp; - &nbsp; 
    Service: <a href="<?php echo service_permalink($service['id']); ?>"><?php echo $service['title']; ?></a>
</div>


<div class="clear"></div>

<div class="order_items">
     	<table class="data_table">
        	<tr class="head">
            	<td class="alignleft">Item</td>
                <td width="100">Duration</td>
                <td width="100">Amount</td>
            </tr>
            <tr class="even">
            	<td class="alignleft"><?php echo $service['title']; ?></td>
                <td<?php if ($order['extra_fast_bought'] == 1) echo' class="dell_text"';?>><?php echo $service['duration']; ?> Days</td>
                <td>$<?php echo $service['price']; ?></td>
            </tr>
            <?php for ($a=1;$a<=3;$a++) {
				if ($service['extra_'.$a.'_ticked']) { 
				if ($order['extra_'.$a.'_bought'] == 1) {
				?>
            <tr>
            	<td class="alignleft">
				<strong>[Extra]</strong> <?php echo $service['extra_'.$a.'_title']; ?></td>
                <td<?php if ($order['extra_fast_bought'] == 1) echo' class="dell_text"';?>><?php echo $service['extra_'.$a.'_duration']; ?> Days</td>
                <td>$<?php echo $service['extra_'.$a.'_price']; ?></td>
            </tr>
            <?php } } } ?>
            <?php if ($service['extra_fast_ticked']) {
				if ($order['extra_fast_bought'] == 1 ) {
				 ?>
            <tr<?php if ($order['extra_fast_bought'] == 0) echo' class="pending"'; ?>>
            	<td class="alignleft"><strong>[Extra Fast]</strong> I will deliver this order in just </td>
                <td><strong><?php if ($service['extra_fast_duration'] == 0){
						 echo "No Additional Time";
				} else {
					$days = ($service['extra_fast_duration'] == 1) ? 'Day':'Days';
					echo $service['extra_fast_duration'].' '.$days;
				} ?></strong></td>
                <td><strong>$<?php echo $service['extra_fast_price']; ?></strong></td>
            </tr>
            <?php } }?>
            <tr class="even">
            	<td class="alignleft"></td>
                <td width="100"><strong>Total</strong></td>
                <td width="100"><strong>$<?php echo $order['price']; ?></strong></td>
            </tr>
            
        </table>
     </div>

<div class="message_box">
<div class="thumb">
	<a href="<?php echo user_permalink($seller['id']); ?>"><?php the_avatar($seller['id'],50); ?></a>
</div><!-- .thumb -->
<div class="info">
	<div class="user">
    	<span class="name"><a href="<?php echo user_permalink($seller['id']); ?>"><?php echo $seller['username'] ?></a></span>
    </div>
    <div class="clear"></div>
    <div class="message">Hi, please send me the following information to get started:<br><br><?php echo nl2br($service['instructions']); ?></div>
</div><!-- .info -->
<div class="clear"></div>
</div><!-- .message_box --> 

<?php 
$result  = mysql_query("SELECT * FROM `messages` WHERE `order_id` = " . $order['id']);
		while ($row = mysql_fetch_array($result)) {
			$box_class = "";
		  	include('../includes/messages/message-box.php');
	  	}
?>


</div><!-- .wrap_box -->

<?php if ($order['seller_rated'] == 1 || $order['buyer_rated'] == 1) { ?>

<div class="wrap_box edit_form_wrap">
	<h2>Order Reviews</h2>
<?php  
$get_review = mysql_query("SELECT * FROM `ratings` WHERE `order_id` = '".$order['id']."' AND `user_id` = '".$buyer['id']."'");
$row_review = mysql_fetch_array($get_review);
if (mysql_num_rows($get_review) != 0) {
  ?>
    
<div class="message_box">
<div class="thumb">
	<a href="<?php echo user_permalink($row_review['user_id']); ?>"><?php the_avatar($row_review['user_id'],50); ?></a>
</div><!-- .thumb -->
<div class="info">
	<div class="user"><a href="<?php echo user_permalink($buyer['id']); ?>"><?php echo $buyer['username'] ?></a></div>
    <div class="clear"></div>
    <div class="message">
		<div class="review_sign <?php echo $row_review['rating']; ?>"><?php echo $row_review['rating']; ?></div>
	    <div class="review_text"><?php echo stripslashes($row_review['review']); ?></div>
    <div class="clear"></div>
    </div>
</div><!-- .info -->
<div class="clear"></div>
</div><!-- .message_box --> 
<?php } ?>

<?php if ($order['seller_rated'] == 1) {
	$get_seller_review = mysql_query("SELECT * FROM `ratings` WHERE `order_id` = '".$order['id']."' AND `user_id` = '".$seller['id']."'");
$row_review_seller = mysql_fetch_array($get_seller_review);
if (mysql_num_rows($get_seller_review) != 0) {
 ?>
	
<div class="message_box">
<div class="thumb">
	<a href="<?php echo user_permalink($seller['id']); ?>"><?php the_avatar($seller['id'],50); ?></a>
</div><!-- .thumb -->
<div class="info">
	<div class="user"><a href="<?php echo user_permalink($buyer['id']); ?>"><?php echo $seller['username'] ?></a></div>
    <div class="clear"></div>
    <div class="message">
		<div class="review_sign <?php echo $row_review_seller['rating']; ?>"><?php echo $row_review_seller['rating']; ?></div>
	    <div class="review_text"><?php echo stripslashes($row_review_seller['review']); ?></div>
    <div class="clear"></div>
    </div>
</div><!-- .info -->
<div class="clear"></div>
</div><!-- .message_box --> 

<?php } ?>

<?php } ?>

</div><!-- .box -->

<?php } ?>

<?php include('footer.php'); ?>