<?php include('header.php'); ?>

<h2 class="main_title">Withdrawals</h2>
<?php
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = $set['per_page'];
	$startpoint = ($page * $limit) - $limit;
 	
	if (isset($_GET['id'])) {
		$statement = "`payment_logs` WHERE `user_id` = '".intval($_GET['id'])."' ORDER BY `log_id` DESC";
	} else {
		$statement = "`payment_logs` ORDER BY `log_id` DESC";
	}
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	confirm_query($result);
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['user_id']))
		$url .= 'user_id='. $_GET['user_id']. '&';
		
	echo pagination($statement,$limit,$page, $url);
	
 ?>

<div class="wrap_box">

<?php display_message(); ?>
<?php display_error(); ?>

	<?php if ($result_count !=0) { ?>
    <table class="form_table">
        	<tr class="head">
            	<td width="40">ID</td>
                <td width="200">User</td>
        		<td>Transaction ID</td>
                <td>Email</td>
                <td>Amount</td>
                <td>Fee</td>
                <td width="150">Method</td>
                <td width="150">Date</td>
        	</tr>
            <?php
				while ($row = mysql_fetch_array($result)) : 
				$from_user = get_user_info($row['user_id']);
			?>
            <tr>
            	<td><?php echo $row['log_id']; ?></td>
                <td><a href="edit_user.php?id=<?php echo $from_user['id']; ?>"><strong><?php echo $from_user['username']; ?></strong></a> - 
                <a href="payment-logs.php?id=<?php echo $from_user['id']; ?>"><small>View All</small></a></td>
            	<td><?php echo $row['txn_id']; ?></td>
                <td><?php echo $row['user_email']; ?></td>
                <td><strong>$<?php echo $row['amount'] ?></strong></td>
                <td><strong>$<?php echo $row['fee'] ?></strong></td>
                <td><img src="<?php echo $set['home']; ?>/img/pmt-icons/<?php echo strtolower($row['method']); ?>.png" alt="" style="width:45px;"></td>
                <td><?php datetime($row['datetime']); ?></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->

<?php echo pagination($statement,$limit,$page, $url); ?>

<?php include('footer.php'); ?>



