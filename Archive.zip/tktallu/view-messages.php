<?php include('header.php'); ?>
<?php

if (!isset($_GET['id'])) redirect('conversations.php');

$conv_id = intval($_GET['id']);

$conversation = get_conversation_info($conv_id);

$to_user = get_user_info($conversation['to_id']);
$from_user = get_user_info($conversation['from_id']);

//$this_user = get_user_info($user_id);

?>

<div class="wrap">
<?php display_error(); ?>
<?php display_message(); ?>
</div>

<div class="wrap_box edit_form_wrap">
<h2>Conversation between <a href="edit_user.php?id=<?php echo $to_user['id']; ?>"><?php echo $to_user['username']; ?></a> and <a href="edit_user.php?id=<?php echo $from_user['id']; ?>"><?php echo $from_user['username']; ?></a> <span class="right"><a href="conversations.php">Back to conversations</a></span></h2>

<?php 
$result  = mysql_query("SELECT * FROM `messages` WHERE `conv_id` = " . $conv_id);
		while ($row = mysql_fetch_array($result)) {
			$box_class = "";
		  	include('../includes/messages/message-box.php');
	  	}
?>

</div><!-- .wrap_box -->


<?php include('footer.php'); ?>