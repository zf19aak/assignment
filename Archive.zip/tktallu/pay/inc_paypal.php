<?php

function BuildHeaders($sandbox = false) {
		$headers = array(
						'X-PAYPAL-SECURITY-USERID: etallu_new_api1.paypal.com', 
						'X-PAYPAL-SECURITY-PASSWORD: 1380276719', 
						'X-PAYPAL-SECURITY-SIGNATURE: AFcWxV21C7fd0v3bYYYRCpSSRl31Av0f4QMg728SPNiUIj4D1VduGpdY', 
						'X-PAYPAL-SECURITY-VERSION: 95.0', 
						'X-PAYPAL-REQUEST-DATA-FORMAT: JSON', 
						'X-PAYPAL-RESPONSE-DATA-FORMAT: JSON', 
						'X-PAYPAL-APPLICATION-ID: APP-80W284485P519543T',
						'X-PAYPAL-DEVICE-IPADDRESS: 182.178.236.106'
						);
		
		if($sandbox){
			array_push($headers, 'X-PAYPAL-SANDBOX-EMAIL-ADDRESS: etallu_new@paypal.com');
		}
		return $headers;
}

function pay_now($Request, $sandbox=false)	{
	if ($sandbox)
	 	$url = "https://svcs.sandbox.paypal.com/AdaptivePayments/Pay";
	else
		$url = "https://svcs.sandbox.paypal.com/AdaptivePayments/Pay";
		
		$curl = curl_init();
				curl_setopt($curl, CURLOPT_VERBOSE, 1);
				curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
				curl_setopt($curl, CURLOPT_TIMEOUT, 30);
				curl_setopt($curl, CURLOPT_URL, $url);
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $Request);
				curl_setopt($curl, CURLOPT_HTTPHEADER, BuildHeaders(true));
		
		$Response = curl_exec($curl);		
		curl_close($curl);
		return $Response;
	}

?>