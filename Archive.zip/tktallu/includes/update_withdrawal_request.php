<?php
if (empty($error)):
		$update = mysql_query("UPDATE `withdrawals` SET `response_json` = '".$response_json."', `completed` = 1, `completed_time` = '".date("Y-m-d H:i:s")."' WHERE `id` = ".$pay_id);
		$paying_user = get_user_info($pay_user_id);
		$total_withdrawn = $paying_user['total_withdrawn'] + $pay_amount;
		$update = mysql_query("UPDATE `users` SET `total_withdrawn` = '".$total_withdrawn."' WHERE `id` = ".$pay_user_id);
		$new_set = $set['total_paid'] + $pay_amount;
		$update_set = mysql_query("UPDATE `options` SET `option_value` = '".$new_set."' WHERE `option_name` = 'total_paid'");
		if (confirm_query($update) && confirm_query($update) && confirm_query($update_set)) {
			$message = "Transaction of $".$pay_amount." was completed successfully!";
			add_noti("Your withdrawal of <strong>($".$pay_amount.")</strong> has been successfully completed!", $pay_user_id,'Withdrawal Completed!');
		}
endif;
?>