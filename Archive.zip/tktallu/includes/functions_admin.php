<?php
function count_users($type){
	
	if ($type == "all")	$query = "SELECT `username` FROM `users` WHERE `username` != 'admin'";
	if ($type == "active")	$query = "SELECT `username` FROM `users` WHERE `active` = 1 AND `username` != 'admin'";
	if ($type == "pending")	$query = "SELECT `username` FROM `users` WHERE `active` = 0 AND `username` != 'admin'";
	if ($type == "expired")	$query = "SELECT `username` FROM `users` WHERE `expired` = 1 AND `username` != 'admin'";
	if ($type == "Basic")	$query = "SELECT `username` FROM `users` WHERE `package` = 'Basic' AND `username` != 'admin'";
	if ($type == "Golden")	$query = "SELECT `username` FROM `users` WHERE `package` = 'Golden' AND `username` != 'admin'";
	if ($type == "Ultimate")	$query = "SELECT `username` FROM `users` WHERE `package` = 'Ultimate' AND `username` != 'admin'";
	if ($type == "email_pending")	$query = "SELECT `username` FROM `users` WHERE `email_verified` = 0 AND `username` != 'admin'";
	
	$result = mysql_query($query);
	return mysql_num_rows($result);
}

function count_withdrawals($type){
  	
	if ($type == "all") $query = "SELECT `id` FROM `withdrawals`";	
	if ($type == "pending") $query = "SELECT `id` FROM `withdrawals` WHERE `completed` = '0'";
	if ($type == "completed") $query = "SELECT `id` FROM `withdrawals` WHERE `completed` = '1'";
	
	$result = mysql_query($query);
	return mysql_num_rows($result);
}

function print_json($json) {
	$get = json_decode($json,true);
	echo "<pre>";
	print_r($get);
	echo "</pre>";	
}

function users_by_date($year,$month=false,$day=false) {
	
	$sql = "SELECT COUNT(id) as `stat_count` FROM `users` WHERE YEAR(signup_date) = ".intval($year);
	if ($month) $sql .= " AND MONTH(signup_date) = ".intval($month);
	if ($day) $sql .= " AND DAY(signup_date) = ".intval($day);
	
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	return $row['stat_count'];
	
}

?>