<?php include('header.php'); 
 

if (isset($_GET['del'])) {
	$del_id = intval($_GET['del']);
	$query = mysql_query("DELETE FROM `categories` WHERE `id` = " .$del_id);
	if (confirm_query($query)){
		$message = "Successfully Deleted!";
	}
}

// Edit Car
if (isset($_POST['update_cat'])) :

$id = intval($_GET['edit']);

$name = mres($_POST['name']);
$description = mres($_POST['description']);
$position = mres($_POST['position']);
$parent = mres($_POST['parent']);
$slug = mres($_POST['slug']);

$query = mysql_query("UPDATE `categories` SET
	`name` = '".$name."',
	`description` = '".$description."',
	`position` = '".$position."',
	`parent` = '".$parent."',
	`slug` = '".$slug."'
 WHERE `id` = " . $id);

if ($query) {
		$message = "Category Updated!";
	} else {
		$error[] = "Error: ". mysql_error();	
	}

endif;

// Add new
if (isset($_POST['add_cat'])) :

$name = mres($_POST['name']);
$description = mres($_POST['description']);
$position = mres($_POST['position']);
$parent = mres($_POST['parent']);

if (empty($error)) {
	
	$query = mysql_query("INSERT INTO `categories` (
		`name`,
		`description`,
		`position`,
		`parent`
		) VALUES (
		'".$name."',
		'".$description."',
		'".$position."',
		'".$parent."'
		)");
	
	if ($query) {
		$message = "Category Added!";
	} else {
		$error[] = "Error: ". mysql_error();	
	}
		
}

endif;

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = $set['per_page'];
	$startpoint = ($page * $limit) - $limit;
 	
	$sort_by = isset($_GET['sort_by'])? mres($_GET['sort_by']) : $sort_by = "id";
	$sort = isset($_GET['sort'])? mres($_GET['sort']) : $sort = "ASC";
	

	$statement = "`categories` WHERE `parent` = '0' ORDER BY `position` ".$sort;
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['user_id']))
		$url .= 'user_id='. $_GET['user_id']. '&';
		
	echo pagination($statement,$limit,$page, $url);

?>

<h2 class="main_title">Notifications</h2>

<?php
if (isset($_GET['edit'])) :

$id = intval($_GET['edit']);
$edit_cat = get_category_info($id);

?>

<div class="wrap_box edit_form_wrap add_cat_wrap">
<form method="post" action="categories.php?edit=<?php echo $id; ?>">
	Parent: 
	<select name="parent">
    <option value="0">No Parent</option>	
    <?php 
		$cat_query = mysql_query("SELECT * FROM `categories` WHERE `parent` = '0'");
		$cat_count = mysql_num_rows($cat_query);
		while ($cat_row = mysql_fetch_array($cat_query)) {
			if ($edit_cat['parent'] == $cat_row['id']) {
			 	$cat_selected = "selected='selected'";
			} else {
				$cat_selected = "";
			}
			echo "<option value='".$cat_row['id']."' ".$cat_selected.">".$cat_row['name']."</option>";
		}
	?>
    </select>
    Name:	<input type="text" name="name" value="<?php echo $edit_cat['name']; ?>" placeholder="Name">
    Description: <input type="text" name="description" value="<?php echo $edit_cat['description']; ?>" placeholder="Description"> <br>
    Slug: <input type="text" name="slug" value="<?php echo $edit_cat['slug']; ?>" placeholder="Slug">
    Position: <input type="text" name="position" value="<?php echo $edit_cat['position']; ?>" style="width:80px" placeholder="Position">
    <input type="submit" value="Update" name="update_cat">
</form>
</div><!-- .wrap_box -->

<?php else : ?>

<div class="wrap_box edit_form_wrap add_cat_wrap">
<form method="post" action="categories.php">
	Parent: 
	<select name="parent">
    <option value="0">No Parent</option>
    <?php 
		$cat_query = mysql_query("SELECT * FROM `categories` WHERE `parent` = '0'");
		$cat_count = mysql_num_rows($cat_query);
		while ($cat_row = mysql_fetch_array($cat_query)) {
			echo "<option value='".$cat_row['id']."'>".$cat_row['name']."</option>";
		}
	?>
    </select>
	<input type="text" name="name" placeholder="Name">
    <input type="text" name="description" placeholder="Description">
    <input type="text" name="position" value="" style="width:80px" placeholder="Position">
    <input type="submit" value="Add" name="add_cat">
</form>
</div><!-- .wrap_box -->

<?php endif;  ?>

<div class="wrap_box edit_form_wrap">

<?php display_error(); display_message(); ?>

	<?php if ($result_count !=0) { ?>
    <table class="form_table">
        	<tr class="head">
                <td class="alignleft">Name</td>
        		<td  class="alignleft">Description</td>
                <td width="100"></td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
			?>
            <tr class="odd" >
                <td><strong><?php echo $row['name']; ?></strong> | <?php echo $row['slug']; ?></td>
            	<td class="alignleft"><?php echo $row['description']; ?></td>
                <td><a href="categories.php?edit=<?php echo $row['id']; ?>">Edit</a> | 
                <a href="categories.php?del=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to delete?')" class="del_link">Delete</a></td>
            </tr>
            <?php 
				$child_count = 1;
				$child_query = mysql_query("SELECT * FROM `categories` WHERE `parent` = " . $row['id']);
				while ($child_row = mysql_fetch_array($child_query)) { 
				?>
            <tr class="child">
                <td> &nbsp; -  &nbsp;<?php echo $child_row['name']; ?> | <?php echo $child_row['slug']; ?></td>
            	<td class="alignleft"><?php echo $child_row['description']; ?></td>
                <td><a href="categories.php?edit=<?php echo $child_row['id']; ?>">Edit</a> | 
                <a href="categories.php?del=<?php echo $child_row['id']; ?>" onClick="return confirm('Are you sure you want to delete?')" class="del_link">Delete</a></td>
            </tr>
            <?php $child_count++; } ?>
            
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->

<?php echo pagination($statement,$limit,$page, $url); ?>
<?php include('footer.php'); ?>