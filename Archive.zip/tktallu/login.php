<?php include_once('../includes/connection.php'); ?>
<?php include_once('../includes/functions.php'); ?>
<?php

if (isset($_SESSION['admin_failded_login'])) {
	if ($_SESSION['admin_failded_login'] >= 2) {
	require_once('../includes/recaptcha_process.php');
	}
}

	if (isset($_POST['login_submit']) && empty($error)) {
		
		$username = mres($_POST['username']);
		$password = mres($_POST['password']);
		$hashed_password = md5($password);
		
		$query = "SELECT * FROM `users` WHERE `username` = '".$username."' AND `password` = '".sha1($password)."' AND `role` = 'admin'";	
		$query_result = mysql_query($query);
		confirm_query($query_result);
		
		if ( mysql_num_rows($query_result) == 1){
			$_SESSION['admin_login'] = $username;
			unset($_SESSION['admin_failded_login']);
			redirect('index.php');
			
		} else {
			$error[] = "<strong>Warning:</strong> Wrong username or password!";
			
			if (!isset($_SESSION['admin_failded_login'])){
				$_SESSION['admin_failded_login'] = 0;
			}
			
			if (isset($_SESSION['admin_failded_login'])){
				$_SESSION['admin_failded_login'] = $_SESSION['admin_failded_login'] + 1;
				if ($_SESSION['admin_failded_login'] >= 2) {
					require_once('../includes/recaptcha_process.php');
				} 
			}
			
		}
		
	}
	
	if (isset($_GET['error'])){
		$error[] = "You need to login in order to access this page.";	
	}
	
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link href="css/admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php if (isset($_SESSION['admin_failded_login'])) { if ($_SESSION['admin_failded_login'] >= 2) { ?>
<script type="text/javascript">
 var RecaptchaOptions = {
    theme : 'white'
 };
 </script>
<?php } }?> 

<table style="width:100%; height:100%;">
	<tr>
		<td>
        <div class="login_box">	
        <?php display_error(); ?>
        
            <form action="login.php" method="post">
            <table class="form_table admin_login_table">
            	<tr>
                	<td></td>
                    <td><h1>Login</h1></td>
                </tr>
            	<tr>
            		<td>Email:</td>
                    <td ><input type="text" name="username"></td>
            	</tr>
                <tr>
                	<td class="field_td">Password:</td>
                    <td><input type="password" name="password"></td>
                </tr>
                <?php if (isset($_SESSION['admin_failded_login'])) { if ($_SESSION['admin_failded_login'] >= 2) { ?>
	            <tr>
                	<td></td>
	            	<td><?php echo recaptcha_get_html($publickey, $error_captcha); ?></td>
	            </tr>
            	<?php } } ?>
                <tr>
                	<td></td>
                    <td><input type="submit" name="login_submit" value="Login"></td>
                </tr>
                <tr>
                	<td></td>
                	<td style="font-size:12px;"><br> Your IP address will be saved!. </td>
                </tr>
             </table>
             </form>
        </div><!-- .login_box -->
        </td>
	</tr>
</table>
<?php include('footer.php'); ?>