<?php 
include('header.php');

$id = intval($_GET['id']);
$service = get_service_info($id);
$service_user = get_user_info($service['user_id']);

if (isset($_POST['edit_submit'])) { 

$user = get_loggedin_info();

$title = mres($_POST['title']);


$category = mres($_POST['category']);
if ($category != '5' && $category != 0) $sub_category = mres($_POST['sub_category']);
$description = mres($_POST['description']);
$tags = mres($_POST['tags']);
$instructions = mres($_POST['instructions']);

$is_mod_required = mres($_POST['is_mod_required']);
$required_modification_msg = mres($_POST['required_modification_msg']);

if ($is_mod_required == 'Yes' && $service['status'] != 'Requires Modification') { 
	
		$this_service = get_service_info($id);
		
		$noti_desc = 'Your service "'.$service['title'].'" requires some modification before going to live.';
  	    $noti_url = $set['home'] . '/my-services/';
  	    $to_id = $service_user['id'];
  	    add_noti($noti_desc,$to_id,$noti_url,'Modification Required!');
	
}

if ($is_mod_required == 'Yes'){
	$status = "Requires Modification";
} else {
	$status = $service['status'];
}
	

	if ($title == '') $error[] = "Title field is required";
	if (strlen($title) < 20 && $title != '') $error[] = "Title is too short! Minimum length is 20 characters";
	if (strlen($title) > 80) $error[] = "Title is too long! Maximum length is 80 characters";
	
	if ($category == 0) $error[] = "Please select a category";
	if ($category != '5' && $category != 0 && $sub_category == 0) $error[] = "Please select a sub category";
	
	if ($description == '') $error[] = "Description is required!";
	if (strlen($description) < 80 && $description != '') $error[] = "Description is too short! Minimum length is 80 characters";
	if (strlen($description) > 1200) $error[] = "Description is too long! Maximum length is 1200 characters";
	
	$total_tags = explode(',',$tags);
	if (count($total_tags) < 3 && $tags != '') $error[] = "Minimum 3 tags are required.";
	
	if ($instructions == '') $error[] = "Instructions for buyer is required!";
	if (strlen($instructions) > 500) $error[] = "instructions is too long! Maximum length is 500 characters";
	
	// Image Processing
	
	$image_name = $_FILES["image"]["name"];
	$image_type = $_FILES["image"]["type"];
	
	$arr = explode(".", $image_name);
    $image_extension = strtolower(array_pop($arr));   
    
	if ($_FILES["image"]["error"] != 4) {
	
	$image_location = '../uploads/service-imgs/';
			
		if ((($image_type == "image/gif") || ($image_type == "image/jpeg") || ($image_type == "image/png") || ($image_type == "image/pjpeg"))) {
	
	  		if ($_FILES["image"]["error"] > 0) {
	    		$error[] = "Return Code: " . $_FILES["image"]["error"] . "<br>";
	    	} else {
				
				$storeimage =  $user['id'].'-service-img-' . substr(md5(date("ymdhis")),0,10);
				
				$image_info = getimagesize($_FILES["image"]["tmp_name"]);
				$image_width = $image_info[0];
				$image_height = $image_info[1];
  				
				if ($image_width < 640 || $image_height < 400) $error[] = "Minimum image size is 600 x 450 pixels";
				
				if ($image_width <= 640 && $image_height <= 400) {
					
					if (empty($error)) {
						// If file exists delete first.	
						$old_image = $image_location.$service['image'];
						if (file_exists($old_image) && !empty($service['image'])) {
							unlink($old_image);
						}
						move_uploaded_file($_FILES["image"]["tmp_name"], $image_location . $storeimage .'.'. $image_extension);
					}
					
				} else {
				
				// If file exists delete first.	
				  $old_image = $image_location.$service['image'];
				  if (file_exists($old_image) && !empty($service['image'])) {
					  unlink($old_image);
				  }
				
				include('../includes/class.upload.php');
			
				$foo = new Upload($_FILES["image"]);
				if ($foo->uploaded) {

				  $foo->file_new_name_body = $storeimage;
				  $foo->image_resize = true;
				  $foo->image_ratio_crop = true;
				  $foo->image_x = 640;
				  $foo->image_y = 400;
				  $foo->Process($image_location);
				  if ($foo->processed) {
				    $foo->Clean();
				  } else {
				    $error[] = 'error : ' . $foo->error;
				  }
				}

				
				}
				
		    }
	  
		} else {
		  $error[] = "Invalid file";
		}
  
  } else { // image is not selected
	$storeimage = false;
  }

if ($storeimage != false){
	$image = $storeimage .'.'. $image_extension;
} else {
	$image = $service['image'];
}
	
	// END Image Processing

if (!isset($sub_category)) $sub_category = 0;
	
if (empty($error)) {
	$query = mysql_query("UPDATE `services` SET 
	`title` = '".$title."',
	`cat_id` = '".$category."',
	`sub_cat_id` = '".$sub_category."',
	`description` = '".$description."',
	`tags` = '".$tags."',
	`instructions` = '".$instructions."',
	`image` = '".$image."',
	`status` = '".$status."',
	`required_modification_msg` = '".$required_modification_msg."' 
	WHERE `id` = " . $id);
	
	if ($query){
		$message = "Service Updated!";
		$service = get_service_info($id);
	} else {
		$error[] = "Error updating database" . mysql_error();
	}
	
}

} // if form submit


?>
<h2 class="main_title">Manage Settings</h2>

<div class="wrap_box edit_form_wrap">

<?php display_error(); ?>
<?php display_message(); ?>

<div class="form_box">


    	<h2>Edit Service</h2>

  		<form action="edit-service.php?id=<?php echo $service['id']; ?>" method="post" enctype="multipart/form-data">
        <table class="form_table">
           <tr>
            	<td class="label" width="150">User:</td>
                <td><a href="edit_user.php?id=<?php echo $service_user['id']; ?>"><strong><?php echo $service_user['username']; ?></strong></a> 
                <a href="services.php?user_id=<?php echo $service_user['id']; ?>">View All Services</a>
                </td>
            </tr>
            <tr>
        		<td class="label">Status:</td>
                <td class="field"><?php echo $service['status']; ?></td>
        	</tr>
        	<tr>
        		<td class="label">Sales:</td>
                <td class="field"><?php echo $service['sales']; ?></td>
        	</tr>
            <tr>
        		<td class="label">Rating:</td>
                <td class="field"><?php echo $service['rating']; ?>%</td>
        	</tr>
            <tr>
        		<td class="label">Created:</td>
                <td class="field"><?php echo ago($service['datetime']); ?></td>
        	</tr>
        
            <tr>
  				<td class="label">Title:</td>
                <td class="field">
                     <input type="text" class="required input_title" name="title"  value="<?php echo $service['title']; ?>" placeholder="do...">
                     for  <strong>$<?php echo $service['price']; ?></strong> in <strong><?php echo $service['duration']; ?></strong> Days
                </td>
  			</tr>
            <tr>
  				<td class="label">Category:</td>
                <td class="field">
                     <select class="half_select choose_cat" name="category">
                     	<option value="0">Select a Category</option>
                     <?php 
					 	
						$cat_id = $service['cat_id'];
						
						isset($category) ? $cat_id = $category : $cat_id = $service['cat_id'];
					 	
					 	$cat_query = mysql_query("SELECT `id`,`name` FROM `categories` WHERE `parent` = 0 ORDER BY `position` ASC"); 
						while ($cat_row = mysql_fetch_array($cat_query)) {
							
							if ($cat_row['id'] == $cat_id) {
								$add_selected = ' selected="selected"';
								if ($cat_row['id'] != 5) $show_child_cat = $cat_id;
							} else {
								$add_selected = '';
							}	
							echo "<option value='".$cat_row['id']."'".$add_selected.">".$cat_row['name']."</option> \n";
						}?>
                     </select> 
                     <span class="cat_loading">Loading...</span>
                     <span class="sub_cat_wrap">
                     	<?php
						
						
						
						 if (isset($show_child_cat)) {
							 
							$sub_cat_id = $service['sub_cat_id'];
							isset($sub_category) ? $sub_cat_id = $sub_category : $sub_cat_id = $service['sub_cat_id'];
							 
							$query = mysql_query("SELECT `id`,`name` FROM `categories` WHERE `parent` = '" . $show_child_cat . "' ORDER BY `position` ASC");
							$output ='<select class="half_select required" name="sub_category">';
							$output .= '<option value="0">Select a Sub Category</option>';
								while ($sub_cat_row = mysql_fetch_array($query)) {
								
								if ($service['sub_cat_id'] == $sub_cat_row['id']) {
									$add_selected = ' selected="selected"';
								} else {
									$add_selected = '';	
								}
								
								$output .= '<option value="'.$sub_cat_row['id'].'"'.$add_selected.'>'.$sub_cat_row['name'].'</option>';
								}
							$output .= '</select>';
							echo $output;
							 } ?>
                     </span>
                </td>
  			</tr>
            <tr>
  				<td class="label">Description:</td>
                <td class="field">
                     <textarea cols="20" rows="6" name="description"><?php  echo stripslashes($service['description']); ?></textarea>
                </td>
  			</tr>
            <tr>
  				<td class="label">Tags:</td>
                <td class="field">
                     <input type="text" name="tags" value="<?php  echo stripslashes($service['tags']); ?>">
                </td>
  			</tr>
            
            <tr>
  				<td class="label">Instructions <br> for buyer:</td>
                <td class="field">
                     <textarea cols="20" rows="2" name="instructions"><?php echo stripslashes($service['instructions']); ?></textarea>
                </td>
  			</tr>
            <tr>
              <td class="label"></td>
              <td class="field">
              	<img src="<?php echo img($set['home'] . '/uploads/service-imgs/'.$service['image'],572); ?>" alt="" />
              </td>
            </tr>
            <tr>
  				<td class="label">Change Image:</td>
                <td class="field">
                     <input type="file" class="image" name="image" />
                </td>
  			</tr>
            <tr>
            	<td class="label">Required Modification?</td>
                <td>
                	<input type="radio" name="is_mod_required" <?php if ($service['status'] != 'Modification Required') echo 'checked'; ?> value="No" /> No &nbsp;
                    <input type="radio" name="is_mod_required" <?php if ($service['status'] == 'Modification Required') echo 'checked'; ?> value="Yes" /> Yes &nbsp;
                </td>
            </tr>
            <tr>
            	<td class="label">Modification Notes?</td>
            	<td><textarea name="required_modification_msg"><?php echo $service['required_modification_msg']; ?></textarea></td>
            </tr>
            <tr>
            	<td></td>
  				<td class="submit_row"><input type="submit" name="edit_submit" value="Update Service" /></td>
  			</tr>
  		</table>
        </form> 
         <div class="clear"></div>
        

</div><!-- .form_box -->
</div><!-- .wrap_box -->

<?php include('footer.php'); ?>