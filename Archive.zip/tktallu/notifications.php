<?php 
include('header.php'); 

if (isset($_GET['del'])) {
	$del_id = intval($_GET['del']);
	$query = mysql_query("DELETE FROM `notifications` WHERE `id` = " .$del_id);
	if (confirm_query($query)){
		$message = "Successfully Deleted!";
	}
}

if (isset($_POST['bulk_submit'])) {
	
	if (isset($_POST['edit_check'])) {
		$update_value = $_POST['edit_check'];
		$in_id = "('" . implode( "','", $update_value ) . "');" ;
		$all_result = mysql_query("DELETE FROM `notifications` WHERE `id` IN $in_id");
		if (confirm_query($all_result)){
			$message = "Successfully Updated!";
		}
		
	} else { 
	
		$error[] = "No no records are selected";
		
	}
}


?>

<h2 class="main_title">Notifications</h2>

<?php

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = $set['per_page'];
	$startpoint = ($page * $limit) - $limit;
 	
	if (isset($_GET['sort_by'])) $sort_by = mres($_GET['sort_by']); else  $sort_by = "id";
	if (isset($_GET['sort'])) $sort = mres($_GET['sort']); else  $sort = "DESC";
	
	if (isset($_GET['id'])) {
		$from_user = get_user_info(intval($_GET['id']));
		$statement = "`notifications` WHERE `user_id` = '".$from_user['id']."' ORDER BY `".$sort_by."` ".$sort;
	} else {
		$statement = "`notifications` ORDER BY `".$sort_by."` ".$sort;
	}
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['user_id']))
		$url .= 'user_id='. $_GET['user_id']. '&';
		
	echo pagination($statement,$limit,$page, $url);
	
 ?>

<div class="wrap_box">

<?php display_error(); display_message(); ?>

<form action="notifications.php<?php echo isset($_GET['id']) ? '?id='.$_GET['id'] : ''; ?>" method="post">

<div class="all_actions_wrap">
	
    Action for all:
    <input type="submit" name="bulk_submit" value="Delete All">
    
</div><!-- .all_actions_wrap -->

	<?php if ($result_count !=0) { ?>
    <table class="form_table">
        	<tr class="head">
            	<td width="40"><input type="checkbox" class="check_all" ></td>
                <td width="200">User</td>
        		<td  class="alignleft">Description</td>
                <td width="150">Date</td>
                <td></td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
				$from_user = get_user_info($row['user_id']);
			?>
            <tr class="<?php if($count%2) echo "even"; else echo "odd"; ?> ">
            	<td><input name="edit_check[]" type="checkbox" class="edit_check" value="<?php echo $row['id']; ?>"></td>
                <td><a href="edit_user.php?id=<?php echo $from_user['id']; ?>"><strong><?php echo $from_user['username']; ?></strong></a> - 
                <a href="notifications.php?id=<?php echo $from_user['id']; ?>"><small>View All</small></a></td>
            	<td class="alignleft"><?php echo $row['description']; ?></td>
                <td><?php datetime($row['datetime']); ?></td>
                <td><a href="notifications.php?del=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to deelte?')" class="del_link">Delete</a></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->
</form>
<?php echo pagination($statement,$limit,$page, $url); ?>

<?php include('footer.php'); ?>



