<?php 
include('header.php');
if (isset($_POST['save_submit'])):

$post=array_map("filter_data",$_POST);
	
	foreach($post as $k=>$v) {
		$v = mres($v);
		$set_sql = "UPDATE `options` SET option_value='{$v}' WHERE `option_name` ='" . $k  . "' LIMIT 1";
		$set_result = mysql_query($set_sql);
		if (!$set_result) { 
			echo "ERROR updating options Where value: " . $v . " = " . $k . "<br />" . mysql_error() . "<br /> <br />";
		} else {
			$message = "Settings Updated";	
		}
	$set[$k] = $v;
	}
		
	$do->refresh_sess();
	
endif;
?>
<h2 class="main_title">Manage Settings</h2>

<div class="wrap_box edit_form_wrap">

<?php display_error(); ?>
<?php display_message(); ?>

<div class="form_box">

	<form action="settings.php" method="post">
    <table class="form_table edit_form">
    		<tr>
  				<td class="label">Website Name:</td>
                <td class="field"><input type="text" name="name" value="<?php echo $set['name']; ?>" /></td>
                <td class="label">Website URL:</td>
                <td class="field"><input type="text" name="home" value="<?php echo $set['home']; ?>" /></td>
  			</tr>
            <tr>
  				<td class="label">Main Email:</td>
                <td class="field"><input type="text" name="email" value="<?php echo $set['email']; ?>" /></td>
                <td class="label">Paypal Email:</td>
                <td class="field"><input type="text" name="paypal_email" value="<?php echo $set['paypal_email']; ?>" /></td>
  			</tr>
            <tr>
              	<td class="label">Meta Keywords:</td>
                <td class="field"><textarea name="meta_keywords"><?php echo $set['meta_keywords']; ?></textarea></td>
  				<td class="label">Meta Description:</td>
                <td class="field"><textarea name="meta_desc"><?php echo $set['meta_desc']; ?></textarea></td>
  			</tr>
            <tr>
              	<td class="label">Main Notice:</td>
                <td class="field" colspan="3"><textarea name="main_notice" style="width:761px;"><?php echo $set['main_notice']; ?></textarea></td>
  			</tr>
            <tr>
              	<td class="label">Recaptcha <br> Public Key:</td>
                <td class="field"><input type="text" name="recaptcha_public_key" value="<?php echo $set['recaptcha_public_key']; ?>" /></td>
  				<td class="label">Recaptcha <br> Private Key:</td>
                <td class="field"><input type="text" name="recaptcha_private_key" value="<?php echo $set['recaptcha_private_key']; ?>" /></td>
  			</tr>
            <tr>
              	<td class="label">Enable Captcha <br> on Sign Up page </td>
                <td class="field">No <input type="radio" <?php if ($set['signup_captcha'] == 0) echo 'checked'; ?>  name="signup_captcha" value="0"> 
                	Yes <input type="radio" <?php if ($set['signup_captcha'] == 1) echo 'checked'; ?> name="signup_captcha" value="1"></td>
  				<td class="label">Withdrawal <br> Days Limit</td>
                <td class="field"><input type="text" name="withdraw_after_days" value="<?php echo $set['withdraw_after_days']; ?>" /></td>
  			</tr>
            <tr>
            	<td class="label"></td>
                <td class="field"></td>
	    		<td class="label">Minimum Withdrawal:</td>
                <td class="field"><input type="text" name="minimum_withdrawal" value="<?php echo $set['minimum_withdrawal']; ?>" /></td>
	    	</tr>
            <tr>
            	<td class="label"></td>
                <td class="field"></td>
	    		<td class="label"></td>
	            <td class="field"><input type="submit" name="save_submit" value="Save Settings"></td>
	    	</tr>
  		</table>
     </form>
    
</div><!-- .form_box -->
</div><!-- .wrap_box -->

<?php include('footer.php'); ?>



