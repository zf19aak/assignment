<?php include('header.php'); ?>
<?php
	
	if ( isset($_GET['del'])) {
		
		$del_id = intval($_GET['del']);
		$get_user = get_user_info($del_id);
		
		if ($get_user['avatar'] != ''){
			unlink('../uploads/avatars/'.$get_user['avatar']);
		}
		
		$check_topics = mysql_query("SELECT * FROM `forum_topics` WHERE `user_id` = ".$del_id);
		if (mysql_num_rows($check_topics) > 0) {
			while ($row = mysql_fetch_array($check_topics)) {
				mysql_query("DELETE FROM `forum_replies` WHERE `topic_id` = ". $row['id']);
			}
		}

		$del_topics = mysql_query("DELETE FROM `forum_topics` WHERE `user_id` = ". $del_id);		
		$del_replies = mysql_query("DELETE FROM `forum_replies` WHERE `user_id` = ". $del_id);
		$del_withdrawals = mysql_query("DELETE FROM `withdrawals` WHERE `user_id` = ". $del_id);
		
		$del_noti = mysql_query("DELETE FROM `notifications` WHERE `user_id` = ". $del_id);
		$del_user = mysql_query("DELETE FROM `users` WHERE `id` = ". $del_id);
		$del_payment_logs = mysql_query("DELETE FROM `payment_logs` WHERE `user_id` = ". $del_id);
		
		if (confirm_query($del_topics) && confirm_query($del_replies) && confirm_query($del_noti) && confirm_query($del_user) && confirm_query($del_withdrawals) && confirm_query($del_payment_logs)) {
			$message = "Successfully Deleted!";
		} else {
			$error[] = "Error Deleting a user";
		}
		
			
	}

?>
<h2 class="main_title">Manage Users</h2>

<div class="box">
	
    <div class="left sort_links">
    <a href="users.php">All <span>(<?php echo count_users('all'); ?>)</span></a> | 
    <a href="users.php?search_by=email_verified&search_term=0">Email Pending <span>(<?php echo count_users('email_pending'); ?>)</span></a>
    </div>
    <div class="right">
    <form action="users.php" method="get">
    <?php
		if ( isset($_GET['search_by']) && ( $_GET['search_by'] == 'username' || $_GET['search_by'] == 'email')  ) {
			$search_value = $_GET['search_term'];
		} else {
			$search_value = '';
		}
		
	?>
    <input type="text" name="search_term" value="<?php echo $search_value; ?>">
    <select name="search_by" style="width:140px">
    	<?php if ( isset($_GET['search_by']) && ( $_GET['search_by'] == 'username')  ) { ?>
        	<option value="username">Username</option>
        	<option value="email">Email</option>
        <?php } elseif ( isset($_GET['search_by']) && ( $_GET['search_by'] == 'email')  ) { ?>
        	<option value="email">Email</option>
            <option value="username">Username</option>
        <?php } else { ?>
	    	<option value="username">Username</option>
	        <option value="email">Email</option>
        <?php } ?>
    </select>
    <input type="submit" value="Search">
    </form>
    </div>
    <div class="clear"></div>
</div><!-- .box -->



<?php

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = $set['per_page'];
	$startpoint = ($page * $limit) - $limit;
 	
	if (isset($_GET['sort_by'])) $sort_by = mres($_GET['sort_by']); else  $sort_by = "id";
	if (isset($_GET['sort'])) $sort = mres($_GET['sort']); else  $sort = "DESC";
	
	if (isset($_GET['search_by']) && isset($_GET['search_term'])) {
		$statement = "`users` WHERE `".mres($_GET['search_by'])."` = '".mres($_GET['search_term'])."' AND `id` != 2 ORDER BY `".$sort_by."` ".$sort;
	} else {
		$statement = "`users` WHERE `id` != 2 ORDER BY `".$sort_by."` ".$sort;
	}
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	confirm_query($result);
	$result_count = mysql_num_rows($result);
	$count = 1;
	
		$url = '?';
	if (isset($_GET['sort']))
		$url .= 'sort='. $_GET['sort']. '&';
	if (isset($_GET['sort_by']))
		$url .= 'sort_by='. $_GET['sort_by']. '&';
	if (isset($_GET['search_term']) && isset($_GET['search_by']))
		$url .= 'search_by='. $_GET['search_by']. '&search_term='. $_GET['search_term'].'&';
		
	echo pagination($statement,$limit,$page, $url);
	
 ?>

<div class="wrap_box">

<?php display_error(); ?>
<?php display_message(); ?>

	<?php if ($result_count !=0) { ?>
    <table class="form_table">
    	<tr class="head">
    		<td width="40">ID <a href="users.php?sort_by=user_id&sort=DESC" class="sort_desc"></a> <a href="users.php?sort_by=user_id&sort=ASC" class="sort_asc"></a></td>
            <td width="130">Username</td>
            <td width="180">Email</td>
            <td>Balance <a href="users.php?sort_by=balance&sort=DESC" class="sort_desc"></a> <a href="users.php?sort_by=balance&sort=ASC" class="sort_asc"></a></td>
            <td>Joined</td>
            <td width="90"></td>
    	</tr>
        <?php
			 $count = 0;
		 	while($row = mysql_fetch_array($result)) : ?>
        <tr class="<?php if($count%2) echo "odd"; else echo "even" ?> <?php if($row['email_verified'] == 0) echo "pending"; ?>">
        	<td align="center"><a href="edit_user.php?id=<?php echo $row['user_id']; ?>"><?php echo $row['id']; ?></a></td>
            <td><?php the_flag($row['last_ip'],1); ?> &nbsp;<a href="edit_user.php?id=<?php echo $row['id']; ?>"><?php echo $row['username']; ?></a> 
            <?php if ($row['email_verified'] == 1) { ?>
            <span class="email_verified" title="Email Verified">&#10004;</span>
            <?php } ?>
            </td>
            <td><a href="edit_user.php?id=<?php echo $row['id']; ?>"><?php echo $row['email']; ?></a></td>
            <td>$<?php echo $row['balance']; ?></td>
            <td><?php datetime($row['signup_date']); ?></td>
            <td><a href="edit_user.php?id=<?php echo $row['id']; ?>">Edit</a> | <a href="users.php?del=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to deelte this user?')" class="del_link">Delete</a></td>
        </tr>
        <?php
		 $count++;
		 endwhile;
		 ?>
    </table>
    <?php } else { ?>
    	<p>No results are found.</p>
    <?php } ?>
    
</div><!-- .wrap_box -->

<?php echo pagination($statement,$limit,$page, $url); ?>

<?php include('footer.php'); ?>



