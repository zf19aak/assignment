<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
check_login();
$page_title = "Please verify your email address";
$email_verify_page = true;
$user = get_loggedin_info();
if ($user['email_verified'] == 1) redirect($set['home'].'/account/');

if (isset($_POST['form_submit'])) {
	
	$new_email = mres($_POST['new_email']);
	
	if ($new_email == '') $error[] = "New email field cannot be empty.";
		
	$check = mysql_query("SELECT `email` FROM `users` WHERE `email` = '".$new_email."'");
	if (mysql_num_rows($check) == 1) {
		 $error[] = "Sorry, That email address is already exist. Please try another one.";
	}
		
	if (empty($error)) {

		$new_code = email_verify_code($user['username']);
		$result = mysql_query("UPDATE `users` SET `email` = '".$new_email."', `email_verify_code` = '".mres($new_code)."' WHERE `id` = " . $user['id']);
		send_email_verification($user['id']);
		
		if (confirm_query($result)) {
			
			$message = "<strong>DONE!</strong> New email saved and verification email sent!";
		}
		
	} else {
		$show_table = true;	
	}
	
} 

if (isset($_GET['resend'])) {
	
	send_email_verification($user['id']);
	$message = "<strong>DONE!</strong> Verification email has been sent again!";
	
}
	
if (empty($error)) $error[] = '<strong>NOTE:</strong> Your email address is not confirmed yet. Please confirm your email address to continue using.' . $set['name'];
include('header.php'); 
//if ($user['email_verified'] == 1) $error[] = redirect($set['home'] . '/account/');

?>

<div class="mid_box email_verify_box">

<?php display_message(); display_error();  ?>
    
    <div class="box">

         <p>A confirmation email has been sent to the email address <strong><?php echo $user['email']; ?></strong>. Please click on the link in the email to confirm your email address.</p>
         <div class="display_notice no_method">If you didn't receive our email within a few minutes, please check your <strong>bulk</strong> or <strong>spam</strong> email folders.</div>
         
         <p>If the confirmation email did not arrive or you deleted it, <a href="<?php echo $set['home']; ?>/verify-email/?resend">click here to resend</a>.</p>
         
                  <p>If you would like to have the verification email sent to a different email address than the one associated with this account, please <a class="show_reset_email">click here</a> and enter it in the form provided. Please note that the email address you submit below will replace for this account.</p>
         <form action="<?php echo $set['home']; ?>/verify-email/" id="validate" method="post">
         <table class="activate_form set_new_email_table<?php if (isset($show_table)) echo " show_email_table"; ?>">
            <tr class="email_resend_field">
  				<td class="label"><input type="email" name="new_email" class="required" value="<?php if (isset($new_email)) echo $new_email; ?>" placeholder="New Email Address for Verification" /></td>
                <td class="field">
                     <input type="submit" value="Send" name="form_submit" />
                </td>
  			</tr>
  		</table>
        </form>
         
         <p>If you are having any other issues, please contact <a href="<?php echo $set['home']; ?>/support/">support</a></p>
         
</div><!-- .box -->
	    
</div><!-- .activate_box -->

<div class="clear"></div>

<?php include('footer.php');  ?>    