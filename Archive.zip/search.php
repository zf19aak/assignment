<?php
require_once('includes/connection.php');
require_once('includes/functions.php');

$search_query = mres($_GET['query']);

if (isset($_GET['tag']))
	$is_tag = 'true';
 else 
	$is_tag = 'false';


if ($is_tag == 'true')
	$page_title = ucwords($search_query) . " Related Services"; 		
 else
	$page_title = "Search Results for " . $search_query;


$this_search_page = true;
include('header.php'); 
display_message(); display_error();
?>
  <h2 class="services_heading">
  	<?php
	if ($is_tag == 'true') {
		echo "<strong>".ucwords($search_query)."</strong> Related Services";
	} else {
		echo "Search results for '".$search_query."'";	
	}
	?>
  	
  </h2>
	
   <?php 
   $check = mysql_query("SELECT COUNT(*) as `num` FROM `services` WHERE `title` LIKE '%".$search_query."%'");
   $check_row = mysql_fetch_array($check);
   ?>
    
  <div class="box filter_wrap">
  	<span class="right"><?php echo $check_row['num']; ?> Results</span>
  	<strong>Showing:</strong> 
    <a data-filter="latest" class="filter_trigger current">Latest</a>
    <a data-filter="high_rating" class="filter_trigger">High Rating</a>
    <a data-filter="expressed" class="filter_trigger">24 Hours Delivery</a>
    <div class="clear"></div>
  </div>
  <div id="services_wrap"><div class="services_loading"></div></div>
<?php include('footer.php'); ?>