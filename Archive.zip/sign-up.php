<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
if ($set['signup_captcha'] == 1) require_once('includes/recaptcha_process.php');

$page_title = "Sign Up";
$meta_desc = "Let's signup to etallu! " . $set['meta_desc'];
$is_signup_page = 1;


if (isset($_COOKIE['get_ref'])) {
	$ref  = mres($_COOKIE['get_ref']);
	$quick_get = mysql_query("SELECT `username` FROM `users` WHERE `username` = '".$ref."' ");
		if (mysql_num_rows($quick_get) == 1) {
			$quick_ref = mysql_fetch_array($quick_get);
			$referrer = $quick_ref['username'];
		} 
} else {
  $referrer = '';	
}

if (isset($_POST['signup_submit'])) :

$email = mres($_POST['email']);
$username = mres($_POST['username']);
$password = mres($_POST['password']);

$signup_date = date("Y-m-d H:i:s");
$signup_ip = mres($_SERVER["REMOTE_ADDR"]);

$confirm_code = md5(uniqid(rand())); 


	if ($email == '') $error[] = "Email is required!";
	
	if ($username == ''){
		 $error[] = "Username is required!";	
	} elseif(strlen($username)<4) {
		 $error[] = "Username cannot have less than 4 characters";	
	} elseif (!preg_match('/^[a-zA-Z0-9_]+$/',$username)) {
	   $error[] = "Sorry, username contains invalid characters.";	
	}
		
	if ($password == '') $error[] = "Password is required!";	
		
	$not_allowed = array('administrator','adnim','ahole', 'anus', 'ash0le', 'ash0les', 'asholes', 'Ass_Monkey', 'Assface', 'assh0le', 'assh0lez', 'asshole', 'assholes', 'assholz', 'asswipe', 'azzhole', 'bassterds', 'bastard', 'bastards', 'bastardz', 'basterds', 'basterdz', 'Biatch', 'bitch', 'bitches', 'Blow_Job', 'boffing', 'butthole', 'buttwipe', 'c0ck', 'c0cks', 'c0k', 'Carpet_Muncher', 'cawk', 'cawks', 'Clit', 'cnts', 'cntz', 'cock', 'cockhead', 'cock-head', 'cocks', 'CockSucker', 'cock-sucker', 'crap', 'cum', 'cunt', 'cunts', 'cuntz', 'dick', 'dild0', 'dild0s', 'dildo', 'dildos', 'dilld0', 'dilld0s', 'dominatricks', 'dominatrics', 'dominatrix', 'dyke', 'enema', 'f_u_c_k', 'f_u_c_k_e_r', 'fag', 'fag1t', 'faget', 'fagg1t', 'faggit', 'faggot', 'fagit', 'fags', 'fagz', 'faig', 'faigs', 'fart', 'flipping_the_bird', 'fuck', 'fucker', 'fuckin', 'fucking', 'fucks', 'Fudge_Packer', 'fuk', 'Fukah', 'Fuken', 'fuker', 'Fukin', 'Fukk', 'Fukkah', 'Fukken', 'Fukker', 'Fukkin', 'g00k', 'gay', 'gayboy', 'gaygirl', 'gays', 'gayz', 'God-damned', 'h00r', 'h0ar', 'h0re', 'hells', 'hoar', 'hoor', 'hoore', 'jackoff', 'jap', 'japs', 'jerk-off', 'jisim', 'jiss', 'jizm', 'jizz', 'knob', 'knobs', 'knobz', 'kunt', 'kunts', 'kuntz', 'Lesbian', 'Lezzian', 'Lipshits', 'Lipshitz', 'masochist', 'masokist', 'massterbait', 'masstrbait', 'masstrbate', 'masterbaiter', 'masterbate', 'masterbates', 'Motha_Fucker', 'Motha_Fuker', 'Motha_Fukkah', 'Motha_Fukker', 'Mother_Fucker', 'Mother_Fukah', 'Mother_Fuker', 'Mother_Fukkah', 'Mother_Fukker', 'mother-fucker', 'Mutha_Fucker', 'Mutha_Fukah', 'Mutha_Fuker', 'Mutha_Fukkah', 'Mutha_Fukker', 'n1gr', 'nastt', 'nigger;', 'nigur;', 'niiger;', 'niigr;', 'orafis', 'orgasim;', 'orgasm', 'orgasum', 'oriface', 'orifice', 'orifiss', 'packi', 'packie', 'packy', 'paki', 'pakie', 'paky', 'pecker', 'peeenus', 'peeenusss', 'peenus', 'peinus', 'pen1s', 'penas', 'penis', 'penis-breath', 'penus', 'penuus', 'Phuc', 'Phuck', 'Phuk', 'Phuker', 'Phukker', 'polac', 'polack', 'polak', 'Poonani', 'pr1c', 'pr1ck', 'pr1k', 'pusse', 'pussee', 'pussy', 'puuke', 'puuker', 'queer', 'queers', 'queerz', 'qweers', 'qweerz', 'qweir', 'recktum', 'rectum', 'retard', 'sadist', 'scank', 'schlong', 'screwing', 'semen', 'sex', 'sexy', 'Sh!t', 'sh1t', 'sh1ter', 'sh1ts', 'sh1tter', 'sh1tz', 'shit', 'shits', 'shitter', 'Shitty', 'Shity', 'shitz', 'Shyt', 'Shyte', 'Shytty', 'Shyty', 'skanck', 'skank', 'skankee', 'skankey', 'skanks', 'Skanky', 'slut', 'sluts', 'Slutty', 'slutz', 'son-of-a-bitch', 'tit', 'turd', 'va1jina', 'vag1na', 'vagiina', 'vagina', 'vaj1na', 'vajina', 'vullva', 'vulva', 'w0p', 'wh00r', 'wh0re', 'whore', 'xrated', 'xxx', 'b!+ch', 'bitch', 'blowjob', 'clit', 'arschloch', 'fuck', 'shit', 'ass', 'asshole', 'b!tch', 'b17ch', 'b1tch', 'bastard', 'bi+ch', 'boiolas', 'buceta', 'c0ck', 'cawk', 'chink', 'cipa', 'clits', 'cock', 'cum', 'cunt', 'dildo', 'dirsa', 'ejakulate', 'fatass', 'fcuk', 'fuk', 'fux0r', 'hoer', 'hore', 'jism', 'kawk', 'l3itch', 'l3i+ch', 'lesbian', 'masturbate', 'masterbat', 'masterbat3', 'motherfucker', 's.o.b.', 'mofo', 'nazi', 'nigga', 'nigger', 'nutsack', 'phuck', 'pimpis', 'pusse', 'pussy', 'scrotum', 'sh!t', 'shemale', 'shi+', 'sh!+', 'slut', 'smut', 'teets', 'tits', 'boobs', 'b00bs', 'teez', 'testical', 'testicle', 'titt', 'w00se', 'jackoff', 'wank', 'whoar', 'whore', 'damn', 'dyke', 'fuck', 'shit', '@$$', 'amcik', 'andskota', 'arse', 'assrammer', 'ayir', 'bi7ch', 'bitch', 'bollock', 'breasts', 'butt-pirate', 'cabron', 'cazzo', 'chraa', 'chuj', 'Cock', 'cunt', 'd4mn', 'daygo', 'dego', 'dick', 'dike', 'dupa', 'dziwka', 'ejackulate', 'Ekrem', 'Ekto', 'enculer', 'faen', 'fag', 'fanculo', 'fanny', 'feces', 'feg', 'Felcher', 'ficken', 'fitt', 'Flikker', 'foreskin', 'Fotze', 'Fu(', 'fuk', 'futkretzn', 'gay', 'gook', 'guiena', 'h0r', 'h4x0r', 'hell', 'helvete', 'hoer', 'honkey', 'Huevon', 'hui', 'injun', 'jizz', 'kanker', 'kike', 'klootzak', 'kraut', 'knulle', 'kuk', 'kuksuger', 'Kurac', 'kurwa', 'kusi', 'kyrpa', 'lesbo', 'mamhoon', 'masturbat', 'merd', 'mibun', 'monkleigh', 'mouliewop', 'muie', 'mulkku', 'muschi', 'nazis', 'nepesaurio', 'nigger', 'orospu', 'paska', 'perse', 'picka', 'pierdol', 'pillu', 'pimmel', 'piss', 'pizda', 'poontsee', 'poop', 'porn', 'p0rn', 'pr0n', 'preteen', 'pula', 'pule', 'puta', 'puto', 'qahbeh', 'queef', 'rautenberg', 'schaffer', 'scheiss', 'schlampe', 'schmuck', 'screw', 'sh!t', 'sharmuta', 'sharmute', 'shipal', 'shiz', 'skribz', 'skurwysyn', 'sphencter', 'spic', 'spierdalaj', 'splooge', 'suka', 'b00b', 'testicle', 'titt', 'twat', 'vittu', 'wank', 'wetback', 'wichser', 'wop', 'yed', 'zabourah');
	
	
	
	if ($email != ''){
		$check_result = mysql_query("SELECT `email` FROM `users` WHERE `email` = '".$email."'");
		$check_count = mysql_num_rows($check_result);
		if ($check_count == 1) {
			$error[] = "Sorry, This email address is already being used.";
		}
	}
	
	if ($username != ''){
		if (in_array($username,$not_allowed)) {
			$error[] = "This username is not allowed!";
		}
		$check_result = mysql_query("SELECT `username` FROM `users` WHERE `username` = '{$username}'");
		$check_count = mysql_num_rows($check_result);
		if ($check_count != 0) {
			$error[] = "Sorry, This username is already taken.";
		}
	}
		
	
if (empty($error)){ 
	
	$email_verify_code = email_verify_code($username);
	
	$password = sha1($password);
	
	$query = "INSERT INTO `users`(
		`email`,
		`username`,
		`password`,
		`referrer`,
		`signup_date`,
		`last_login`,
		`role`,
		`level`,
		`email_verify_code`,
		`signup_ip`,
		`last_ip`
		) VALUES (
		'$email',
		'$username',
		'$password',
		'".$referrer."',
		'$signup_date',
		'$signup_date',
		'user',
		'No Level',
		'".$email_verify_code."',
		'".mres($_SERVER['REMOTE_ADDR'])."',
		'".mres($_SERVER['REMOTE_ADDR'])."'
		)";
	$result = mysql_query($query);
	
	if (confirm_query($result)) {
		$_SESSION['user_login'] = $username;
		$user = get_loggedin_info();
		
		if ($referrer != ''){
			$ref_user = get_user_info($referrer,true);
			add_noti('Congrats! <strong>(' .$username. ')</strong> Signed up as your referral.',$ref_user['id'],'New Referral ['.$username.']');
		}
		
		add_noti('Signed Up for <strong>etallu Marketplace</strong>', $user['id'],'',0,true);
		
		send_email_verification($user['id'],$email_verify_code);
				
		if (isset($_COOKIE['get_ref'])) {
			$expire=time()-60*60*24*2;
			setcookie("get_ref", $_COOKIE['get_ref'], $expire,'/');
		}
		redirect($set['home']."/verify-email/");
	} 
	
}

endif;
include('header.php');
?>

<div class="form_wrap">
<?php display_error(); display_message(); ?>
<?php if ($set['signup_captcha'] == 1) { ?>
<script type="text/javascript">
 var RecaptchaOptions = {
    theme : 'white'
 };
 </script>
<?php } ?> 

<div class="login_box">
	<form id="validate_signup_form" action="<?php echo $set['home']; ?>/sign-up/" method="post">
        <table class="form_table">
        	<tr>
                <td><h2>Sign Up</h2></td>
        	</tr>
            <tr>
                <td><input type="email" name="email" class="required" tabindex="3" value="<?php if (isset($email)) echo $email; ?>" placeholder="Your Email"></td>
        	</tr>
        	<tr>
                <td><input type="text" name="username" class="required" tabindex="4" value="<?php if (isset($username)) echo $username; ?>" placeholder="Username"></td>
        	</tr>
            <tr>
                <td><input type="password" name="password" class="required" tabindex="5" placeholder="Password"></td>
        	</tr>
            <tr>
                <td><input type="password" name="confirm_password" class="required" tabindex="6" placeholder="Confirm Password"></td>
        	</tr>
            <?php if ($set['signup_captcha'] == 1) { ?>
            <tr>
            	<td><?php echo recaptcha_get_html($publickey, $error_captcha); ?></td>
            </tr>
            <?php } ?>
            <tr>
                <td class="aligncenter">By signing up I agree to the <a href="<?php echo $set['home']; ?>/terms-of-service/" target="_blank">Terms of Service</a></label></td>
        	</tr>
            <tr>
              <td></td>
            </tr>
            <tr>
                <td class="aligncenter"><input type="submit" name="signup_submit" class="button" value="Sign up"> <br>&nbsp; <a href="<?php echo $set['home']; ?>/sign-in/">Already a member?</a></td>
        	</tr>
        </table>
    </form>
</div><!-- .login_box -->

</div><!-- .form_wrap -->

<?php include('footer.php'); ?>