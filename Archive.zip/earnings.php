<?php
include('includes/header_account.php');
$page_title = "My Earnings";
$meta_desc = "All your account info." . $set['meta_desc'];
include('header.php');

if (isset($_GET['auto_renew'])) {
	$renew_val = intval($_GET['auto_renew']);
	mysql_query("UPDATE `users` SET `auto_renew` = '".$renew_val."' WHERE `id` = " . $user['id']);
	if ($renew_val == 1) $action = 'ON';
	if ($renew_val == 0) $action = 'OFF';
	$message = "Auto Renewal is now turned " . $action;
	$user = get_loggedin_info();
}

if (isset($_GET['renewed'])) display_message("Congrats! You have successfully <strong>renewed</strong> your account.");
if (isset($_GET['depositcomplete'])) display_message("Congrats! You have successfully deposited money your account.");
if (isset($_GET['upgraded'])) display_message("Congrats! Your account is now <strong>upgraded</strong>.");
if (isset($_GET['activated'])) display_message("Congrats! Your account is now <strong>activated</strong>.");
if (isset($_GET['withdrawal'])) display_message("Your withdrawal request has been successfully sent.");
if (isset($_GET['emailverified'])) display_message("<strong>Thank you ".$user['first_name']." !</strong> Your email addess is now <strong>verified!</strong>.");

display_message(); display_error(); display_notice();

$pending_count = mysql_query("SELECT `amount` FROM `earnings` WHERE `status` = 'Pending' AND `user_id` = " . $user['id']);
$total_pending = 0;
while ($count_row = mysql_fetch_array($pending_count)){
	$total_pending = $total_pending + $count_row['amount'];
}

$upcimming_count = mysql_query("SELECT `price` FROM `orders` WHERE `status` = 'Active' AND `seller_id` = " . $user['id']);
$total_upcoming = 0;
while ($count_row = mysql_fetch_array($upcimming_count)){
	$amount = get_seller_earning_amount($count_row['price']);
	$total_upcoming = $total_upcoming + $amount;
}

?>

<div class="side_content">

 <div class="box">
 
    	<h2>Earnings
	        <span class="right">
	            <a href="<?php echo $set['home']; ?>/withdraw/" class="new_button" >Withdraw <strong class="colored">$<?php echo $user['balance']; ?></strong></a> 
	        </span>
        </h2>
        
        <div class="bal_box">
        	<strong>$<?php echo round($user['balance'],2); ?></strong><br>Balance - <a href="<?php echo $set['home']; ?>/withdraw/">Withdraw</a>
        </div><!-- .bal_box -->
        <div class="bal_box">
        	<strong>$<?php echo $total_pending; ?></strong><br>Pending clearance - <a href="<?php echo $set['home']; ?>/withdraw/">View All</a>
        </div><!-- .bal_box -->
        <div class="bal_box no_border">
        	<strong>$<?php echo $total_upcoming; ?></strong><br>Upcoming - <a href="<?php echo $set['home']; ?>/deposit/">View All</a>
        </div><!-- .bal_box -->
         
         <div class="clear"></div>
        
    </div><!-- .box -->
    
    
    
  	<div class="clear"></div>
    
     <div class="box">
		
         <div class="bal_box">
         	<?php 
			$total_earnings = ($user['balance'] + $user['total_withdrawn'] + $user['balance_used']) ; 
            if ($total_earnings < 0) $total_earnings = 0; 
			?>
        	<strong>$<?php echo round( $total_earnings ,2); ?> </strong> <br />Total Earnings
        </div><!-- .bal_box -->
        <div class="bal_box">
        	<strong>
            $<?php echo round($user['balance_used'],2); ?></strong>
            </strong> <br> Balance Used
        </div><!-- .bal_box -->
                <div class="bal_box no_border">
        	<strong>$<?php echo round($user['total_withdrawn'],2); ?> </strong> <br />Already Withdrawn
        </div><!-- .bal_box -->
         
         <div class="clear"></div>
        
    </div><!-- .box -->
    
    <div class="clear"></div>
    
    <div class="box">
    
<?php
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	if ($page == '') $page = 1;
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;

	$by_type = ' ';
	
	if (isset($_GET['type'])) {
		$type = mres($_GET['type']);
		$by_type = " AND `status` = '".ucfirst($type)."' ";
	} else {
		$type = 'all';
	}
	
	$statement = "`earnings` WHERE `user_id` = '".$user['id']."' ".$by_type." ORDER BY `id` DESC";
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$total = mysql_num_rows($result);
 ?>

    <?php  ?>
    
    	<h2><span class="left">
    	<a href="<?php echo $set['home']; ?>/earnings/" class="new_button<?php if ($type == 'all') echo ' current'; ?>">All</a>
        <a href="<?php echo $set['home']; ?>/earnings/type/pending/" class="new_button<?php if ($type == 'pending') echo ' current'; ?>">Pending Clearance</a>
        <a href="<?php echo $set['home']; ?>/earnings/type/completed/" class="new_button<?php if ($type == 'completed') echo ' current'; ?>">Completed</a>
        <a href="<?php echo $set['home']; ?>/earnings/type/cancelled/" class="new_button<?php if ($type == 'cancelled') echo ' current'; ?>">Cancelled</a>
     	</span>&nbsp;</h2>
        
        <table class="data_table">
        	<tr class="head">
            	<td width="100">Amount</td>
        		<td class="alignleft">Description</td>
                <td width="120">Due Date</td>
        	</tr>
            <?php
				if ($total != 0) {
				while ($row = mysql_fetch_array($result)) : 
			?>
            <tr class="<?php if ($row['status'] == 'Pending') echo "pending"; ?>">
            	<td><strong>$<?php echo $row['amount']; ?></strong></td>
            	<td class="alignleft">
                <?php
					if ($row['status'] == 'Pending') {
						echo "Pending for clearance";
					} elseif ($row['status'] == 'Completed') {
						echo "Completed";
					} elseif ($row['status'] == 'Cancelled') {
						echo "Cancelled and refunded to buyer.";	
					}
				?>
                </td>
                <td><?php echo get_date($row['due_datetime'],'j F, Y'); ?></td>
            </tr>
            <?php endwhile;  ?>
            <?php } else { ?>
            <tr>
            	 <td colspan="3" class="alignleft">
                 <?php if ($type == 'all') { 
				 			echo "No earnings so far."; 
				 		} else { 
				 			echo "No " . $type . ' earnings to show.';
				 	} ?>
                 </td>
            </tr>
            <?php } ?>
        </table>
    </div><!-- .box -->


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-sales.php'); ?>
<?php include('footer.php');  ?>    