<?php 
$page_title = "Referrals";
include('includes/header_account.php');
include('header.php'); 
display_error(); display_notice(); 
?>

<div class="side_content">

<?php include('includes/ref_url_box.php'); ?>
  
 <?php
 	
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;
 	
	$statement = "`users` WHERE `referrer` = '".$user['username']."' ORDER BY `id` DESC, `first_deposit` ASC";
	
 	$refs_result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$refs_count = mysql_num_rows($refs_result);
 ?>
	
     <?php echo pagination($statement,$limit,$page); ?>
    
    <div class="box">
    
    <?php if ($refs_count != 0) { ?>
    
    	<h2>Referrals <span class="right">Total: <?php echo $refs_count; ?></span></h2>
        
        <table class="referrals_table">
        	<tr class="head">
        		<td>Username</td>
                <td>Status</td>
                <td>Joined</td>
        	</tr>
            <?php
				$count = 0;
				while ($ref_row = mysql_fetch_array($refs_result)) : 
			?>
            <tr class="<?php if($count%2) echo "even"; ?> <?php if($ref_row['first_deposit'] == 0) echo "pending"; ?>" >
            	<td><?php echo $ref_row['username']; ?></td>
                <td><?php if ($ref_row['first_deposit'] == 1) echo "<strong class='active'>Deposited</strong>"; else echo "<strong class='pending'>Pending</strong>" ?></td>
                <td><?php datetime($ref_row['signup_date']); ?></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
        <?php } else { ?>
        <h2>No referrals so far!</h2>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <?php } ?>
			
    </div><!-- .box -->

	<?php echo pagination($statement,$limit,$page); ?>


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-account.php'); ?>
<?php include('footer.php');  ?>    