<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = "How it works";
$meta_desc = "Check it out how Lancer Desk works! " . $set['meta_desc'];
?>

<?php include('header.php'); ?>

<div class="how_to_text">
<h2>What is LANCER DESK?</h2>
<p>LANCER DESK is a marketplace for all kind of small services online starting from $3. People (sellers) offer their services and other people (Buyers) buy the services they like.</p>
</div>	
    
<div class="how_to_box left">
	<h2>How to Buy?</h2>
	<p><strong>Find a Service. and Pay:</strong> Find some service you like and place your order.</p>
	<p><strong>Track and Receive:</strong> Follow the progress and receive your order.</p>
	<p><strong>Review and Share:</strong> Review your order and share with friends.</p>
	<p><a href="<?php echo $set['home']; ?>/services/" class="button">Explore Services</a></p>
</div><!-- .how_to_box -->
<div class="how_to_box right">
	<h2>How to Sell?</h2>
	<p><strong>Create a Service and Share It:</strong> Offer a small service and share it with the world.</p>
	<p><strong>Get Paid:</strong> Get notified when your service is ordered.</p>
	<p><strong>Withdraw and Party!:</strong> Deliver your work and withdraw your funds.</p>
	<p><a href="<?php echo $set['home']; ?>/new/" class="button">Create New Service</a></p>
</div><!-- .how_to_box -->

<div class="clear"></div>
     
<?php include('footer.php'); ?>