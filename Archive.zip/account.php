<?php
include('includes/header_account.php');
$page_title = "My Account";
$meta_desc = "All your account info." . $set['meta_desc'];

include('header.php');
if (isset($_GET['auto_renew'])) {
	$renew_val = intval($_GET['auto_renew']);
	mysql_query("UPDATE `users` SET `auto_renew` = '".$renew_val."' WHERE `id` = " . $user['id']);
	if ($renew_val == 1) $action = 'ON';
	if ($renew_val == 0) $action = 'OFF';
	$message = "Auto Renewal is now turned " . $action;
	$user = get_loggedin_info();
}

if (isset($_GET['renewed'])) display_message("Congrats! You have successfully <strong>renewed</strong> your account.");
if (isset($_GET['paymentcomplete'])) display_message("Congrats! You have successfully deposited money your account.");
if (isset($_GET['upgraded'])) display_message("Congrats! Your account is now <strong>upgraded</strong>.");
if (isset($_GET['activated'])) display_message("Congrats! Your account is now <strong>activated</strong>.");
if (isset($_GET['withdrawal'])) display_message("Your withdrawal request has been successfully sent.");
if (isset($_GET['emailverified'])) display_message("<strong>Thank you ".$user['first_name']." !</strong> Your email addess is now <strong>verified!</strong>.");

display_message(); display_error(); display_notice();
?>

<div class="side_content">

 <div class="box">
 
    	<h2>Hello <?php echo $user['username']; ?>! 
	        <span class="right">
	            <a href="<?php echo $set['home']; ?>/withdraw/" class="new_button" >Withdraw</a> 
	            <a href="<?php echo $set['home']; ?>/deposit/" class="new_button" title="Deposit">Purchase Balance: <strong class="colored">$<?php echo $user['purchase_balance']; ?></strong></a>
	        </span>
        </h2>
        
        <div class="bal_box">
        	<strong>$<?php echo round($user['balance'],2); ?></strong><br>Balance - <a href="<?php echo $set['home']; ?>/withdraw/">Withdraw</a>
        </div><!-- .bal_box -->
        <div class="bal_box ">
        	<strong>$<?php echo round($user['purchase_balance'],2); ?></strong><br>Purchase balance - <a href="<?php echo $set['home']; ?>/deposit/">Deposit</a>
        </div><!-- .bal_box -->
        <div class="bal_box no_border">
        	<?php if ($user['level'] != 'No Level') { ?>
        	<strong class="type_<?php echo strtolower(str_replace(' ','_',$user['level'])); ?>"><?php echo $user['level']; ?></strong><br>Account
            <?php } else { ?>
            	&nbsp;<br>N/A
            <?php } ?>
        </div><!-- .bal_box -->
         
         <div class="clear"></div>
        
    </div><!-- .box -->
    
    
    <div class="clear"></div>
    
            <?php 
		$check_widhrwawal = mysql_query("SELECT * FROM `withdrawals` WHERE `user_id` = '" . $user['id'] . "' AND `completed` = 0 ORDER BY `id` DESC");
		confirm_query($check_widhrwawal);
		$withdrawal_count = mysql_num_rows($check_widhrwawal);
		if ($withdrawal_count != 0) { ?>
			
         <div class="box">
         	
            
        <h2>Withdrawal Requests (<?php echo $withdrawal_count; ?>) <spann class="right"><a href="<?php echo $set['home']; ?>/withdrawals/" class="new_button">View All</a></span></h2>
        
        <table class="referrals_table">
        	<tr class="head">
        		<td >Amount</td>
                <td>Method</td>
                <td width="150">Status</td>
                <td width="150">Requested</td>
        	</tr>
            <?php
				$count = 0;
				while ($with_row = mysql_fetch_array($check_widhrwawal)) : 
			?>
            <tr class="<?php if($count%2) echo "even"; ?> <?php if($with_row['completed'] == 0) echo "pending"; ?>" >
            	<td><strong>$<?php echo $with_row['amount']; ?></strong> (USD)</td>
                <td><img src="<?php echo $set['home']; ?>/img/pmt-icons/<?php echo $with_row['method']; ?>.png" alt="" style="width:45px;"></td>
                <td><?php if ($with_row['completed'] == 1) echo "<strong class='active'>Completed!</strong>"; else echo "<strong class='pending'>Pending</strong>" ?></td>
                <td><?php datetime($with_row['datetime']); ?></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
            
         </div>   
         <div class="clear"></div>
            
	<?php } ?>
    
    <div class="clear"></div>
    
    <div class="box">
    
     <?php
 	$noti_result = mysql_query("SELECT * FROM `notifications` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 5");
	$noti_count = mysql_num_rows($noti_result);
 ?>

    	<h2>Recent Notifications <div class="right"><a class="new_button" href="<?php echo $set['home']; ?>/notifications/">View All</a></div></h2>
        
        <table class="data_table">
        	<tr class="head">
        		<td class="alignleft">Description</td>
                <td width="150"></td>
        	</tr>
            <?php
			if ($noti_count != 0) {
				$count = 0;
				while ($noti_row = mysql_fetch_array($noti_result)) : 
			?>
            <tr class="<?php if($count%2) echo "even"; ?> <?php if ($noti_row['viewed'] == 0) echo "pending"; ?>" >
            	<td class="alignleft">
                <?php if ($noti_row['url'] != '') { ?>
                	<a href="<?php echo $set['home'] . '/' . $noti_row['url']; ?>">
                <?php } ?>
					<?php echo $noti_row['description']; ?>
                <?php if ($noti_row['url'] != '') { ?>
                </a>
                <?php } ?>
                </td>
                <td><?php datetime($noti_row['datetime']); ?></td>
            </tr>
            <?php 
				$count++;  endwhile; 
			} else {
			 ?>
             <tr>
             	<td colspan="2">No Notifications far!</td>
             </tr>
             <?php } ?>
        </table>
		
    </div><!-- .box -->
  
  <?php include('includes/ref_url_box.php'); ?>

</div><!-- .side_content -->
<?php include('includes/sidebars/sidebar-account.php'); ?>
<?php include('footer.php');  ?>    