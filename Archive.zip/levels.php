<?php $page_title = "Levels" ?>
<?php include('header.php'); ?>

<div class="levels_wrap">
  
  <h2 class="centered front_heading">Level One Sellers</h2>
	  
      <p>You've been active on the site for 30 days and completed at least 10 orders while maintaining excellent ratings and a great track record. You'll automatically be promoted to Level One. At this Level, you'll gain additional features making it easier for you to offer more advanced services and generate higher income.</p>
      
      <div class="level_features">
      	Max Service Price: $20
      </div>
      
  <h2 class="centered front_heading">Level Two Sellers</h2>

<p>You made over 50 orders in the past two months while maintaining excellent ratings and a solid track record. You'll automatically be promoted to Level Two, unlocking advanced sales tools to further expand your services and increase your sales. You'll also receive priority support.</p>
	
    <div class="level_features">
      	Max Service Price: $50
    </div>
    
  <h2 class="centered front_heading">Level Three Sellers</h2>

<p>You made over 100 orders in the past two months while maintaining excellent ratings and a solid track record. You'll automatically be promoted to Level Two, unlocking advanced sales tools to further expand your services and increase your sales. You'll also receive priority support.</p>

<div class="level_features">
      	Max Service Price: $100
    </div>

</div><!-- .levels_wrap -->

<?php include('footer.php'); ?>