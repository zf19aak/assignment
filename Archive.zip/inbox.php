<?php 
$page_title = "Messages";
include('includes/header_account.php');
include('header.php');
display_error(); display_notice(); 

	$result = mysql_query("SELECT * FROM `conversations` WHERE `to_id` = '".$user['id']."' OR `from_id` = '".$user['id']."' ORDER BY `updated` DESC ");
	$rows_count = mysql_num_rows($result);
?>

<div class="side_content">
  
     <div class="box inbox_wrap">
 
    	<h2>Inbox (<?php echo $rows_count; ?>)</small>
        <span class="right"><a href="<?php echo $set['home']; ?>/account/" class="new_button">read</a></span></h2>
        
  	    <?php if ($rows_count != 0) { ?>
        
        <table class="data_table">
        	<tr class="head">
        		<td width="150" class="centered">Sender</td>
                <td class="alignleft">Message</td>
                <td width="120">Updated</td>
        	</tr>
            <?php
				$count = 1;
				while ($row = mysql_fetch_array($result)) : 
				$get_last_msg = mysql_query("SELECT `message` FROM `messages` WHERE `id` = ". $row['last_msg_id']);
				$last_msg = mysql_fetch_array($get_last_msg);
				$sender = get_user_info($row['to_id']);
				if ($row['to_id']==$user['id']) $sender = get_user_info($row['from_id']);
				
				$unread = 0;
								
				if ($row['to_id'] != $user['id'] && $row['from_unread'] == 1) $unread = 1;
				if ($row['from_id'] != $user['id'] && $row['to_unread'] == 1) $unread = 1;
				
			?>
            <tr class="<?php if($count%2) echo "even"; if ($unread == 1) echo " pending"; ?>">
            	<td class="centered"><a href="<?php echo $set['home']; ?>/messages/<?php echo $sender['username']; ?>/"><?php echo $sender['username']; ?></a></td>
                <td class="alignleft"><a href="<?php echo $set['home']; ?>/messages/<?php echo $sender['username']; ?>/"><?php echo limit_words($last_msg['message'],8); ?>...</a></td>
                <td><?php datetime($row['updated']); ?></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
        <?php } else { ?>
        <p>No messages to show here...</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <?php } ?>
         
         <div class="clear"></div>
        
    </div><!-- .box -->


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-messages.php');  ?>  
<?php include('footer.php');  ?>    