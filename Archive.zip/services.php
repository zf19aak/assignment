<?php
require_once('includes/connection.php');
require_once('includes/functions.php');

if (isset($_GET['category'])) $category = get_category_info(mres($_GET['category']),true);
if (isset($_GET['sub_category'])) $sub_category = get_category_info(mres($_GET['sub_category']),true);

$page_title = "Services";

if (isset($_SESSION['service_not_active'])) {
	$error[] = "Sorry, that service is not active.";
	unset($_SESSION['service_not_active']);
}

include('header.php'); 


display_message(); display_error();

if (!isset($category))  {
   		include('includes/services/categories-tree.php');
} else {

$this_services_page = true;

if (!isset($category['id'])) redirect($set['home'].'/services/');
if (isset($sub_category)) {
	if (!isset($sub_category['id'])) redirect(category_url($category['id']));
}


?>
  <h2 class="services_heading"><a href="<?php echo category_url($category['id']); ?>"><?php echo $category['name']; ?></a>
  <?php if (isset($sub_category)) echo ', ' . $sub_category['name']; ?></h2>
  <?php if ($category['id'] != 5) { ?>
  <div class="box cats_wrap">
  	<ul>
    <?php
		$query = mysql_query("SELECT * FROM `categories` WHERE `parent` = '".$category['id']."' ORDER BY `position` ASC");
		while ($row = mysql_fetch_array($query)) {?>
	   	<li>
        <?php
		if (isset($sub_category)) {
			if ($row['id'] == $sub_category['id']) {
				echo $row['name'];
			} else { ?>
	        <a href="<?php echo category_url($row['id']); ?>"><?php echo $row['name']; ?></a>
	        <?php } 
		} else { ?>
        	 <a href="<?php echo category_url($row['id']); ?>"><?php echo $row['name']; ?></a>
		<?php } ?>
        </li>
        <?php } ?>
    </ul>
    <div class="clear"></div>
  </div><!-- .cats_wrap -->
  <?php } ?>
  <div class="box filter_wrap">
  	<strong>Showing:</strong> 
    <a data-filter="latest" class="filter_trigger current">Latest</a>
    <a data-filter="high_rating" class="filter_trigger">High Rating</a>
    <a data-filter="expressed" class="filter_trigger">24 Hours Delivery</a>
  </div>
  <div id="services_wrap"><div class="services_loading"></div></div>
<?php } ?>
<?php include('footer.php'); ?>