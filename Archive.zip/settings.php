<?php 
$page_title = "Account Settings";
$is_settings_page = 1;
require_once('includes/connection.php');
require_once('includes/functions.php');
check_login();
$user = get_loggedin_info();

if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");

if (isset($_GET['del_img'])) {
	$image_location = 'uploads/avatars/';
	if (file_exists($image_location.$user['avatar']) && !empty($user['avatar'])){
		unlink($image_location.$user['avatar']);
		$message = "Image Deleted!";
		$del_result = mysql_query("UPDATE `users` SET `avatar`= '' WHERE `id` = ".$user['id']);
		confirm_query($del_result);
		if ($del_result) {
		$user = get_loggedin_info();
		$message = "Image Deleted!";
		}
		
	}
}



if (isset($_GET['update'])) { $error[] = "Please Update your settings"; }
if (isset($_GET['payment_emails'])) { $error[] = "Please Update Payza email."; }

if (isset($_POST['update_submit'])):
	
	$first_name = mres($_POST['first_name']);
	$last_name = mres($_POST['last_name']);
	$description = mres($_POST['description']);
	$email = mres($_POST['email']);
	$paypal_email = mres($_POST['paypal_email']);
	$new_password = mres($_POST['new_password']);
	$current_password = mres($_POST['current_password']);
	
	if ($current_password == '') {
		$error[] = "Current password is required to update your settings.";
	}
	
	$check_again = mysql_query("SELECT `username` FROM `users` WHERE `username` = '".$user['username']."' AND `password` = '".sha1($current_password)."'");
	if (mysql_num_rows($check_again) != 1) {
		$error[] = "Sorry, your current password is incorrect.";
	}
	
	
	// Image Processing
	
	$image_name = $_FILES["avatar"]["name"];
	$image_type = $_FILES["avatar"]["type"];
	
	$arr = explode(".", $image_name);
    $image_extension = strtolower(array_pop($arr));   
    
	if ($_FILES["avatar"]["error"] != 4) {
	
	$image_location = 'uploads/avatars/';
			
		if ((($image_type == "image/gif") || ($image_type == "image/jpeg") || ($image_type == "image/png") || ($image_type == "image/pjpeg"))) {
	
	  		if ($_FILES["avatar"]["error"] > 0) {
	    		$error[] = "Return Code: " . $_FILES["avatar"]["error"] . "<br>";
	    	} else {
				
				//$storeimage =  "avatar-".$user['id']."." . $image_extension;
				$storeimage = strtolower($user['username']);
				
				$quick_result = mysql_query("SELECT `avatar` FROM `users` WHERE `id` =".$user['id']);
				$quick_row = mysql_fetch_array($quick_result);
					
				// If file exists delete first.	
				$old_image = $image_location.$quick_row['avatar'];
				if (file_exists($old_image) && !empty($quick_row['avatar'])) {
					unlink($image_location.$quick_row['avatar']);
				}
				
				$image_info = getimagesize($_FILES["avatar"]["tmp_name"]);
				$image_width = $image_info[0];
				$image_height = $image_info[1];
  				
				if ($image_width <= 100) {
					move_uploaded_file($_FILES["avatar"]["tmp_name"], $image_location . $storeimage .'.'. $image_extension);
				} else {
				
				include('includes/class.upload.php');
			
				$foo = new Upload($_FILES['avatar']);
				if ($foo->uploaded) {

				  $foo->file_new_name_body = $storeimage;
				  $foo->image_resize = true;
				  $foo->image_ratio_crop = true;
				  $foo->image_y = 100;
				  $foo->image_x = 100;
				  $foo->Process($image_location);
				  if ($foo->processed) {
				    $foo->Clean();
				  } else {
				    $error[] = 'error : ' . $foo->error;
				  }
				}

				
				}
				
		    }
	  
		} else {
		  $error[] = "Invalid file";
		}
  
  } else { // image is not selected
	$storeimage = false;
  }
	
	// END Image Processing
	
	$check_result = mysql_query("SELECT `email` FROM `users` WHERE `email` = '{$email}'");
	if (mysql_num_rows($check_result) != 0 && $email != $user['email']) {
		$error[] = "Sorry, This email address is already being used.";
	} elseif (mysql_num_rows($check_result) == 0 && $email != $user['email']) {
		
		$new_code = email_verify_code($user['username']);
		$result = mysql_query("UPDATE `users` SET `email` = '".$email."', `email_verified` = 0, `email_verify_code` = '".mres($new_code)."' WHERE `id` = " . $user['id']);
		send_email_verification($user['id']);
		$verification_sent = true;
	}
	
	
	if (empty($error)){ 
		$update_sql = "UPDATE `users` SET 
		`first_name` = '".$first_name."',
		`last_name` = '".$last_name."',
		`description` = '".$description."',
		`email` = '".$email."',";
		
		if ($new_password != '') {
		$update_sql .= " `password` = '".sha1($new_password)."', ";
		}
		
		if ($storeimage != false) {
		$update_sql .= " `avatar` = '".$storeimage.".".$image_extension."', ";
		}
		
		$update_sql .= " 
		`paypal_email` = '".$paypal_email."' 
		WHERE `id` = ". $user['id'];
		
		$update_result = mysql_query($update_sql);
		if (confirm_query($update_result)) {
			
			$message = "Settings Saved!";
		  	
			if (isset($verification_sent)) $message = "Settings are saved and verification email sent!";
			
			/*
			if ($user['settings_updated'] == 0) {
			mysql_query("UPDATE `users` SET `settings_updated` = '1' WHERE `id` = " .$user['id']);	
			redirect($set['home'].'/account/activated/');
			}*/
			
			$user = get_loggedin_info();
			
		}
		
	}
	
endif;

include('header.php');

?>

<?php display_error(); display_message(); display_notice(); ?>

<div class="side_content">

 <div class="box">
 	<h2>Account Settings <span class="right"><a href="<?php echo $set['home']; ?>/account/" class="new_button">Back to Account</a></span></h2>
 	  		<form id="update_settings" action="<?php echo $set['home']; ?>/settings/" method="post" enctype="multipart/form-data">
      		<table class="activate_form settings_table">
            <tr>
            	<td></td>
                <td>
                <?php if ($user['avatar'] != '') { ?>
                <img src="<?php echo img($set['home'] . '/uploads/avatars/' . $user['avatar'],100); ?>" alt=""> &nbsp;              
				<?php } else { ?>
                <img src="<?php echo get_gravatar($user['email'],80); ?>" alt="" />
                <?php } ?>
                </td>
            </tr>
            <tr>
  				<td>Profile Photo: <small>(100x100)</small></td>
                <td><input type="file" name="avatar" /></td>
  			</tr>
            <tr>
  				<td>First Name:</td>
                <td><input type="text" name="first_name" class="required" value="<?php if (isset($first_name)) echo $first_name; else echo $user['first_name']; ?>" /></td>
  			</tr>
            <tr>
  				<td>Last Name:</td>
                <td><input type="text" name="last_name" class="required" value="<?php if (isset($last_name)) echo $last_name; else echo $user['last_name']; ?>" /></td>
  			</tr>
            <tr>
  				<td>Something <br> About yourself:</td>
                <td><textarea class="check_length" maxlength="300" cols="20" rows="6" name="description"><?php if (isset($description)) echo $description; else echo $user['description']; ?></textarea>
                	<div class="inst">(0 / 300 MAX)</div>
                </td>
  			</tr>
  			<tr>
  				<td>Email:</td>
                <td><input type="email" name="email" class="required" value="<?php if (isset($email)) echo $email; else echo $user['email']; ?>" /><br />
				<span class="email_change_alert">(New email address will require email verification)</span>
                
                </td>
  			</tr>
            <tr>
  				<td>Paypal Email:</td>
                <td><input type="email" name="paypal_email" value="<?php if (isset($paypal_email)) echo $paypal_email; else echo $user['paypal_email']; ?>" /></td>
  			</tr>
            <tr>
  				<td>Current Password:</td>
                <td><input type="password" name="current_password" /></td>
  			</tr>
            <tr>
  				<td>Change Password:</td>
                <td><input type="password" name="new_password" /></td>
  			</tr>
            <tr class="last_row">
            	<td></td>
                <td><input type="submit" value="Save" name="update_submit" /></td>
            </tr>
  		</table>
    </form>
    
 </div><!-- .box -->  	



</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-account.php'); ?>
<?php include('footer.php');  ?>    