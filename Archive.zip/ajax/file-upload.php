<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');
if (!empty($_FILES)) {

$drectory = "../uploads/attachments/";

$from_user = get_loggedin_info();

$tmp_file = $_FILES["Filedata"]["tmp_name"];

$user_id = intval($_POST['u_id']);
$user = get_user_info($user_id);
$rel_id = intval($_POST['rel_id']);
$file_code = gen_file_code();

    // not allowed file types
    $fileTypes = array('com','vbs','vbe','cmd','bat','ws','wsf','scr','shs','pif','hta','jar','lnk','exe','EXE','pif'); // File extensions

    $fileParts = pathinfo($_FILES['Filedata']['name']);
	$storefile = $user['id'] . '-' . date('ymdhis').'-'. str_replace(' ','-',$_FILES["Filedata"]["name"]);
	$file_location = $drectory . $storefile;
	
	$file_size = filesize_formatted($_FILES['Filedata']['size']);
	
    if (in_array($fileParts['extension'],$fileTypes)) {
		echo 'Not Allowed.';        
    } else {
		$uploaded = move_uploaded_file($tmp_file, $file_location);
		
		if ($uploaded) {
		
			
		
			$store_file = mysql_query("INSERT INTO `files` (
				`code`,
				`rel_id`,
				`user_id`,
				`msg_id`,
				`name`,
				`size`,
				`datetime`
			) VALUES (
				'".mres($file_code)."',
				'".$rel_id."',
				'".$user['id']."',
				'0',
				'".mres($storefile)."',
				'".$file_size."',
				'".date('Y-m-d H:i:s')."'
			)");
		
		if ($store_file) {
			$recet_id = mysql_insert_id();
		 echo '1,'.$recet_id;
		} else {
		 echo 'Error Inserting Into database' . mysql_error();	
		}
		
       
		
		} else {
			echo 'Error uploading file.';
		}
    }
}
?>