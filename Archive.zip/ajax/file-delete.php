<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

if (isset($_POST['id'])){

$id = intval($_POST['id']);
$file = get_file_info($id);

if (isset($file['name'])) {

	$directory = "../uploads/attachments/";
	$this_file = $directory . $file['name'];
	
	if (file_exists($this_file) && $file['name'] != ''){
		$deleted = unlink($this_file);
			if ($deleted) {
				
			$delete_record = mysql_query("DELETE FROM `files` WHERE `id` = " . $file['id']);
			if ($delete_record)	{
				 echo '1';		
			} else {
				echo "Error Deleting Record";
			}
			
			 
			} else {
			 echo "Error Deleting File";
			}
	}

} 

}
?>

