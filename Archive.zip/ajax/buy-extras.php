<?php
include_once('../includes/connection.php');
include_once('../includes/functions.php');
if (isset($_REQUEST['extra'],$_REQUEST['order'])):
	
	$extra = mres($_REQUEST['extra']);
	$order_number = mres($_REQUEST['order']);
	
	$order = get_order_info($order_number);
	$service = get_service_info($order['service_id']);
	$buyer = get_user_info($order['buyer_id']);
	$seller = get_user_info($order['seller_id']);
	
	if ($extra != 'extra_fast'){
	if ($order['extra_'.$extra.'_bought'] != 1) {
		$this_extra_price = $service['extra_'.$extra.'_price'];
		$total_duration = $service['extra_'.$extra.'_duration'] + $order['duration'];
		$new_due_datetime = date('Y-m-d H:i:s', strtotime(' +'.$total_duration.' day',strtotime($order['started_datetime'])));
		
		if ($buyer['purchase_balance'] < $this_extra_price){
			echo 'no fund' . $this_extra_price;
		} else {
			$update = mysql_query("UPDATE `orders` SET 
				`price` = `price` + '".$this_extra_price."',
				`duration` = '".$total_duration."',
				`due_datetime` = '".$new_due_datetime."',
				`extra_".intval($extra)."_bought` = 1 
				 WHERE `id` = " . $order['id']);
			
			$payment_desc = "Purchased one of the service extras from Purcahse Balance";
			mysql_query("INSERT INTO `payments` (
				  `user_id`,
				  `order_number`,
				  `amount`,
				  `description`,
				  `type`,
				  `datetime`
			  ) VALUES (
			  	  '".$buyer['id']."',
				  '".$order['number']."',
				  '".$this_extra_price."',
				  '".$payment_desc."',
				  '0',
				  '".date('Y-m-d H:i:s')."'
			  )");
			
			if ($update){
				$noti_desc = 'Congrats! ' .$buyer['username'] .' purchased one of your extras for ordder ' . $order['number'];
				$noti_url = '/order/'.$order['number'].'/';
				$to_id = $seller['id'];
				add_noti($noti_desc,$to_id,$noti_url,'Buyer Purchased Extra!');
				 echo '1';
			} else {
				echo 'Error: ' . mysql_error();	
			}
		}
	
	}
	} elseif ($extra == 'extra_fast') {
	if ($order['extra_fast_bought'] != 1) {	
		$this_extra_price = $service['extra_fast_price'];
		$total_duration = $service['extra_fast_duration'];
		$new_due_datetime = date('Y-m-d H:i:s', strtotime(' +'.$total_duration.' day'));
		
		if ($buyer['purchase_balance'] < $this_extra_price){
			echo 'no fund';
		} else {
			$update = mysql_query("UPDATE `orders` SET 
				`price` = `price` + '".$this_extra_price."',
				`duration` = '".$total_duration."',
				`due_datetime` = '".$new_due_datetime."',
				`extra_fast_bought` = 1 
				 WHERE `id` = " . $order['id']);
				 
			$payment_desc = "Purchased one of the service extras from Purcahse Balance";
			mysql_query("INSERT INTO `payments` (
				  `user_id`,
				  `order_number`,
				  `amount`,
				  `description`,
				  `type`,
				  `datetime`
			  ) VALUES (
			  	  '".$buyer['id']."',
				  '".$order['number']."',
				  '".$this_extra_price."',
				  '".$payment_desc."',
				  '0',
				  '".date('Y-m-d H:i:s')."'
			  )");
				 
			if ($update){
				
				$noti_desc = 'Congrats! ' .$buyer['username'] .' purchased one of your extras for ordder ' . $order['number'];
				$noti_url = '/order/'.$order['number'].'/';
				$to_id = $seller['id'];
				add_noti($noti_desc,$to_id,$noti_url,'Buyer Purchased Extra!');
				
				 echo '1';
			} else {
				echo 'Error: ' . mysql_error();	
			}
		}
		}
		
	}
	
endif;
?>
                     