<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

$search_query = mres($_POST['query']);
$filter = mres($_POST['filter']);
$is_tag = mres($_POST['tag']);

?>
<div class="services_wrap">
  <?php
  	$page = (int) (!isset($_POST["page"]) ? 1 : $_POST["page"]);
	$limit = 5;
	$startpoint = ($page * $limit) - $limit;
 	
	if ($is_tag == 'true')
		$by_column = 'tags';
	else
		$by_column = 'title';	
	
	$statement = "`services` WHERE `".$by_column."` LIKE '%".$search_query."%' AND `status` = 'Active' ORDER BY `id` DESC";
	
	if ($filter == 'high_rating') $statement = "`services` WHERE `".$by_column."` LIKE '%".$search_query."%' AND `reviews` > 0 AND `status` = 'Active' ORDER BY `reviews` DESC, `id` DESC";
	if ($filter == 'expressed') $statement = "`services` WHERE `".$by_column."` LIKE '%".$search_query."%' AND `duration` = 1 AND `status` = 'Active' ORDER BY `reviews` DESC, `id` DESC";
	
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	if (mysql_num_rows($result) > 0) {
		while ($row = mysql_fetch_array($result)) {
			service_box($row);
	   	} 
	} else {
	echo "Sorry, no Services are found.";
	}
   ?> 
   <div class="clear"></div>
</div><!-- .services_wrap -->

<?php echo search_pagination($statement,$limit,$page,$search_query,$is_tag,$filter);  ?>