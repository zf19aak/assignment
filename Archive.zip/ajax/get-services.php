<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');
if (isset($_POST['category'])) $category = intval($_POST['category']);
if (isset($_POST['sub_category'])) {
	 $sub_category = intval($_POST['sub_category']);
	 if ($sub_category == 0) unset($sub_category);
}

$filter = mres($_POST['filter']);

?>
<div class="services_wrap">
  <?php
  	$page = (int) (!isset($_POST["page"]) ? 1 : $_POST["page"]);
	$limit = 16;
	$startpoint = ($page * $limit) - $limit;
 	
	$add_statement = " WHERE `cat_id` = '".$category."' ";
	if (isset($sub_category)){
		$add_statement .= " AND `sub_cat_id` = '".$sub_category."' ";
	}
	
	$statement = "`services` ".$add_statement." AND `status` = 'Active' ORDER BY `id` DESC";
	if ($filter == 'high_rating') $statement = "`services` ".$add_statement." AND `reviews` > 0 AND `status` = 'Active' ORDER BY `reviews` DESC, `id` DESC";
	if ($filter == 'expressed') $statement = "`services` ".$add_statement." AND `duration` = 1 AND `status` = 'Active' ORDER BY `reviews` DESC, `id` DESC";
	
	$count = 0;
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	if (mysql_num_rows($result) > 0) {
		while ($row = mysql_fetch_array($result)) {
			service_box($row);
			$count++;
		if ($count == 4) {
			echo '<div class="clear"></div>'; 
			$count = 0;
		}
	   	} 
	} else {
	echo "Sorry, No Services are found.";
	}
   ?> 
   <div class="clear"></div>
</div><!-- .services_wrap -->

<?php
 if (!isset($sub_category))$sub_category = 0; 
 echo services_pagination($statement,$limit,$page,$category,$sub_category,$filter); 
 ?>