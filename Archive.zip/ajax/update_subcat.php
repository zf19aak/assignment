<?php
include_once('../includes/connection.php');
	if (isset($_REQUEST['id'])):
	$id = intval($_REQUEST['id']);
	$query = mysql_query("SELECT `id`,`name` FROM `categories` WHERE `parent` = " . $id . " ORDER BY `position` ASC");
	$output ='<select class="half_select required" name="sub_category">';
	$output .= '<option value="0">Select a Sub Category</option>';
		while ($row = mysql_fetch_array($query)) {
		$output .= '<option value="'.$row['id'].'">'.$row['name'].'</option>';
		}
	$output .= '</select>';
	echo $output;
endif;
?>
                     