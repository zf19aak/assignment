<?php
if (isset($_POST['service_id'])):
require_once('../includes/connection.php');
require_once('../includes/functions.php');

$service = get_service_info(intval($_POST['service_id']));
$type = mres($_POST['type']);
if ($service) {
	
	$page = (int) (!isset($_POST["page"]) ? 1 : $_POST["page"]);
	$limit = 8;
	$startpoint = ($page * $limit) - $limit;
	
	$add_statement = '';
	if ($type != 'all')	$add_statement = " AND rating = '".$type."'";
	
	$statement = "`ratings` WHERE `service_id` = '".$service['id']."' ".$add_statement." AND `user_id` != " . $service['user_id'] . " ORDER BY `id` DESC";
	
	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$count_reviews = mysql_num_rows($result);
	
	if ($count_reviews > 0) { ?>
    <div class="box reviews_wrap">
    <h2>Customer Reviews <span class="right">
    <a class="<?php if ($type=='all') echo 'active'; else echo 'rreview_type_trigger'; ?>" data-type="all">All <small>(<?php echo $service['reviews']; ?>)</small></a> &nbsp; 
    <a class="<?php if ($type=='up') echo 'active"'; else echo 'rreview_type_trigger'; ?>" data-type="up">Positive <small>(<?php echo count_reviews($service['id'],'up','service',$service['user_id']); ?>)</small></a> &nbsp; 
    <a class="<?php if ($type=='down') echo 'active'; else echo 'rreview_type_trigger';?>" data-type="down">Negative <small>(<?php echo count_reviews($service['id'],'down','service',$service['user_id']); ?>)</small></a>
	</span></h2>
    <div class="reviews_inside">  
    <?php } 
	while ($review_row = mysql_fetch_array($result)) {
		   $this_user = get_user_info($review_row['user_id']);
	?>
    <div class="review_box">
      	<div class="review_sign <?php echo $review_row['rating']; ?>"><?php echo $review_row['rating']; ?></div><!-- .review_sign -->
    	<div class="thumb">
        	<?php the_avatar($this_user['id'],50); ?>
        </div><!-- .thumb -->
        <div class="review">
        	<div class="from"><a href="<?php echo user_permalink($this_user['id']); ?>"><?php echo $this_user['username']; ?></a> 
            	<span>about <?php datetime($review_row['datetime']); ?></span>
            </div>
            <div class="feedback">
				<?php echo nl2br($review_row['review']); ?>
            </div>
        </div><!-- .review -->
    </div><!-- .review_box -->
    <?php
		$query = mysql_query("SELECT * FROM `ratings` WHERE `order_id` = '".$review_row['order_id']."' AND `user_id` != " . $review_row['user_id']);
		if (mysql_num_rows($query) == 1) {
		$child_row = mysql_fetch_array($query);
		$child_user = get_user_info($child_row['user_id']);
	?>
    <div class="review_box seller_review_box">
    	<div class="thumb">
        	<?php the_avatar($child_user['id'],24); ?>
        </div><!-- .thumb -->
        <div class="review">
        	<div class="from">Seller's Feedback:</div>
            <div class="feedback">
				<?php echo nl2br($child_row['review']); ?>
            </div>
        </div><!-- .review -->
    </div><!-- .review_box -->
    <?php } ?>
    <?php } ?>
    
    
 <?php if ($count_reviews > 0) { ?>
  </div><!-- .reviews_inside --> 
  </div><!-- .reviews_wrap -->
  <?php } ?>
  
      <?php echo reviews_pagination($statement,$limit,$page,$type); ?>
 
 <?php } ?>  
<?php endif; ?>  