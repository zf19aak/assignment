<?php 
$page_title = "Referrals";
include('header.php'); 
check_login();
if ($user['active'] == 0) redirect($set['home']."/activate/");
?>

<?php display_error(); display_notice(); ?>

<div class="side_content">
  
 <?php
 	
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;
 	
	$statement = "`withdrawals` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC";
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$with_count = mysql_num_rows($result);
 ?>
    
    <div class="box">
    
    <?php if ($with_count != 0) { ?>
    
    	<h2>Withdrawal Requests <span class="right"><a href="<?php echo $set['home']; ?>/account/" class="new_button">Back to Account</a></span></h2>
        
        <table class="referrals_table">
        	<tr class="head">
        		<td>Amount</td>
                <td>Method</td>
                <td>Status</td>
                <td width="120">Requested</td>
                <td width="120">Completed</td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
			?>
            <tr class="<?php if($count%2) echo "even"; ?> <?php if($row['completed'] == 0) echo "pending"; ?>" >
            	<td><strong>$<?php echo $row['amount']; ?></strong></td>
                <td><img src="<?php echo $set['home']; ?>/img/pmt-icons/<?php echo $row['method']; ?>.png" alt="" style="width:45px;"></td>
                <td><?php if ($row['completed'] == 1) echo "<strong class='active'>Completed!</strong>"; else echo "<strong class='pending'>Pending</strong>" ?></td>
                <td><?php datetime($row['datetime']); ?></td>
                <td><?php  if ($row['completed_time'] != '0000-00-00 00:00:00') datetime($row['completed_time']); ?></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
        <?php } else { ?>
        <h2>No referrals so far!</h2>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <?php } ?>
			
    </div><!-- .box -->
	
    <?php $url =  $set['home']. '/withdrawals/'; ?>
	<?php echo pagination($statement,$limit,$page,$url,1); ?>


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-account.php'); ?>
<?php include('footer.php');  ?>    