<?php 
include('includes/header_account.php');

$upload_files = true;

$number = mres($_GET['number']);
$order = get_order_info($number);

if (!isset($order['id'])) redirect($set['home'].'/account/');

$buyer = get_user_info($order['buyer_id']);
$seller = get_user_info($order['seller_id']);
$service = get_service_info($order['service_id']);

$page_title = "Your Order #" . $number;

$order_permalink = $set['home'].'/order/'.$number.'/';

if ($order['status'] == 'Active' && check_due($order['due_datetime'])) {
	$update = mysql_query("UPDATE `orders` SET `status` = 'Late' WHERE `id` = ".$order['id']);
	$order = get_order_info($number);
}

if ($seller['id'] == $user['id']) $i_am_seller = true;

if (isset($_POST['publish_review_seller'])) {
	
	$rating = mres($_POST['rating']);
	$review = mres($_POST['review']);
	$datetime = date('Y-m-d H:i:s');
	
	if ($review == '') $error[] = "Your review is required!";
	
	if (empty($error)) {
		$add_review = mysql_query("INSERT INTO `ratings` (
			`order_id`,
			`service_id`,
			`user_id`,
			`for_user_id`,
			`rating`,
			`review`,
			`datetime`
		) VALUES (
			'".$order['id']."',
			'".$service['id']."',
			'".$user['id']."',
			'".$buyer['id']."',
			'".$rating."',
			'".$review."',
			'".$datetime."'
			)");
			confirm_query($add_review);
		
		$update = mysql_query("UPDATE `orders` SET `seller_rated` = '1' WHERE `id` = " . $order['id']);
		confirm_query($update);
		$order = get_order_info($number);
	}
		
}

if (isset($_POST['publish_review'])) {
	
	$rating = mres($_POST['rating']);
	$review = mres($_POST['review']);
	
	if ($review == '') $error[] = "Your review is required!";
	
	$datetime = date('Y-m-d H:i:s');
	
	if (empty($error)){
		$add_review = mysql_query("INSERT INTO `ratings` (
			`order_id`,
			`service_id`,
			`user_id`,
			`for_user_id`,
			`rating`,
			`review`,
			`datetime`
		) VALUES (
			'".$order['id']."',
			'".$service['id']."',
			'".$user['id']."',
			'".$seller['id']."',
			'".$rating."',
			'".$review."',
			'".$datetime."'
			)");
		confirm_query($add_review);
	
	if ($order['status'] == 'Delivered') {
		complete_order($order['id'],false);
		update_rating($service['id'],'service');
		update_rating($service['user_id'],'user');
	}
	
	// update Order
	$update = mysql_query("UPDATE `orders` SET `buyer_rated` = '1' WHERE `id` = " . $order['id']);
	confirm_query($update);
	$order = get_order_info($number);
	
	$update_service = mysql_query("UPDATE `services` SET `reviews` = `reviews` + 1  WHERE `id` = " . $service['id']);
	confirm_query($update_service);
	
	$how_review = ($rating == 'up') ? 'positive' : 'negative';

	$noti_desc = $user['username'] .' Posted a '.$how_review. ' review on your order #'.$number;
	$noti_url =  '/order/'.$number.'/';
	$to_id = $seller['id'];
	add_noti($noti_desc,$to_id,$noti_url,$user['username'] . 'Posted a '.$how_review. ' review on your order');
	
	}
	$order = get_order_info($number);
}


if (isset($_POST['send_message'])) {
	
	$type = '';
	
	if (!isset($i_am_seller) && $order['info_submitted'] == 0) { // info submitted start the order!
	
	$delivery_datetime = date('Y-m-d H:i:s', strtotime(' +'.$order['duration'].' day'));
	
		$update = mysql_query("UPDATE `orders` SET 
			`info_submitted` = 1,
			`started_datetime` = '".date('Y-m-d H:i:s')."',
			`due_datetime` = '".$delivery_datetime."',
			`status` = 'Active' 
			 WHERE `id` = " . $order['id']);
		confirm_query($update);
		$order = get_order_info($number);
		$type = 'info_submitted';
		
		$noti_desc = 'Order Started! ' .$user['username'] .' Submitted the information for ordder ' . $number;
		$noti_url =  '/order/'.$number.'/';
		$to_id = $seller['id'];
		add_noti($noti_desc,$to_id,$noti_url,'Order Started!');
		
		$noti_added = true;
		
	}
	
	$rel_id = $order['id'];
	$user_id = $user['id'];
	$message = mres($_POST['message']);
	$datetime = date('Y-m-d H:i:s');
	if (isset($_POST['delivered'])) {
		$delivered = intval($_POST['delivered']);
	} else {
		$delivered =  false;
	}
	
	if (isset($i_am_seller) && $delivered == 1) { // info submitted start the order!
		
		$update = mysql_query("UPDATE `orders` SET 
			`status` = 'Delivered', 
			`delivered_datetime` = '".date('Y-m-d H:i:s')."' 
			 WHERE `id` = " . $order['id']);
		confirm_query($update);
		$order = get_order_info($number);
		$type = 'order_delivery';
		
		$noti_desc = 'Good News! ' . $seller['username']. ' just delivered your order.';
		$noti_url =  '/order/'.$number.'/';
		$to_id = $buyer['id'];
		add_noti($noti_desc,$to_id,$noti_url, $seller['username'] . ' delivered your order');
		$noti_added = true;
		
	}
	
	
	$add_msg = mysql_query("INSERT INTO `messages` (
		`order_id`,
		`user_id`,
		`message`,
		`type`,
		`datetime`
	) VALUES (
		'".$rel_id."',
		'".$user_id."',
		'".$message."',
		'".$type."',
		'".$datetime."'
		)");
	
	
	$rel_id = $order['id'];
	$last_id = mysql_insert_id();
	
	$attach_files = mysql_query("SELECT `id` FROM `files` WHERE `rel_id` = " .$rel_id." AND `user_id` = '".$user['id']."' AND `msg_id` = 0");
	if (mysql_num_rows($attach_files) > 0) {
		while ($file_row = mysql_fetch_array($attach_files))
		$update_file = mysql_query("UPDATE `files` SET `msg_id` = " . $last_id . " WHERE `id` = " . $file_row['id']);
	}
	
	if (!isset($noti_added)) {
		$noti_desc = 'Order ' . $number . ' was updated by ' .$user['username'];
		$noti_url =  '/order/'.$number.'/';
		$to_id = $seller['id'];
		if (isset($i_am_seller)) $to_id = $buyer['id'];
		add_noti($noti_desc,$to_id,$noti_url, 'Order updated by ' . $user['username']);
	}
	
	if (!$add_msg) $error[] = "Error sending Message " .mysql_error();
		
}

if (isset($_GET['cancel'])) {
	
	$cancel_val = intval($_GET['cancel']);
	
	if ($cancel_val == 2) {
		
		$update = mysql_query("UPDATE `orders` SET `buyer_cancelled` = 0, `seller_cancelled` = 0 WHERE `id` = " . $order['id']);
		$noti_desc = $user['username'] . ' declined your mutual cancelation request on order ' .$number;
		$noti_url = '/order/'.$number.'/';
		$to_id = isset($i_am_seller) ? $buyer['id'] : $seller['id'];
		add_noti($noti_desc,$to_id,$noti_url,$user['username'] . ' declined your mutual cancelation request');
			
	} else {
		
		if (!isset($i_am_seller) && $order['status'] == 'Late'){
			$update = mysql_query("UPDATE `orders` SET `status` = 'Cancelled' WHERE `id` = " . $order['id']);
			
			$noti_desc = 'Order #' . $number . ' is cancelled now!';
			$noti_url =  '/order/'.$number.'/';
			
			$to_id = $seller['id'];
			add_noti($noti_desc,$to_id,$noti_url,'Order Cancelled!');
			
			$update = mysql_query("UPDATE `users` SET `purchase_balance` = `purchase_balance` + ".$order['price']." WHERE `id` =" . $buyer['id']);
			
				$rating = 'down';
				$review = 'Cancelled the order! Seller faild to deliver on time.';
				$datetime = date('Y-m-d H:i:s');
				
				if (empty($error)){
					$add_review = mysql_query("INSERT INTO `ratings` (
						`order_id`,
						`service_id`,
						`user_id`,
						`for_user_id`,
						`rating`,
						`review`,
						`datetime`
					) VALUES (
						'".$order['id']."',
						'".$service['id']."',
						'".$user['id']."',
						'".$seller['id']."',
						'".$rating."',
						'".$review."',
						'".$datetime."'
						)");
					confirm_query($add_review);
					update_rating($service['id'],'service');
					update_rating($service['user_id'],'user');
					$update_service = mysql_query("UPDATE `services` SET `reviews` = `reviews` + 1 WHERE `id` =" . $service['id']);
					
				}
			
		}
	
		if (!isset($i_am_seller) && $order['seller_cancelled'] == 0){
			
			$update = mysql_query("UPDATE `orders` SET `buyer_cancelled` = ".$cancel_val." WHERE `id` = " . $order['id']);
			$noti_desc = 'Order ' . $number . ' was updated by ' .$user['username'];
			$noti_url =  '/order/'.$number.'/';
			$to_id = $seller['id'];
			add_noti($noti_desc,$to_id,$noti_url,'Order updated by ' .$user['username']);
				
		}
		
		if (isset($i_am_seller) && $order['buyer_cancelled'] == 0){
			
			$update = mysql_query("UPDATE `orders` SET `seller_cancelled` = ".$cancel_val." WHERE `id` = " . $order['id']);
			$noti_desc = 'Order ' . $number . ' was updated by ' .$user['username'];
			$noti_url =  '/order/'.$number.'/';
			$to_id = $buyer['id'];
			add_noti($noti_desc,$to_id,$noti_url,'Order updated by ' .$user['username']);
				
		}
		
		//
		
		if (!isset($i_am_seller) && $order['seller_cancelled'] == 1){
			
			
			if ($order['seller_cancelled'] == 'Completed') {
				refund_buyer($order['id']);
			}
			
			$update = mysql_query("UPDATE `orders` SET `status` = 'Cancelled', `buyer_cancelled` = ".$cancel_val." WHERE `id` = " . $order['id']);
			
			$noti_desc = 'Order ' . $number . ' is cancelled now!';
			$noti_url = '/order/'.$number.'/';
			
			$to_id = $seller['id'];
			add_noti($noti_desc,$to_id,$noti_url,'Order Cancelled!');
			$update = mysql_query("UPDATE `users` SET `purchase_balance` = `purchase_balance` + ".$order['price']." WHERE `id` =" . $buyer['id']);
			
			
			
		}
		
		if (isset($i_am_seller) && $order['buyer_cancelled'] == 1){
			
			if ($order['seller_cancelled'] == 'Completed') {
				refund_buyer($order['id']);
			}
			
			$update = mysql_query("UPDATE `orders` SET `status` = 'Cancelled', `seller_cancelled` = ".$cancel_val." WHERE `id` = " . $order['id']);
			
			$noti_desc = 'Order ' . $number . ' is cancelled now!';
			$noti_url =  '/order/'.$number.'/';
			
			$to_id = $buyer['id'];
			add_noti($noti_desc,$to_id,$noti_url,'Order Cancelled!');
			$update = mysql_query("UPDATE `users` SET `purchase_balance` = `purchase_balance` + ".$order['price']." WHERE `id` =" . $buyer['id']);

			
		}
	
	}
	
	redirect($order_permalink);
	
}

include('header.php');

display_error(); display_notice(); 

?>
<div class="side_content">
  
     <div class="box messages_wrap order_wrap">
     	<div class="order_price">$<?php echo $order['price']; ?></div>
        <div class="order_meta_wrap">
        <?php if (isset($i_am_seller)) { ?>
        <h2>Order #<?php echo $number; ?></h2>
    	<div class="order_meta"> 
	        <strong>Buyer:</strong> <a href="<?php echo user_permalink($buyer['id']); ?>"><?php echo $buyer['username']; ?></a> &nbsp; / &nbsp;
	        <strong>Created:</strong> <?php echo get_date($order['datetime'],'F j, Y'); ?>
		</div><!-- .order_meta -->
        <?php } else { ?>
        <h2>
        <?php if (isset($service['id'])) { ?>
        	<a href="<?php echo service_permalink($service['id']); ?>"><?php echo $service['title']; ?></a>
        <?php } else { ?>
        	Service Deleted!
        <?php } ?>
		</h2>
    	<div class="order_meta"> 
	        <strong>Seller:</strong> <a href="<?php echo user_permalink($seller['id']); ?>"><?php echo $seller['username']; ?></a> &nbsp; / &nbsp;
	        <strong>Order#:</strong> <?php echo $number; ?> &nbsp; / &nbsp;
	        <strong>Created:</strong> <?php echo get_date($order['datetime'],'F j, Y'); ?>
		</div><!-- .order_meta -->
        <?php } ?>
        </div><!-- .order_meta_wrap -->
     <div class="clear"></div>
     <div class="order_items">
     	<table class="data_table">
        	<tr class="head">
            	<td class="alignleft">Item</td>
                <td width="100">Duration</td>
                <td width="100">Amount</td>
            </tr>
            <tr class="even">
            	<td class="alignleft"><?php echo $service['title']; ?></td>
                <td<?php if ($order['extra_fast_bought'] == 1) echo' class="dell_text"';?>><?php echo $service['duration']; ?> Days</td>
                <td>$<?php echo $service['price']; ?></td>
            </tr>
            <?php for ($a=1;$a<=3;$a++) {
				if ($service['extra_'.$a.'_ticked']) { 
				if ($order['extra_'.$a.'_bought'] == 1) {
				?>
            <tr>
            	<td class="alignleft">
				<strong>[Extra]</strong> <?php echo $service['extra_'.$a.'_title']; ?></td>
                <td<?php if ($order['extra_fast_bought'] == 1) echo' class="dell_text"';?>><?php echo $service['extra_'.$a.'_duration']; ?> Days</td>
                <td>$<?php echo $service['extra_'.$a.'_price']; ?></td>
            </tr>
            <?php } } } ?>
            <tr class="even">
            	<td class="alignleft"></td>
                <td width="100"><strong>Total</strong></td>
                <td width="100"><strong>$<?php echo $order['price']; ?></strong></td>
            </tr>
            <?php if ($order['status'] == 'Active') { ?>
            <?php for ($a=1;$a<=3;$a++) {
				if ($service['extra_'.$a.'_ticked']) { 
				if (!isset($i_am_seller) && $order['extra_'.$a.'_bought'] != 1) {
				?>
            <tr<?php if ($order['extra_'.$a.'_bought'] == 0) echo' class="pending"'; ?>>
            	<td class="alignleft">
                <?php if ($order['extra_'.$a.'_bought'] == 0 && !isset($i_am_seller)) { ?>
                <a class="new_button buy_extra" data-extra="<?php echo $a; ?>" data-order="<?php echo $order['number']; ?>" onclick="return confirm('Are you sure you want to buy this extra?');">Buy Now</a>
                <span class="loading"></span>
                <?php } ?>
				<strong>[Extra]</strong> <?php echo $service['extra_'.$a.'_title']; ?></td>
                <td<?php if ($order['extra_fast_bought'] == 1) echo' class="dell_text"';?>><?php echo $service['extra_'.$a.'_duration']; ?> Days</td>
                <td>$<?php echo $service['extra_'.$a.'_price']; ?></td>
            </tr>
            <?php } } } ?>
            <?php if ($service['extra_fast_ticked']) {
				if (!isset($i_am_seller) || $order['extra_fast_bought'] == 1 ) {
				 ?>
            	<tr<?php if ($order['extra_fast_bought'] == 0) echo' class="pending"'; ?>>
            	<td class="alignleft">
                <?php if ($order['extra_fast_bought'] == 0 && !isset($i_am_seller)) { ?>
                <a data-extra="extra_fast" data-order="<?php echo $order['number']; ?>" class="new_button buy_extra">Buy Now</a> <span class="loading"></span>
                <?php } ?>
                <strong>[Extra Fast]</strong> I will deliver this order in just 
				</td>
                <td><strong><?php if ($service['extra_fast_duration'] == 0){
						 echo "No Additional Time";
				} else {
					$days = ($service['extra_fast_duration'] == 1) ? 'Day':'Days';
					echo $service['extra_fast_duration'].' '.$days;
				} ?></strong></td>
                <td><strong>$<?php echo $service['extra_fast_price']; ?></strong></td>
            </tr>
            <?php } }?>
            <?php } ?>
        </table>
     </div><!-- .order_items -->
     
     <div class="clear"></div>
     	
<?php 
if (!isset($i_am_seller) && $order['info_submitted'] == 0) {
	display_notice('Please provide the required information.'); 
} elseif (isset($i_am_seller) && $order['info_submitted'] == 0) {
	display_notice('We have asked buyer to provide the required information.'); 
}
?>      
 
<div class="message_box">
<div class="thumb">
	<a href="<?php echo user_permalink($seller['id']); ?>"><?php the_avatar($seller['id'],50); ?></a>
</div><!-- .thumb -->
<div class="info">
	<div class="user">
    	<span class="name"><a href="<?php echo user_permalink($seller['id']); ?>"><?php echo $seller['username'] ?></a></span>
    </div>
    <div class="clear"></div>
    <div class="message">Hi, please send me the following information to get started:<br><br><?php echo nl2br($service['instructions']); ?></div>
</div><!-- .info -->
<div class="clear"></div>
</div><!-- .message_box --> 
<?php
	
	  $check = mysql_query("SELECT * FROM `messages` WHERE `order_id` = " . $order['id']);
	  $first_count = 0; 
	  while ($row = mysql_fetch_array($check)) {
		  if ($row['user_id'] == $user['id']) {
			 $box_class = " my_msg";
		  } else {
			 $box_class = "";
		  }
		  include('includes/messages/message-box.php');
	  }
	  
	  
	  if ($order['status'] == 'Late') { ?>
      
      <div class="msg_note late_note">
      <?php if (isset($i_am_seller)) { ?>
        <h2>Your are Late!</h2>
        <p>Buyer may now cancel the order.</p>
     <?php } else { ?>
     	<h2>Delivery is Late!</h2>
        <p>You may now <a href="<?php echo $order_permalink; ?>/cancel/yes/">cancel</a> the order.</p>
     <?php } ?>
      </div><!-- .msg_note -->
      
      <?php }  ?>
	  
	  
	 <?php if ($order['status'] == 'Completed') { ?>
	  
	  	<div class="msg_note">
        	<h2>Order Completed!</h2>
            
            <p>This order is complete. Click  
            <?php if (isset($i_am_seller)) { ?>
            	<a href="<?php echo $set['home']; ?>/messages/<?php echo $buyer['username']; ?>/">here</a> to contact the buyer.
            <?php } else { ?>
            	<a href="<?php echo $set['home']; ?>/messages/<?php echo $seller['username']; ?>/">here</a> to contact the seller.
            <?php } ?>
            </p>
        </div><!-- .msg_note -->
	  	
	  <?php } ?>
	 
      <?php if ($order['status'] == 'Cancelled') { ?>
	  
	  	<div class="msg_note late_note">
        	<h2>Order Cancelled!</h2>
            <p>Payments are refunded! Click 
            <?php if (isset($i_am_seller)) { ?>
            	<a href="<?php echo $set['home']; ?>/messages/<?php echo $buyer['username']; ?>/">here</a> to contact the buyer.
            <?php } else { ?>
            	<a href="<?php echo $set['home']; ?>/messages/<?php echo $seller['username']; ?>/">here</a> to contact the seller.
            <?php } ?>
            </p>
        </div><!-- .msg_note -->
	  	
	  <?php } ?>
     
      
	 </div>

<?php 
	if (!isset($i_am_seller) && $order['status'] == 'Delivered') {
	$action_box = true;
?>
	<div class="box order_actions">
    Pending Action: 
    	<a href="#" class="new_button click_complete_order">Complete Order</a> or 
        <a href="#" class="new_button click_contact_seller">Contact Seller</a>
    </div><!-- .box -->
    
    <div class="box send_reply_box post_review_box">
        <form action="<?php echo $set['home']. '/order/'. $number. '/' ?>" method="post">
        <h3>How was your experience with this seller? 
          <input type="radio" name="rating" id="rating_up" value="up" /> <label for="rating_up">Good</label> &nbsp;
            <input type="radio" name="rating" id="rating_down" value="down" /> <label for="rating_down">Bad</label> &nbsp;</h3>
          <textarea name="review" rows="3" cols="40"></textarea>
          <div class="left">
              <input type="submit" name="publish_review" value="Publish Review" />
          </div>
          <div class="clear"></div>
        </form>
	</div><!-- .send_reply_box -->
<?php } ?>

<?php
if ($order['status'] == 'Completed' && $order['buyer_rated'] == 0 && !isset($i_am_seller)) {
?>

<div class="box send_reply_box post_review_box">
        <form action="<?php echo $set['home']. '/order/'. $number. '/' ?>" method="post">
        <h3>How was your experience with this seller? 
          <input type="radio" name="rating" id="rating_up" value="up" /> <label for="rating_up">Good</label> &nbsp;
            <input type="radio" name="rating" id="rating_down" value="down" /> <label for="rating_down">Bad</label> &nbsp;</h3>
          <textarea name="review" rows="3" cols="40"></textarea>
          <div class="left">
              <input type="submit" name="publish_review" value="Publish Review" />
          </div>
          <div class="clear"></div>
        </form>
	</div><!-- .send_reply_box -->
    
<?php } ?>

<?php if (isset($i_am_seller) && $order['buyer_cancelled'] == 1 && $order['status'] != 'Cancelled') {
	$action_box = true;
?>
	<div class="box order_actions">
    <h2>Buyer wants to mutually cancel the order</h2>
    Pending Action: 
    	<a href="<?php echo $order_permalink . 'cancel/yes/'; ?>" class="new_button">Accept</a> or 
    	<a href="<?php echo $order_permalink . 'cancel/decline/'; ?>" class="new_button">Decline</a> or <a href="#" class="new_button click_contact_seller">Contact Buyer</a>
    </div><!-- .box -->
<?php } elseif (!isset($i_am_seller) && $order['buyer_cancelled'] == 1 && $order['status'] != 'Cancelled') { 
	$action_box = true;
 ?>
	<div class="box order_actions">
    <h2>Cancelation request sent!</h2>
    <a href="<?php echo $order_permalink; ?>cancel/no/" class="new_button">Undo</a> or <a href="#" class="new_button click_contact_seller">Contact Seller</a>
    </div><!-- .box -->
	
<?php } ?>

<?php 
	if (!isset($i_am_seller) && $order['seller_cancelled'] == 1 && $order['status'] != 'Cancelled') {
	$action_box = true;
?>
	<div class="box order_actions">
    <h2>Seller wants to mutually cancel the order</h2>
    Pending Action: 
    	<a href="<?php echo $order_permalink . 'cancel/yes/'; ?>" class="new_button">Accept</a> or 
    	<a href="<?php echo $order_permalink . 'cancel/decline/'; ?>" class="new_button">Decline</a> or <a href="#" class="new_button click_contact_seller">Contact Seller</a>
    </div><!-- .box -->
<?php } elseif (isset($i_am_seller) && $order['seller_cancelled'] == 1 && $order['status'] != 'Cancelled') { 
	$action_box = true;
 ?>
	<div class="box order_actions">
    <h2>Cancelation request sent!</h2>
    <a href="<?php echo $order_permalink; ?>cancel/no/" class="new_button">Undo</a> or <a href="#" class="new_button click_contact_seller">Contact Buyer</a>
    </div><!-- .box -->
	
<?php } ?>
      
<?php

if ($order['status'] == 'Completed' && $order['buyer_rated'] == 1) { ?>

<div class="box messages_wrap order_wrap">
	<h2>Order Reviews</h2>
<?php  
$get_review = mysql_query("SELECT * FROM `ratings` WHERE `order_id` = '".$order['id']."' AND `user_id` = '".$buyer['id']."'");
$row_review = mysql_fetch_array($get_review);
  ?>
    
<div class="message_box">
<div class="thumb">
	<a href="<?php echo user_permalink($row_review['user_id']); ?>"><?php the_avatar($row_review['user_id'],50); ?></a>
</div><!-- .thumb -->
<div class="info">
	<div class="user"><a href="<?php echo user_permalink($buyer['id']); ?>"><?php echo $buyer['username'] ?></a></div>
    <div class="message">
		<div class="review_sign <?php echo $row_review['rating']; ?>"><?php echo $row_review['rating']; ?></div>
	    <div class="review_text"><?php echo stripslashes($row_review['review']); ?></div>
    <div class="clear"></div>
    </div>
</div><!-- .info -->
<div class="clear"></div>
</div><!-- .message_box --> 

<?php if ($order['seller_rated'] == 1) {
	$get_seller_review = mysql_query("SELECT * FROM `ratings` WHERE `order_id` = '".$order['id']."' AND `user_id` = '".$seller['id']."'");
$row_review_seller = mysql_fetch_array($get_seller_review);
 ?>
	
<div class="message_box">
<div class="thumb">
	<a href="<?php echo user_permalink($seller['id']); ?>"><?php the_avatar($seller['id'],50); ?></a>
</div><!-- .thumb -->
<div class="info">
	<div class="user"><a href="<?php echo user_permalink($buyer['id']); ?>"><?php echo $seller['username'] ?></a></div>
    <div class="message">
		<div class="review_sign <?php echo $row_review_seller['rating']; ?>"><?php echo $row_review_seller['rating']; ?></div>
	    <div class="review_text"><?php echo stripslashes($row_review_seller['review']); ?></div>
    <div class="clear"></div>
    </div>
</div><!-- .info -->
<div class="clear"></div>
</div><!-- .message_box --> 

<?php } ?>

</div><!-- .box -->
<?php if ($order['buyer_rated'] == 1 && $order['seller_rated'] == 0 && isset($i_am_seller)) { ?>
    <div class="box send_reply_box post_review_box">
        <form action="<?php echo $set['home']. '/order/'. $number. '/' ?>" method="post">
        <h3>How was your experience with this Buyer? 
          <input type="radio" name="rating" id="rating_up" checked="checked" value="up" /> <label for="rating_up">Good</label> &nbsp;
            <input type="radio" name="rating" id="rating_down" value="down" /> <label for="rating_down">Bad</label> &nbsp;</h3>
          <textarea name="review" rows="3" cols="40"></textarea>
          <div class="left">
              <input type="submit" name="publish_review_seller" value="Publish Review" />
          </div>
          <div class="clear"></div>
        </form>
	</div><!-- .send_reply_box -->
<?php } ?>
	
	
	
		
<?php
	
} elseif ($order['status'] != 'Cancelled' && $order['status'] != 'Completed') {

	  $form_submit_name = "send_message";
	  $form_url =  $set['home']. '/order/'. $number. '/';
	  include('includes/messages/send-message-box.php'); 

}
?>
         <div class="clear"></div>

<?php if (isset($i_am_seller) && $order['status'] != 'Completed' && $order['status'] != 'Cancelled') { ?>
	<div class="centered">View discussion with <a href="<?php echo $set['home']; ?>/messages/<?php echo $buyer['username']; ?>"><?php echo $buyer['username']; ?></a> in your inbox. 
    <?php if ($order['seller_cancelled'] == 0 && $order['buyer_cancelled'] == 0) { ?>
    Click <a href="<?php echo $order_permalink; ?>cancel/yes/" onclick="return confirm('Are you sure you want to cancel this order?');">here</a> if you want to mutually cancel the order.
    <?php } ?>
    </div>
<?php } elseif(!isset($i_am_seller) && $order['status'] != 'Completed' && $order['status'] != 'Cancelled') { ?>
	<div class="centered">View discussion with <a href="<?php echo $set['home']; ?>/messages/<?php echo $seller['username']; ?>"><?php echo $seller['username']; ?></a> in your inbox.
    <?php if ($order['seller_cancelled'] == 0 && $order['buyer_cancelled'] == 0) { ?>
    Click <a href="<?php echo $order_permalink; ?>cancel/yes/" onclick="return confirm('Are you sure you want to cancel this order?');">here</a> if you want to mutually cancel the order.
    <?php } ?>
    </div>
<?php } ?>

   
</div><!-- .side_content -->

<?php
$sidebar = "shopping";
if (isset($i_am_seller)) $sidebar = "sales";
include('includes/sidebars/sidebar-'.$sidebar.'.php'); 


if (isset($order['id'])){
    $file_rel_id = $order['id'];
} else {
	$file_rel_id = 0;	
}
$this_order_page = true;
include('footer.php'); 
?>