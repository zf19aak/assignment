<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');

if (!isset($_GET['username'])) redirect($set['home'].'/');

$username = mres($_GET['username']); 
$this_user = get_user_info($username,true);

if (!isset($this_user['id'])) redirect($set['home'].'/');

$page_title = $this_user['username'];
$meta_description = $this_user['description'];
include('header.php');

?>
</div>
<div class="main_box user_main_box">
<div class="wrap">

        	<div class="thumb">
            	<?php the_avatar($this_user['id'],80); ?> 
            </div><!-- .thumb -->
            <div class="info">
            	<div class="username">
	            	<?php echo $this_user['username']; ?>   
	            </div>
	            <div class="meta">
                	FROM: <?php $ip_info = json_decode(ip_json($this_user['last_ip']),true); echo $ip_info['geoplugin_countryName']; ?> <?php the_flag($this_user['last_ip']); ?> &nbsp; 
                  	 <?php if ($this_user['level'] != 'No Level') echo $this_user['level'] . ' Seller'; ?> &nbsp; 
                     <?php if ($this_user['rating'] != 0) echo $this_user['rating'] . '% Rating.'; ?> &nbsp;
                     <a href="<?php echo $set['home']; ?>/messages/<?php echo $this_user['username']; ?>/" class="new_button">CONTACT</a> 
	            </div>
            </div><!-- .info -->


        <div class="clear"></div>
</div><!-- .wrap -->    
</div><!-- .main_box -->

<div class="wrap user_wrap">

 
 	        <div class="desc">
	        	<p><?php echo $this_user['description']; ?></p>
	        </div><!-- .desc -->
 	
  <?php
  $query = mysql_query("SELECT * FROM `services` WHERE `user_id` = '".$this_user['id']."' AND `status` = 'Active'");
  if (mysql_num_rows($query) != 0) {
  ?>  
  <h2>Services Offered by <?php echo $this_user['username']; ?></h2>
  
  <div class="services_wrap">
  <?php
	while ($row = mysql_fetch_array($query)) {
		service_box($row);
    } ?> 
    <div class="clear"></div>
  </div><!-- .services_wrap -->
 <?php } ?>  
<?php include('footer.php'); ?>