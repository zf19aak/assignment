<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = "Recover your password";
$email_verify_page = true;

if (isset($_GET['key'],$_GET['code'])) {
	$key = mres($_GET['key']);
	$code = mres($_GET['code']);
	
	$check = mysql_query("SELECT `id` FROM `users` WHERE `password_verify_code` = '".$code."'");
	if (mysql_num_rows($check) == 1){
		$get_user = mysql_fetch_array($check);
		$this_user = get_user_info($get_user['id']);
		
		$user_key = strtoupper(md5($this_user['username'].$this_user['member_id'].$this_user['email']));
		$user_code = $this_user['password_verify_code'];
		
		if ($key == $user_key && $code == $user_code) {
			$_SESSION['pass_verified'] = true;
			$message = "Thank you for confirmation!";
		} else {
			$error[] = "Verification Faild!";
		}
		
	} else {
		$error[] = "Invalid verification code or expired!";
	}
	
} else {
	unset($_SESSION['pass_verified']);
}

if (isset($_POST['verified_submit'],$_SESSION['pass_verified'])) {
	
	$new_password = mres($_POST['new_password']);
	$confirm_password = mres($_POST['confirm_password']);
	
	if ($new_password == '' || $confirm_password == '') $error[] = "All fields are required";
	
	if ($new_password != $confirm_password) $error[] = "Confirm password didn't match";
	
	if (empty($error)){
		$save_password = sha1($new_password);
		$update_now = mysql_query("UPDATE `users` SET `password` = '".$save_password."' WHERE `id` = " . $this_user['id']);
		if (confirm_query($update_now)){
			unset($_SESSION['pass_verified']);
			add_noti('You have successfully reset your password.',$this_user['id'],'Password Reset!');
			redirect($set['home'] . '/sign-in/?reset');
		}
	}
		
}

if (isset($_POST['form_submit'])) {
	
	$this_email = mres($_POST['email']);
	if ($this_email == '') $error[] = "New email field cannot be empty.";
	
	$check = mysql_query("SELECT `username` FROM `users` WHERE `email` = '".$this_email."'");
	if (mysql_num_rows($check) == 1) {
		
		$get_user = mysql_fetch_array($check);
		$this_user = get_user_info($get_user['username'],true);
		
		send_password_request($this_user['id']);
		$message = 'Password recovery confirmation has been sent in email.';
		
			
	} else {
		$error[] = "Sorry, no user found!";
	}
	
} 

if (isset($_GET['resend'])) {
	
	send_email_verification($user['id']);
	$message = "<strong>DONE!</strong> Verification email has been sent again!";
	
}
	
//if (empty($error)) $error[] = '<strong>NOTE:</strong> Your email address is not confirmed yet. Please confirm your email address to continue using.' . $set['name'];
include('header.php'); 


?>

<div class="mid_box email_verify_box">

<?php display_message(); display_error();  ?>
    
    <div class="box recover_pass_box">
		<?php if (!isset($_SESSION['pass_verified'])) { ?>
        <h2>Recover your password</h2>
         <form action="<?php echo $set['home']; ?>/recover-password/" id="validate" method="post">
         <table class="activate_form show_email_table">
            <tr class="email_resend_field">
  				<td class="label"><input type="email" name="email" class="required" value="<?php if (isset($new_email)) echo $new_email; ?>" placeholder="Please enter your email" /></td>
                <td class="field">
                     <input type="submit" value="Send" name="form_submit" />
                </td>
  			</tr>
  		</table>
        </form>
        <?php } else { ?>
        <h2>Reset your password</h2>
        <form action="<?php echo $set['home']; ?>/recover-password/?key=<?php echo $key; ?>&code=<?php echo $code; ?>" id="validate" method="post">
         <table class="activate_form">
            <tr>
                <td class="field"><input type="password" name="new_password" class="required" value="<?php if (isset($new_email)) echo $new_email; ?>" placeholder="New Password" /></td>
            </tr>
            <tr>
                <td class="field"><input type="password" name="confirm_password" class="required" value="<?php if (isset($new_email)) echo $new_email; ?>" placeholder="Confirm Password" /></td>
			</tr>
            <tr>
                <td class="field"><input type="submit" value="Reset Password" name="verified_submit" /></td>
  			</tr>
  		</table>
        </form>
        <?php } ?>
         
         <div class="display_notice" style="margin-bottom:0;">If you are having any other issues, please contact <a href="<?php echo $set['home']; ?>/support/">support</a></div>
         
</div><!-- .box -->
	    
</div><!-- .activate_box -->

<div class="clear"></div>

<?php include('footer.php');  ?>    