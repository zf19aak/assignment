<?php 
$front_page = true; 
include('header.php'); 
display_message(); display_error(); 
?>

<?php if (is_loggedin()) { ?>
  <h2 class="centered front_heading">Recent Services</h2>
  <div class="services_wrap">
  <?php
    $count = 0;
  	$query = mysql_query("SELECT * FROM `services` WHERE `status` = 'Active' ORDER BY `id` DESC LIMIT 16");
	while ($row = mysql_fetch_array($query)) {
		service_box($row);
		$count++;
		if ($count == 4) {
			echo '<div class="clear"></div>'; 
			$count = 0;
		}
		 }
   ?> 
    <div class="clear"></div>
  </div><!-- .services_wrap -->
  <div class="centered">
  	<a href="<?php echo $set['home']; ?>/services/" class="new_button">Explore All Services</a>
  </div>
<?php } ?>

<?php if (!is_loggedin()) { ?>
  
  <div class="front_steps">
  	<ul>
		<li><strong>1</strong> Choose your provider</li>
		<li><strong>2</strong> Supply your brief</li>
		<li class="last"><strong>3</strong> Get work done</li>
    </ul>
  </div><!-- .front_steps -->

<?php } ?>
  
  <h2 class="centered front_heading">Popular Categories</h2>
  
  <div class="front_cats_wrap">
  	
    	<div class="cat_box box">
        	<?php $this_cat = get_category_info(6); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
	            <img src="<?php echo $set['home']; ?>/img/categories/graphics-designing.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
	            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box box -->
        <div class="cat_box box">
        	<?php $this_cat = get_category_info(16); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
	            <img src="<?php echo $set['home']; ?>/img/categories/programming-it.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
	            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box box -->
        <div class="cat_box box">
          	<?php $this_cat = get_category_info(31); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
            <img src="<?php echo $set['home']; ?>/img/categories/creative-art.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box -->
        <div class="cat_box box">
        	<?php $this_cat = get_category_info(52); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
            <img src="<?php echo $set['home']; ?>/img/categories/writing-translation.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box box -->
        <div class="cat_box box">
        	<?php $this_cat = get_category_info(85); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
        	<img src="<?php echo $set['home']; ?>/img/categories/advertising.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box box -->
        <div class="cat_box box">
        	<?php $this_cat = get_category_info(95); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
            <img src="<?php echo $set['home']; ?>/img/categories/business.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box box -->
        <div class="cat_box box">
        	<?php $this_cat = get_category_info(74); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
            <img src="<?php echo $set['home']; ?>/img/categories/music-audio.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box box -->
        <div class="cat_box box">
        	<?php $this_cat = get_category_info(65); ?>
        	<a href="<?php echo category_url($this_cat['id']); ?>">
            <img src="<?php echo $set['home']; ?>/img/categories/video-animation.jpg" width="219" height="129" alt="<?php echo $this_cat['name']; ?>">
            <strong><?php echo $this_cat['name']; ?></strong> <span><?php echo count_all_approved_services('cat_id',$this_cat['id']); ?> Services</span>
            </a>
        </div><!-- .cat_box box -->
        
    <div class="clear"></div>
  </div><!-- .front_cats_wrap -->

  <div class="guarantee_box">
  	<img src="<?php data_image('img/money-back-guarantee.png','png'); ?>" width="120" height="119" title="Get your work done or your money back!" alt="100% money back guarantee">
    <h2 class="main_title" title="Get your work done or your money back!">100% Money Back GUARANTEE</h2>
  </div><!-- .guarantee_box -->

<?php if (!is_loggedin()) { ?>
  <h2 class="centered front_heading">Recent Services</h2>
  <div class="services_wrap">
  <?php
  	$query = mysql_query("SELECT * FROM `services` WHERE `status` = 'Active' ORDER BY `id` DESC LIMIT 16");
	$count = 0;
	while ($row = mysql_fetch_array($query)) {
		service_box($row);
		$count++;
		if ($count == 4) {
			echo '<div class="clear"></div>'; 
			$count = 0;
		}
	}
	?> 
    <div class="clear"></div>
  </div><!-- .services_wrap -->
  <div class="centered">
  	<a href="<?php echo $set['home']; ?>/services/" class="new_button">Explore All Services</a>
  </div>
<?php } ?>
  
<?php include('footer.php'); ?>