<?php
require_once('includes/connection.php');
require_once('includes/functions.php');

$code = mres($_GET['code']);

$file = get_file_info($code,true);

if ($file['id']) {

$directory = "uploads/attachments/";

$file_location = $directory . $file['name'];

$new_filename = get_original_file_name($file['name']);

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.$new_filename.'"');
header('Content-Length: ' . filesize($file_location));
readfile($file_location);

} else {
	redirect($set['home'].'/not-found/');
}
?>