<div class="sidebar forum_sidebar">
<?php if (isset($cat_slug)) { 
		$add_cat = get_forum_category_info($cat_slug,true);
		$cdd_cat_var = '?category='.$add_cat['id'];
	} else {
		$cdd_cat_var = '';	
	}
?>

<a href="<?php echo $set['home'] . "/forum/new-topic/".$cdd_cat_var; ?>" class="button">Start a New Topic</a>

    <h2>Categories</h2>
    <ul>
    <?php $result = mysql_query("SELECT * FROM `forum_categories` ORDER BY `position` ASC"); 
			while ($row = mysql_fetch_array($result)) : ?>
            <li><a href="<?php echo $set['home']; ?>/forum/<?php echo $row['slug']; ?>/"><?php echo $row['name']; ?></a></li>
    <?php endwhile; ?>
    </ul>
    
    <h2>Facebook</h2>
    
    <div class="side_fb">
    	<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fetallu&amp;width=181&amp;height=305&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=true" style="border:none; overflow:hidden; width:181px; height:305px;" allowTransparency="true"></iframe>
    </div><!-- .side_fb -->
    
</div><!-- .sidebar -->

<div class="clear"></div>