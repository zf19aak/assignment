<div class="forum_box">
        	<div class="thumb">
            <?php $by_user = get_user_info($row_again['user_id']); ?>
            <?php if ( $by_user['avatar'] != '') { ?>
            	<img src="<?php echo $set['home']; ?>/img/avatars/<?php echo $by_user['avatar']; ?>" alt="" />
            <?php } else { ?>
            	<img src="<?php echo get_gravatar($by_user['email'],80); ?>" alt="" />
            <?php } ?>
            </div>
            <div class="title">
            
            <?php $permalink = $set['home'] . '/topic-' . $row_again['id'] . '/' . make_slug(stripslashes($row_again['title'])) . '/'; ?>
            
            	<a href="<?php echo topic_permalink($row_again['id']); ?>">
                <?php if ($row_again['closed'] == 1) { ?>
                <img src="<?php echo $set['home']; ?>/img/forum/locked.png" title="Topic is closed" alt="Closed" />
                <?php } ?>
				<?php echo stripslashes($row_again['title']); ?>
                </a>
                
	            <div class="meta">
	            	Started By: <strong><?php echo $by_user['username']; ?></strong>  
                    <?php if ($row_again['last_user_id'] != 0) {
						$last_user = get_user_info($row_again['last_user_id']); ?>
                        &nbsp; Last Reply: <strong><?php echo $last_user['username']; ?></strong>
                    <?php } ?>
                    <?php datetime($row_again['updated']); ?>
                    
	            </div>
            </div>
            <div class="posted">
            	<div class="replies"><strong class="big"><?php echo stripslashes($row_again['replies']); ?></strong> 
                <?php if ($row_again['replies'] == 1) {
					echo "Reply";
				} else {
					echo "Replies";
				} ?>
                </div>
            	 
            </div>
        </div><!-- .forum_box -->