<div class="box">

<?php if ($topic['closed'] == 1) { echo "<strong>Sorry, Topic is closed!</strong>"; } else { ?>
<?php if (is_loggedin()) { ?>
  <div class="forum_box reply_box">
      <h2>Post a Reply</h2>
	  <div class="reply_box_top"></div>
  
  <?php if ($user['email_verified'] == 0) { ?>
  Sorry, Your email address is not confirmed yet <a href="<?php echo $set['home']; ?>/verify-email/"><strong>Please Verify Email</strong></a>.
  <?php } else { ?>
  
      <div class="thumb">
          <?php if ( $user['avatar'] != '') { ?>
            	<img src="<?php echo $set['home']; ?>/img/avatars/<?php echo $user['avatar']; ?>" alt="" />
            <?php } else { ?>
            	<img src="<?php echo get_gravatar($user['email'],80); ?>" alt="" />
            <?php } ?>
      </div>
      <div class="details">
      <form action="<?php echo $last_page_link; ?>" method="post">
          <textarea class="animate" name="reply" rows="5" cols="15"></textarea>
          <input type="submit" name="post_reply" value="Post Reply" />
      </form>
      </div>

<?php } ?>
  </div><!-- .forum_box -->
<?php } else { ?>
    You must <a href="<?php echo $set['home']; ?>/sign-in/must/topic-<?php echo $topic['id']; ?>/">Sign In</a> to reply.
<?php } ?>
  
<?php } ?>

</div><!-- .box -->