<?php 
require_once('../includes/connection.php');
require_once('../includes/functions.php');
require_once('includes/forum-functions.php');

$page_title = "Edit Reply";
$nofollow = true;

if (!is_loggedin()) { redirect($set['home'].'/sign-in/'); } else {
$user = get_loggedin_info();
if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");	
}

$edit_id = intval($_GET['id']);

$edit_result = mysql_query("SELECT * FROM `forum_replies` WHERE `id` = ".$edit_id);
$edit_row = mysql_fetch_array($edit_result);

$edit_user = get_user_info($edit_row['user_id']);


if (forum_mod($edit_user['id'])) {

if (isset($_GET['del']) && $_GET['topic'] && forum_mod()) {
	
	$return_id = intval($_GET['topic']);
	
	$get_user_result = mysql_query('SELECT `user_id` FROM `forum_replies` WHERE `id`='.$edit_id);
	$got_user = mysql_fetch_array($get_user_result);
	$update_user = mysql_query("UPDATE `users` SET `forum_posts` = `forum_posts` - 1 WHERE `id` = " .$got_user['user_id']);
	if (!$update_user) die("Error:".mysql_error());
	
	$get_topic_replies = mysql_query('SELECT `replies`,`datetime` FROM `forum_topics` WHERE `id` = ' . $return_id);
	confirm_query($get_topic_replies);
	$got_replies = mysql_fetch_array($get_topic_replies);
	
	if ($got_replies['replies'] == 1) {
	 $update_topic = mysql_query("UPDATE `forum_topics` SET `replies` = 0, `last_user_id` = 0, `updated` = '".$got_replies['datetime']."' WHERE `id` = " . $return_id);
	 confirm_query($update_topic);
	} else {
	 $update_topic = mysql_query('UPDATE `forum_topics` SET `replies` = `replies` - 1 WHERE `id` = ' . $return_id);
	 confirm_query($update_topic);
	}
	
	
	$del = mysql_query("DELETE FROM `forum_replies` WHERE `id`=".$edit_id);
	if (confirm_query($del) && confirm_query($update_topic)){
		$return_url = topic_permalink($return_id);
		redirect($return_url);
	}
		
}
	
if (isset($_POST['edit_submit'])) :

$content = mres($_POST['content']);
$user_id = $user['id'];
$edited = date('Y-m-d H:i:s');

if ( $content == '') {
	$error[] = "All Fields are required!";
}

if (empty($error)){
	
	$result = mysql_query("UPDATE `forum_replies` SET `content` = '".$content."', `edited` = '".$edited."' WHERE `id` = " . $edit_id);
	
	if (confirm_query($result)) {
		$message = "Successfully Edited";
		
		$edit_result = mysql_query("SELECT `content`,`topic_id` FROM `forum_replies` WHERE `id` = ".$edit_id);
		$edit_row = mysql_fetch_array($edit_result);
		redirect(topic_permalink($edit_row['topic_id']));
		
	}
}

endif;
include('../header.php'); 
?>
  
<div class="activate_box new_topic_box edit_reply_box">
	
    <?php display_error(); display_message(); display_notice(); ?>
    
    <div class="box">

    	<h2>Edit a Reply by (<?php if ($edit_user['username'] == $user['username']) echo "You"; else echo $edit_user['username']; ?>)</h2>
        <form class="<?php echo $set['home']; ?>/forum-edit-message/?id=<?php echo $edit_id; ?>" method="post">
  		<table class="activate_form">
            <tr>
                <td class="field">
                    <textarea name="content" cols="28" rows="8"><?php echo stripslashes($edit_row['content']); ?></textarea>
                </td>
  			</tr>
            <tr class="last_row">
                <td><input type="submit" value="Edit" name="edit_submit" /></td>
            </tr>
  		</table>
         </form>
         
    </div><!-- .box -->
    
</div><!-- .activate_box -->

<?php } else {
	redirect($set['home'].'/forum/');	
}
?>

<?php include('../footer.php');  ?>  

  