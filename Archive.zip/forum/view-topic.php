<?php 
require_once('../includes/connection.php');
require_once('../includes/functions.php');
require_once('includes/forum-functions.php');

$id = mres(intval($_GET['id']));

if (!get_topic_info($id)) {
	$_SESSION['topic_deleted'] = true;
	redirect($set['home'].'/forum/');
}

$topic = get_topic_info($id);
$category = get_forum_category_info($topic['cat_id']);

	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = 10;
	$startpoint = ($page * $limit) - $limit;
	
	$statement = "`forum_replies` WHERE `topic_id` = '".$topic['id']."' ORDER BY `id` ASC";
	$query = "SELECT COUNT(*) as `num` FROM {$statement}";
   	$quick_row = mysql_fetch_array(mysql_query($query));
   	$total = $quick_row['num'];
	$lastpage = ceil($total/$limit);
		
$page_title = $topic['title'] . ' - ' . $category['name'] . ' - Forum';

//$remove = array("\n", "\r\n", "\r");
//$meta_content = str_replace($remove, '', stripslashes($topic['content']));
//$meta_content = strip_tags($meta_content);
//$meta_desc = limit_words($meta_content,25);

if (is_loggedin()) {
	$user = get_loggedin_info();
	//if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");
 }
 
if (isset($_GET['mod']) && isset($user['forum_mod'])) :
if ($user['forum_mod'] == 1) {


	if ($_GET['mod'] == 'close') {
		$do_mod = mysql_query("UPDATE `forum_topics` SET `closed` = 1 WHERE `id` =".$id);
	} elseif ($_GET['mod'] == 'open') {
		$do_mod = mysql_query("UPDATE `forum_topics` SET `closed` = 0 WHERE `id` =".$id);
	}
	
	if (confirm_query($do_mod)) {
		$message = "Successfully Done!";
	}
	
	$topic = get_topic_info($id);

}
endif;

if (isset($_POST['post_reply'])) :

$user_id = $user['id'];
$reply = mres($_POST['reply']);
$datetime = date('Y-m-d H:i:s');

if (empty($error) && $topic['closed'] == 0) {
	
	$result = mysql_query("INSERT INTO `forum_replies` (
	`topic_id`,
	`user_id`,
	`content`,
	`datetime`
	) VALUES (
	'".$topic['id']."',
	'".$user_id."',
	'".$reply."',
	'".$datetime."'
	)");
	
	if (confirm_query($result)){
		$new_replies = $topic['replies'] + 1;
		$update_topid = mysql_query("UPDATE `forum_topics` SET `last_user_id` = '".$user_id."', `updated` = '".$datetime."', `replies` = '".$new_replies."' WHERE `id` = " . $id);
		
		$new_posts = $user['forum_posts'] + 1;
		$posts_uipdate = mysql_query("UPDATE `users` SET `forum_posts` = '".$new_posts."' WHERE `id` = ".$user_id);
		
		if (confirm_query($update_topid) && confirm_query($posts_uipdate)){
			$message = "Successfully Posted!";
		}
		
		$user = get_loggedin_info();
		
		$statement = "`forum_replies` WHERE `topic_id` = '".$topic['id']."' ORDER BY `id` ASC";
		$query = "SELECT COUNT(*) as `num` FROM {$statement}";
	   	$quick_row = mysql_fetch_array(mysql_query($query));
	   	$total = $quick_row['num'];
		$lastpage = ceil($total/$limit);
		if ($page != $lastpage) redirect(topic_permalink($topic['id']).'page/'.$lastpage.'/');
		
	}
	
}

endif;

include('../header.php'); 

?>
<div class="side_content forum_content">  

<?php $permalink = topic_permalink($topic['id']) ?>

<?php display_error();  display_message(); display_notice(); ?>
  
  <?php if (is_loggedin()) { ?>
  
  <?php if ($topic['cat_id'] == 1) { ?>
  
  
	  <?php if ($user['role'] == 'admin') { ?>
      
	  <div class="box topic_title">
	  	<?php if ($topic['closed'] == 1) { ?>
	    	<strong>Topic is now Closed!</strong> <a href="<?php echo $permalink; ?>mod/open/" onclick="return confirm('Are you sure?')">Open Topic</a>
	    <?php } else { ?>
	    	<a href="<?php echo $permalink; ?>mod/close/" onclick="return confirm('Are you sure?')">Close Topic</a>
	    <?php } ?>
         <?php echo $topic['views']; ?> Views
        
        <span class="right"> 
        <a href="<?php echo $set['home']; ?>/forum/edit-topic.php?id=<?php echo $topic['id']; ?>&del=true&topic=<?php echo $topic['id']; ?>" onclick="return confirm('Are you sure?')" class="del_link">Delete Topic</a>  										</span> 
		<div class="clear"></div>
	  </div>
		<?php } ?>
                 
                 
      <?php } else {?>
	
	<?php if ($user['forum_mod'] == 1) { ?>
	  <div class="box topic_title">
	  	<?php if ($topic['closed'] == 1) { ?>
	    	<strong>Topic is now Closed!</strong> <a href="<?php echo $permalink; ?>mod/open/" onclick="return confirm('Are you sure?')">Open Topic</a>
	    <?php } else { ?>
	    	<a href="<?php echo $permalink; ?>mod/close/" onclick="return confirm('Are you sure?')">Close Topic</a>
	    <?php } ?>
         <?php echo $topic['views']; ?> Views
        
        <span class="right"> <?php if  (forum_mod()) { ?>
        <a href="<?php echo $set['home']; ?>/forum/edit-topic.php?id=<?php echo $topic['id']; ?>&del=true&topic=<?php echo $topic['id']; ?>" onclick="return confirm('Are you sure?')" class="del_link">Delete Topic</a>  										<?php } ?>
      </span>
        <div class="clear"></div>
	  </div>
      <?php } ?>
                 
        
	  <?php } ?>
  <?php } ?>
  

  
  <div class="box topic_title">
  	<div class="bread_crumbs">
       <a href="<?php echo $set['home']; ?>/forum/">Forum</a> <span>&raquo;</span> 
       <a href="<?php echo $set['home']; ?>/forum/<?php echo $category['slug']; ?>/"> <?php echo $category['name']; ?></a> <span>&raquo;</span> 
    </div><!-- .bread_crumbs -->
  	<h2>
    <?php if ($topic['closed'] == 1) { ?>
           <img src="<?php echo $set['home']; ?>/img/forum/locked.png" title="Topic is closed" alt="Closed" />
       <?php } ?>
	<?php echo $topic['title']; ?></h2>
  </div>
   
    
    <?php 
	
	$statement = "`forum_replies` WHERE `topic_id` = '".$topic['id']."' ORDER BY `id` ASC";
	$query = "SELECT COUNT(*) as `num` FROM {$statement}";
   	$quick_row = mysql_fetch_array(mysql_query($query));
   	$total = $quick_row['num'];
	$lastpage = ceil($total/$limit);
	
	$get_reply = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$replies_count = mysql_num_rows($get_reply);
		
		if ($replies_count != 0 ){
		while ($reply_row = mysql_fetch_array($get_reply)) : 
			
			forum_message_box($reply_row);
		
		endwhile;
		}
	 ?>
    
    <?php
		
		if ($lastpage > 1) {
			$last_page_link = $permalink."page/".$lastpage."/";
		} else {
			$last_page_link = $permalink;
		}
		
	?>	
    
    <?php $url = $permalink . '/'; ?>
    <?php echo pagination($statement,$limit,$page, $url, 1); ?>
    <?php if ($page == $lastpage || $total <= $limit) { 
		 include('includes/forum-reply-box.php');
	 } else { 
		 if ($topic['closed'] == 1) {
			 echo "<div class='box'><strong>Sorry, Topic is closed!</strong></div>";
		 } elseif(is_loggedin()) {
		 	 echo "<a href='".$last_page_link."' class='button right'>Post a Reply</a>";
		 } else {
			 echo "<a href='".$set['home']."/sign-in/must/topic-".$topic['id']."/' class='button not_loggedin right'>Post a Reply</a>";
		 }
	 }?>
     <div class="clear"></div>

</div><!-- .side_content -->

<?php 

if (!isset($_GET['page']) && !isset($_GET['mod'])) {
	$new_view = $topic['views'] + 1;
	$views_result = mysql_query("UPDATE `forum_topics` SET `views` = '".$new_view."' WHERE `id`=".$topic['id']);
	confirm_query($views_result);
}

include('includes/forum-sidebar.php');  
include('../footer.php');
?>    