<?php 
$page_title = "Edit Topic";
$nofollow = true;
include('../header.php'); 
if (!is_loggedin()) { redirect($set['home'].'/sign-in/'); } else {
$user = get_loggedin_info();
if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");	
}


$edit_id = intval($_GET['id']);

$edit_result = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = ".$edit_id);
$edit_row = mysql_fetch_array($edit_result);

$edit_user = get_user_info($edit_row['user_id']);

if (forum_mod($edit_user['id'])) {

$result = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = ". $edit_id);
$row = mysql_fetch_array($result);

if ($row['cat_id'] == 1 && $user['role'] != 'admin') {
	$error[] = "You do not have access to edit this topic.";
	$no_access = true;
}

if (isset($_GET['del_confirm']) && forum_mod()) {


$get_cat = mysql_query("SELECT * FROM `forum_categories` WHERE `id` = " . $row['cat_id']);
$cat_row = mysql_fetch_array($get_cat);

if ($cat_row['id'] == 1) {
	
	if ($user['role'] == 'admin'){
		$del = mysql_query("DELETE FROM `forum_topics` WHERE `id`=".$edit_id);
		if (confirm_query($del)){
			$del_replies = mysql_query("DELETE FROM `forum_replies` WHERE `topic_id` = ".$edit_id);
			if (confirm_query($del)){
				redirect($set['home']."/forum/");
			}
		}	
	} else {
		$error[] = "You do not have access to delete this topic.";
	}
	
} else {
	
	$del = mysql_query("DELETE FROM `forum_topics` WHERE `id`=".$edit_id);
	  if (confirm_query($del)){
		  $del_replies = mysql_query("DELETE FROM `forum_replies` WHERE `topic_id` = ".$edit_id);
		  if (confirm_query($del)){
			  redirect($set['home']."/forum/");
		  }
	  }
		
}
	
	
		
}
	
if (isset($_POST['edit_submit'])) :

$content = mres($_POST['content']);
$user_id = $user['id'];
$edited = date('Y-m-d H:i:s');

if ( $content == '') {
	$error[] = "All Fields are required!";
}

if (empty($error)){
	
	$result = mysql_query("UPDATE `forum_topics` SET `content` = '".$content."', `edited` = '".$edited."' WHERE `id` = " . $edit_id);
	
	if (confirm_query($result)) {
		$message = "Successfully Edited";
		
		$edit_result = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = ".$edit_id);
		$edit_row = mysql_fetch_array($edit_result);
		
	}
}

endif;

if (isset($_GET['del'])){
	$topic_id = intval($_GET['topic']);
$error[] = "Are you sure you want to delete this topic? <strong><a href='edit-topic.php?id=".$edit_id."&del_confirm=true'>Yes</a> &nbsp; <a href='".get_topic_link($topic_id)."/'>No</a></strong>";
}

?>

<div class="activate_box new_topic_box edit_reply_box">
	
    <?php display_error(); display_notice(); display_message(); ?>
    
    <div class="box">

    	<h2>Edit a Topic by (<?php if ($edit_user['username'] == $user['username']) echo "You"; else echo $edit_user['username']; ?>)</h2>
        <form class="<?php echo $set['home']; ?>/edit-reply.php?id=<?php echo $edit_id; ?>" method="post">
  		<table class="activate_form">
            <tr>
                <td class="field">
                    <textarea<?php if (isset($no_access)) echo ' disabled="disabled"'; ?>  name="content" cols="28" rows="8"><?php // echo stripslashes($edit_row['content']); ?></textarea>
                </td>
  			</tr>
            <tr class="last_row">
                <td><input type="submit" value="Edit" name="edit_submit" /></td>
            </tr>
  		</table>
         </form>
         
    </div><!-- .box -->
    
</div><!-- .activate_box -->

<?php } else {
	redirect($set['home'].'/forum/');	
}
?>

<?php include('../footer.php');  ?>
<?php if (isset($no_access)) { redirect($set['home']. "/forum/",2); } ?>

  