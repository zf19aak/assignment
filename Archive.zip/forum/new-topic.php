<?php 
require_once('../includes/connection.php');
require_once('../includes/functions.php');
require_once('includes/forum-functions.php');

if (isset($_GET['category'])) {
 	$in_category = intval($_GET['category']);
	if ($in_category == '') {
	 	unset($in_category);
	} else {
		$cat_id = $in_category;	
	}
	
}

$page_title = "Start a New Topic";
$meta_desc = "Add new forum topic! " . $set['meta_desc'];
check_login();

$user = get_loggedin_info();

if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");


if (isset($_POST['form_submit'])) :

$title = mres($_POST['title']);
$content = mres($_POST['content']);
$cat_id = mres($_POST['cat_id']);
$user_id = $user['id'];
$datetime = date('Y-m-d H:i:s');

if ( $title == '' || $content == '' || $cat_id == '') {
	$error[] = "All Fields are required!";
}

if ( $cat_id == '1' && $user['role'] != 'admin') {
	$error[] = "Sorry, you are not allowed to post topic in this category.";
}

if (empty($error)){
	
	$add_topic = mysql_query("INSERT INTO `forum_topics` (
		`title`, 
		`cat_id`, 
		`user_id`, 
		`datetime`, 
		`updated`
		) VALUES ( 
		'".$title."', 
		'".$cat_id."', 
		'".$user_id."',
		'".$datetime."', 
		'".$datetime."'
		 )");
	
	confirm_query($add_topic);

	$topic_id = mysql_insert_id();
	$add_reply = mysql_query("INSERT INTO `forum_replies` (
	`topic_id`,
	`user_id`,
	`content`,
	`datetime`
	) VALUES (
	'".$topic_id."',
	'".$user_id."',
	'".$content."',
	'".$datetime."'
	)");
	confirm_query($add_reply);
	
	$update_user = mysql_query("UPDATE `users` SET `forum_posts` = `forum_posts` + 1 WHERE `id` = ".$user['id']);
	
	if (confirm_query($add_topic) && confirm_query($update_user) && confirm_query($add_reply)) {
		$category = get_forum_category_info($cat_id);
		redirect($set['home'].'/forum/'.$category['slug'].'/');
	}
}

endif;
include('../header.php'); 
?>
  
<div class="activate_box new_topic_box">
	
    <?php display_error(); display_notice(); ?>
    
    <div class="box">

    	<h2>Start a New Topic</h2>
        <form class="<?php echo $set['home']; ?>/forum/new-topic/" method="post">
  		<table class="activate_form">
  			<tr>
  				<td class="label">Title:</td>
                <td class="field"><input type="text" required="required" name="title" value="<?php if (isset($title)) echo stripslashes($title); ?>" /></td>
  			</tr>
            <tr>
  				<td class="label">Select Category:</td>
                <td class="field"><select name="cat_id">
                <?php 
				if ($user['role'] == 'admin') {
					$result = mysql_query("SELECT `id`,`name` FROM `forum_categories` WHERE `id` = 1");
				} else {
					$result = mysql_query("SELECT `id`,`name` FROM `forum_categories` WHERE `id` != 1");
				}
					
					while ($row = mysql_fetch_array($result)) {
						if (isset($cat_id)){
							if ($cat_id == $row['id']) $selected = 'selected="selected"'; else $selected = ''; 
						} else {
							$selected = '';
						}
						
					echo "<option ".$selected." value='".$row['id']."'>".$row['name']."</option>";
					}
				 ?>
                  </select>
                </td>
  			</tr>
            <tr>
  				<td class="label" valign="top">Details:</td>
                <td class="field">
                    <textarea name="content" required="required" cols="30" rows="10"><?php if (isset($content)) echo stripslashes($content); ?></textarea>
                </td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo $set['home']; ?>/forum/">Cancel</a></td>
                <td><input type="submit" value="Create Topic" name="form_submit" /></td>
            </tr>
  		</table>
         </form>
         
    </div><!-- .box -->
    
</div><!-- .activate_box -->

<?php include('../footer.php');  ?>    