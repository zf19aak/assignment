<?php 
require_once('../includes/connection.php');
require_once('../includes/functions.php');
require_once('includes/forum-functions.php');

$page_title = "Forum";
$meta_desc = "All forum discussions here." . $set['meta_desc'];
if (isset($_GET['cat'])) $cat_slug = mres($_GET['cat']); 

if (isset($_SESSION['topic_deleted'])) {
	$error[] = "Sorry, That topic doesn't exist";
	unset($_SESSION['topic_deleted']);
}

include('../header.php');
display_notice(); display_error();
?>
<div class="side_content forum_content">  

    <?php if (isset($cat_slug)) :
	$get_cat = mysql_query("SELECT * FROM `forum_categories` WHERE `slug` = '{$cat_slug}'");
	confirm_query($get_cat);
	$cat_row = mysql_fetch_array($get_cat);
	 ?>
	
    <div class="box">
    	 <div class="bread_crumbs">
         	<a href="<?php echo $set['home']; ?>/forum/">Forum</a> &raquo; 
            <a href="<?php echo $set['home']; ?>/forum/<?php echo $cat_id; ?>/"><?php echo $cat_row['name']; ?></a>
         </div><!-- .bread_crumbs -->
    </div>
    
	<?php
		echo "<div class='box forum_wrap'>";
		
		echo "<h2>" . $cat_row['name']. "<span class='inside'>".$cat_row['description']."</span></h2>";
		
		
		$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
		$limit = 12;
		$startpoint = ($page * $limit) - $limit;
	 	
 
		$statement = "`forum_topics` WHERE `cat_id` = '".$cat_row['id']."' ORDER BY `updated` DESC";
		
	 	$cat_result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
		confirm_query($cat_result);
		
		if (mysql_num_rows($cat_result) == 0) {
				echo "<p>No Topics are added so far.<br>&nbsp;</p>";
		} else {
				while ($row_again = mysql_fetch_array($cat_result)) : 
					include('includes/forum-box.php');
				endwhile; 
		}
		
		echo "</div>";
		
		$url = $set['home'] . "/forum/" . $cat_slug . "/";
		echo pagination($statement,$limit,$page,$url,1); 
	
	else : ?>
	
	
	<div class='box forum_wrap'>
    <?php $result = mysql_query("SELECT * FROM `forum_categories` ORDER BY `position` ASC"); 
			while ($row = mysql_fetch_array($result)) : ?>
			<h2><?php echo $row['name']; ?>  <span class="inside"><?php echo $row['description']; ?></span></h2>		
            <?php $result_again = mysql_query("SELECT * FROM `forum_topics` WHERE `cat_id` = ".$row['id']." ORDER BY `updated` DESC LIMIT 5"); 
			if (mysql_num_rows($result_again) == 0) {
				echo "<p>No topics are added so far.</p>";
			} else {
				while ($row_again = mysql_fetch_array($result_again)) : 
					include('includes/forum-box.php');
				endwhile; 
			}
			?>
            <div class="new_all_wrap"><a href="<?php echo $set['home']; ?>/forum/<?php echo $row['slug']; ?>/" class="button"> View All</a> </div>
	<?php 	endwhile; 	?>
    
    </div><!-- .box -->
    
    <?php endif; ?>
    
   
    </div><!-- .side_content -->

<?php include('includes/forum-sidebar.php');  ?>  
<?php include('../footer.php');  ?>    