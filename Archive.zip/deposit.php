<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = "Deposit";
$deposit_page = 1;
$meta_desc = "Deposit money into your account! " . $set['meta_desc'];
check_login();
$user = get_loggedin_info();
if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");

if (isset($_POST['form_submit'])) {
	
	$amount = mres($_POST['amount']);
	$other_amount = mres($_POST['other_amount']);
	$method = mres($_POST['method']);
	
	if ($amount == 'other' && $other_amount != '') {
		$amount = $other_amount;
	} 
	
	if ($amount < 3) {
		$error[] = "Sorry, minimun deposit ammount is $3.";
		$mehtod = '';
	}
	if ($amount > 1000) {
		$error[] = "Sorry, maximum deposit ammount is $1000.";
		$mehtod = '';
	}
	
	if ($method == 'balance' && empty($error)) {
		
		if ( $user['balance'] < $amount ) {
			$error[] = "Sorry, you don't have enough balance to deposit <strong>$".$amount."</strong> into your account.";
			unset($_POST['form_submit']);
		} else {
			
			$user_id = $user['id'];
			$payment_amount = $amount;
			$via = 'Account Balance';
			
			$query = mysql_query("UPDATE `users` SET `balance` = `balance` - ".$amount.", `balance_used` = `balance_used` + ".$amount." WHERE `id` = " .$user_id);
			include('ipn/ipn_process.php');
			redirect($set['home']. '/account/deposit-complete/');
							
		}
		
		
		
		
	}
	
} else {
	$show_form = 1;
}

include('header.php'); 
?>

<div class="form_box">
<?php display_message(); display_error(); display_notice(); ?>

<?php if (isset($_POST['form_submit'])) { ?>
	
    <?php if ($method == "paypal") { ?>
        <div class="box">
    	<h2>Please Confirm your details!</h2>
        <?php
		$paypal_sandbox = 0;
		if ($paypal_sandbox == 1) {
				$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
			} else {
				$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
			}
		?>
        <!-- HELLO! If you change any of these values, your order will be void and no refunds will be given. -->
        <form action="<?php echo $paypal_url; ?>" method="post"> 
        <input type="hidden" name="cmd" value="_xclick">
        <input type="hidden" name="page_style" value="etallu">
        <input type="hidden" name="business" value="<?php echo $set['paypal_email']; ?>">
        <input type="hidden" name="notify_url" value="<?php echo $set['home']; ?>/ipn/ipn_paypal.php">
        <input type="hidden" name="return" value="<?php echo $set['home']; ?>/payment-complete/"> 
        <input type="hidden" name="cancel" value="<?php echo $set['home']; ?>/deposit/"> 
        <input type="hidden" name="item_name" value="etallu Deposit">  
        <input type="hidden" name="amount" value="<?php echo $amount; ?>">  
        <input type="hidden" name="no_shipping" value="1">  
        <input type="hidden" name="no_note" value="1">  
        <input type="hidden" name="currency_code" value="USD">
        <input type="hidden" name="quantity" value="1">
        <input type="hidden" name="bn" value="PP-BuyNowBF">
        <input type="hidden" name="custom" value="<?php echo $user['id']; ?>">
  		<table class="activate_form">
            <tr>
  				<td class="label">Amount:</td>
                <td class="field" align="center"><strong class="big"> $<?php echo round($amount); ?></strong> (USD)</td>
  			</tr>
            <tr>
  				<td class="label">Payment Method:</td>
                <td class="field" align="center"><img src="<?php echo $set['home']; ?>/img/pmt-icons/paypal.png" alt="PayPal" title="Paypal" /></td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo $set['home']; ?>/deposit/">Go Back</a></td>
                <td><input type="submit" value="Checkout" name="activate_submit" /></td>
            </tr>
  		</table>
         </form>
     </div><!-- .box -->
        
	<?php } elseif ($method == "payza") { ?>

        <div class="box">
    	<h2>Please Confirm your details!</h2>
        <?php
			
			$sandbox = 0;
			
			if ($sandbox == 1) {
				$payza_url = "https://sandbox.Payza.com/sandbox/payprocess.aspx";
			} else {
				$payza_url = "https://secure.payza.com/checkout";
			}
			
		?>
        <!-- HELLO! If you change any of these values, your order will be void and no refunds will be given. -->
        <form method="post" action="<?php echo $payza_url; ?>">
		<input type="hidden" name="ap_merchant" value="<?php echo $set['payza_email']; ?>"/>
		<input type="hidden" name="ap_purchasetype" value="item"/>
		<input type="hidden" name="ap_itemname" value="etallu Deposit"/>
		<input type="hidden" name="ap_amount" value="<?php echo $amount; ?>"/> 
		<input type="hidden" name="ap_currency" value="USD"/>
		<input type="hidden" name="ap_returnurl" value="<?php echo $set['home']; ?>/account/"/>
		<input type="hidden" name="ap_cancelurl" value="<?php echo $set['home']; ?>/deposit/"/>
        <input type="hidden" name="ap_alerturl" value="<?php echo $set['home']; ?>/ipn/ipn_payza.php"/>
		<input type="hidden" name="apc_1" value="<?php echo $user['id']; ?>"/>

  		<table class="activate_form">
            <tr>
  				<td class="label">Amount:</td>
                <td class="field" align="center"><strong class="big"> $<?php echo $amount; ?></strong> (USD)</td>
  			</tr>
            <tr>
  				<td class="label">Payment Method:</td>
                <td class="field" align="center"><img src="<?php echo $set['home']; ?>/img/pmt-icons/payza.png" alt="Payza" title="Payza" /></td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo $set['home']; ?>/deposit/">Go Back</a></td>
                <td><input type="submit" value="Checkout" /></td>
            </tr>
  		</table>
         </form>
     </div><!-- .box -->
        
    <?php } else { ?>
    
    <?php include('includes/form_deposit.php'); ?>
    
    <?php }?>
    
<?php } else { ?>
	
    <?php include('includes/form_deposit.php'); ?>
	    
<?php } ?>


</div><!-- .activate_box -->

<div class="clear"></div>

<?php include('footer.php');  ?>    