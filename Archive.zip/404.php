<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = 'Error 404 not found';
$meta_desc = 'Sorry, the page you are looking for is not here or removed';
if (is_loggedin()){ $user = get_loggedin_info(); }
if (isset($_GET['rid'])) {
	$expire=time()+60*60*24*2;
	setcookie("rid", $_GET['rid'], $expire);
} elseif (isset($_GET['ref'])) {
	$expire=time()+60*60*24*2;
	setcookie("ref", $_GET['ref'], $expire);
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<?php if (isset($nofollow)) { ?>
<meta name="robots" content="noindex, nofollow"> 
<?php } ?>
<title><?php if (isset($page_title)) echo $page_title . " - "; echo $set['name']; ?></title>
<meta name="generator" content="<?php echo $set['name']; ?>">
<meta name="author" content="<?php echo $set['name']; ?>">
<meta name="description" content="<?php if (isset($meta_desc)) echo $meta_desc; else echo $set['meta_desc']; ?>">
<meta name="keywords" content="<?php if (isset($meta_keywords)) echo $meta_keywords; else echo $set['meta_keywords']; ?>">
<link rel="shortcut icon" href="<?php echo $set['home']; ?>/img/favicon.ico">
<link type="text/css" rel="stylesheet" href="<?php echo $set['home']; ?>/css/style_404.css">
</head>
<body>
<div class="wrap">
	<h1>Ooops :(</h1>
	<h2>Error 404 page Not Found</h2>
    <p>Sorry, the page you are looking for is not here or removed. Go to <a href="<?php echo $set['home']; ?>/">Home</a></p>
    <!-- <p>Redirecting in 5 Seconds...</p> -->
    <p></p>
</div>
</body>
</html>
<?php // echo redirect($set['home'],20); ?>