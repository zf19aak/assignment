<?php
require_once('includes/connection.php');
require_once('includes/functions.php');

$page_title = "Sign In"; 
$is_signin_page = 1;
$meta_desc = "Sign in to etallu. " . $set['meta_desc'];

if (isset($_GET['to']) && !isset($_POST['login_submit'])) {
	$error[] = "<strong>Warning!</strong> You need to Sign in first!";
}

if (isset($_SESSION['login_redirect']) && !isset($_POST['login_submit'])) $error[] = "You must be signed in to access this page.";

if (isset($_GET['reset'])) $message = "You have successfully reset your password!";


	$redirect_to = $set['home'] . "/account/";	


if (isset($_SESSION['login_redirect'])) {
	$redirect_to = $_SESSION['login_redirect'];
}


if (isset($_SESSION['failded_login'])) {
	if ($_SESSION['failded_login'] >= 2) {
	require_once('includes/recaptcha_process.php');
	$username = mres($_POST['username']);
	}
}


if (isset($_POST['login_submit']) && empty($error)) :

$username = mres($_POST['username']);
$password = mres($_POST['password']);
$password = sha1($password);

$remember = intval($_POST['remember']);

	if ($username == '')
		$error[] = "Username is required!";	
	if ($password == '')
		$error[] = "Password is required!";	
	
	$result = mysql_query("SELECT `email`,`password` FROM `users` WHERE  `username` = '{$username}' AND `password` = '{$password}'");
	confirm_query($result);
	$check_num = mysql_num_rows($result);
	if ($check_num == 0) {
		$error[] = "<strong>Warning:</strong> Wrong Username or Password!";
		
		if (!isset($_SESSION['failded_login'])){
			$_SESSION['failded_login'] = 0;
		}
		
		if (isset($_SESSION['failded_login'])){
			$_SESSION['failded_login'] = $_SESSION['failded_login'] + 1;
			if ($_SESSION['failded_login'] >= 2) {
				require_once('includes/recaptcha_process.php');
			} 
		}
		
	} 
	
	if (empty($error)){
		$that_user = get_user_info($username,1);
		if ($that_user['suspended'] == 1)
		$error[] = "Sorry, Account suspended!";
	}
	
	
	if (empty($error)){ 
	
		if ($remember == 1) {
			$expire=time()+60*60*24*2;
			setcookie("user_login", $username, $expire,'/');
		} else {
			$_SESSION['user_login'] = $username;
		}
		unset($error);
		unset($_SESSION['failded_login']);
		unset($_SESSION['login_redirect']);
		$update_last = mysql_query("UPDATE `users` SET `last_login` = '".date('Y-m-d H:i:s')."', `last_ip` = '".mres($_SERVER['REMOTE_ADDR'])."' WHERE `username` = '".$username."'");
		confirm_query($update_last);
		redirect($redirect_to);
	}

endif;

include('header.php');
?>
<?php if (isset($_SESSION['failded_login'])) { if ($_SESSION['failded_login'] >= 2) { ?>
<script type="text/javascript">
 var RecaptchaOptions = {
    theme : 'white'
 };
 </script>
<?php } } ?> 
<div class="form_wrap">
<?php display_error(); display_message(); ?>

	<div class="login_box">
	<form id="signin_validate_form" action="<?php echo $set['home']; ?>/sign-in/<?php if(isset($_GET['to'])) echo "/must/". $_GET['to'] . "/"; ?>"  method="post">
        <table class="form_table">
        	<tr>
                <td><h2>Sign In</h2></td>
        	</tr>
        	<tr>
                <td><input type="text" name="username" class="required" value="<?php if (isset($username)) echo $username; ?>" placeholder="Username"></td>
        	</tr>
            <tr>
                <td><input type="password" name="password" class="required" placeholder="Password"></td>
        	</tr>
            <tr>
            	<td><input type="hidden" name="remember" value="0" checked="checked" /><input type="checkbox" name="remember" value="1" id="remember" /> <label for="remember">Remember Me</label></td>
            </tr>
            <?php if (isset($_SESSION['failded_login'])) { if ($_SESSION['failded_login'] >= 2) { ?>
            <tr>
            	<td><?php echo recaptcha_get_html($publickey, $error_captcha); ?></td>
            </tr>
            <?php } } ?>
            <tr>
                <td><input type="submit" class="button" name="login_submit" value="login"> &nbsp; <a href="<?php echo $set['home']; ?>/sign-up/">Dont have an Account?</a></td>
        	</tr>
            <tr>
            	<td class="form_footer"> <a href="<?php echo $set['home']; ?>/recover-password/">Forgot your password?</a></td>
            </tr>
        </table>
    </form>
    </div><!-- .login_box -->

</div><!-- .form_wrap -->

<?php include('footer.php'); ?>