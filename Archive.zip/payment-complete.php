<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');

check_login();

$page_title = 'Deposit Completed';
$meta_desc = 'Deposit Completed';

?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<?php if (isset($nofollow)) { ?>
<meta name="robots" content="noindex, nofollow"> 
<?php } ?>
<title><?php if (isset($page_title)) echo $page_title . " - "; echo $set['name']; ?></title>
<meta name="generator" content="<?php echo $set['name']; ?>">
<meta name="author" content="<?php echo $set['name']; ?>">
<meta name="description" content="<?php if (isset($meta_desc)) echo $meta_desc; else echo $set['meta_desc']; ?>">
<meta name="keywords" content="<?php if (isset($meta_keywords)) echo $meta_keywords; else echo $set['meta_keywords']; ?>">
<link rel="shortcut icon" href="<?php echo $set['home']; ?>/img/favicon.ico">
<link type="text/css" rel="stylesheet" href="<?php echo $set['home']; ?>/css/style_404.css">
</head>
<body>
<div class="wrap">
	<h1>Thank You!</h1>
	<h2 class="ty_heading">Your Payment Has Been Successfully Completed!</h2>
    <p>Click here to go to your account <a href="<?php echo $set['home']; ?>/account/payment-complete/"><strong>My Account</strong></a></p>
</div>
</body>
</html>