<?php 
$page_title = "Notifications";
include('includes/header_account.php');
include('header.php'); 
display_error(); display_notice(); 
?>

<div class="side_content">
  
  
  
 <?php
 	
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;
 	
	$statement = "`notifications` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC";
	
 	$noti_result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$noti_count = mysql_num_rows($noti_result);
 ?>
	
    <?php $url =  $set['home']. '/notifications/'; ?>
    
    <div class="box">
    
    <h2>All Notifications <span class="right"><a href="<?php echo $set['home']; ?>/account/" class="new_button">Back to Account</a></span></h2>
    
    <?php if ($noti_count != 0) { ?>
        
        <table class="data_table">
        	<tr class="head">
        		<td  class="alignleft">Description</td>
                <td width="150">Date</td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($noti_result)) : 
			?>
            <tr class="<?php if($count%2) echo "even"; ?> <?php if ($row['viewed'] == 0) echo "pending"; ?>" >
            	<td class="alignleft">
                <?php if ($row['url'] != '') { ?>
                	<a href="<?php echo $set['home'] . $row['url']; ?>">
                <?php } ?>
					<?php echo $row['description']; ?>
                <?php if ($row['url'] != '') { ?>
                </a>
                <?php } ?>
                </td>
                <td><?php datetime($row['datetime']); ?></td>
            </tr>
            <?php mysql_query("UPDATE `notifications` SET `viewed` = 1 WHERE `id` = ".$row['id']); ?>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
        <?php } else { ?>
        <h2>No History So far</h2>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <?php } ?>
			
    </div><!-- .box -->
	
	<?php echo pagination($statement,$limit,$page,$url,1); ?>

</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-account.php'); ?>
<?php include('footer.php');  ?>    