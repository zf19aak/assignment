<?php 
$page_title = "Manage Sales";
include('includes/header_account.php');
include('header.php'); 
display_error(); display_notice(); 
?>

<div class="side_content">
  
    <div class="box">
        <h2>My Shopping</h2>
        <table class="main_stats"> 
          <tr>
            <td><a href="<?php echo $set['home']; ?>/shopping/type/missing-details/"><strong><?php echo count_shopping($user['id'],'info_submitted',0); ?></strong><br>Missing <br>Details</a></td>
            <td><a href="<?php echo $set['home']; ?>/shopping/type/awaiting-review/"><strong><?php echo count_shopping($user['id'],'status','Delivered',true); ?></strong><br>Awaiting <br>My Review</a></td>
            <td><a href="<?php echo $set['home']; ?>/shopping/type/active/"><strong><?php echo count_shopping($user['id'],'status','Active'); ?></strong><br>Active<br>&nbsp;</a></td>
            <td><a href="<?php echo $set['home']; ?>/shopping/type/delivered/"><strong><?php echo count_shopping($user['id'],'status','Delivered'); ?></strong><br>Delivered<br>&nbsp;</a></td>
            <td><a href="<?php echo $set['home']; ?>/shopping/type/completed/"><strong><?php echo count_shopping($user['id'],'status','Completed'); ?></strong><br>Completed<br>&nbsp;</a></td>
            <td class="last"><a href="<?php echo $set['home']; ?>/shopping/type/cancelled/"><strong><?php echo count_shopping($user['id'],'status','Cancelled'); ?></strong><br>Cancelled<br>&nbsp;</a></td>
          </tr>
        </table>
    </div><!-- .box -->
  
 <?php
 	
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	if ($page == '') $page = 1;
	
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;
 	
	$by_type = ' ';
	
	if (isset($_GET['type'])) {
		$type = mres($_GET['type']);
		$by_type = " AND `status` = '".ucfirst($type)."' ";
		
		if ($type == 'missing-details') $by_type = " AND `info_submitted` = '0' ";
		if ($type == 'awaiting-review') $by_type = " AND `status` = 'COMPLETED' AND `buyer_rated` = '0' ";
		
	} else {
		$type = 'all';
	}
	
	$statement = "`orders` WHERE `buyer_id` = '".$user['id']."' ".$by_type." ORDER BY `id` DESC";
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$total = mysql_num_rows($result);
 ?>
	
     <?php echo pagination($statement,$limit,$page); ?>
    
    <div class="box">

    <h2><span class="left">
    	<a href="<?php echo $set['home']; ?>/shopping/" class="new_button<?php if ($type == 'all') echo ' current'; ?>">All</a>
        <a href="<?php echo $set['home']; ?>/shopping/type/active/" class="new_button<?php if ($type == 'active') echo ' current'; ?>">Active</a>
    	<a href="<?php echo $set['home']; ?>/shopping/type/missing-details/" class="new_button<?php if ($type == 'missing-details') echo ' current'; ?>">Missing Details</a>
        <a href="<?php echo $set['home']; ?>/shopping/type/awaiting-review/" class="new_button<?php if ($type == 'awaiting-review') echo ' current'; ?>">Awaiting My Review</a>
        <a href="<?php echo $set['home']; ?>/shopping/type/delivered/" class="new_button<?php if ($type == 'delivered') echo ' current'; ?>">Delivered</a>
        <a href="<?php echo $set['home']; ?>/shopping/type/completed/" class="new_button<?php if ($type == 'completed') echo ' current'; ?>">Completed</a>
        <a href="<?php echo $set['home']; ?>/shopping/type/cancelled/" class="new_button<?php if ($type == 'cancelled') echo ' current'; ?>">Cancelled</a>
     </span>&nbsp;</h2>
    
    <?php  ?>
    
        <table class="referrals_table">
        	<tr class="head">
        		<td align="left">Service</td>
                <td>Date</td>
                <td>Total</td>
                <td>Status</td>
        	</tr>
            <?php
				if ($total != 0) {
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
				$buyer = get_user_info($row['buyer_id']);
				$service = get_service_info($row['service_id']);
			?>
            <tr class="<?php if($row['status'] != 'Completed') echo "even"; ?> <?php if($row['status'] == 'Cancelled') echo " pending"; ?>" >
                <td align="left">
                	<a href="<?php echo $set['home']; ?>/order/<?php echo $row['number']; ?>/">
					<?php if (isset($service['id'])) {
						echo $service['title'];
					} else {
						echo 'Service Deleted!';
					} ?>
                    </a></td>
                <td><?php echo get_date($row['datetime'],'M j, y'); ?></td>
                <td><strong>$<?php echo $row['price']; ?></strong></td>
                <td><?php echo $row['status']; ?></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
            
            <?php } else { ?>
            <tr>
             <td colspan="4" class="alignleft">
             <?php if (count_orders('all','buyer_id',$user['id']) == 0) { echo "No orders are created so far!";
			  } else { ?>
             	<a href="<?php echo $set['home']; ?>/shopping/type/completed/">View your past orders.</a>
             <?php } ?>
             </td>
            </tr>
            <?php } ?>
            
        </table>
       
    </div><!-- .box -->

	<?php echo pagination($statement,$limit,$page); ?>


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-shopping.php');  ?>  
<?php include('footer.php');  ?>    