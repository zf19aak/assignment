<?php 
$page_title = "Submit a Support Ticket";
include('header.php'); 
//if (is_loggedin()) if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/"); 
if (isset($_POST['form_submit'])) :

$question = mres($_POST['question']);
$user_message = $_POST['user_message'];
$sent_from = $user['username'] . " <" . $user['email'] . '>';

if ( $question == '' || $user_message == '') {
	$error[] = "All Fields are required!";
}

if (empty($error)){
	
	$ToEmail = 'support@lancerdesk.com'; 
	
	$EmailSubject = $question; 

	$headers = "From: ".$sent_from." \r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	 
	$messsage = "User: ". $user['username'] . "<br>"; 
	$messsage .= "Email: ". $user['email'] . "<br>";
	$messsage .= "Name: ". $user['first_name'] . ' '. $user['last_name'] . "<br>";
	$messsage .= "<br><br> ". nl2br($user_message);
	
	$success = mail($ToEmail, $EmailSubject, $messsage, $headers) or die ("error sending email");
	
	if ($success){
		$message = "Your message has been successfully sent! We will contact you within 24 hours.";
	}

}
endif;
?>
  
<div class="activate_box new_topic_box support_box">

   <?php display_error(); display_message(); ?>
    
    <div class="box">

    	<h2>Submit a Support Ticket</h2>
        <?php if (is_loggedin()) { ?>
        
        <form class="<?php echo $set['home']; ?>/support/" method="post">
  		<table class="activate_form">
  			<tr>
  				<td class="label">Subject:</td>
                <td class="field"><input type="text" name="question" value="<?php if (isset($question)) echo stripslashes($question); ?>" /></td>
  			</tr>
            <tr>
  				<td class="label" valign="top">Details:</td>
                <td class="field">
                    <textarea name="user_message" cols="30" rows="10"><?php if (isset($user_message)) echo stripslashes($user_message); ?></textarea>
                </td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo $set['home']; ?>/account/">Cancel</a></td>
                <td><input type="submit" value="Submit Ticket" name="form_submit" /></td>
            </tr>
  		</table>
         </form>
         <?php } else { ?>
         	<div class="centered">
            <p>&nbsp;</p>
            You need to <strong>Sign In</strong> to send us a support ticket <a href="<?php echo $set['home']; ?>/sign-in/must/support/" class="new_button">Sign In</a>            
           	<hr />
            <?php display_notice('You can also reach us any time by email at <a href="mailto:support@lancerdesk.com"><strong>support@lancerdesk.com</strong></a>'); ?>
            <p>&nbsp;</p>
            </div><!-- .centered -->
         <?php } ?>
         
    </div><!-- .box -->
    
</div><!-- .activate_box -->

<?php include('footer.php');  ?>    