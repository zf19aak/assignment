<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$id = intval($_GET['id']);
if ($id == '') redirect($set['home'].'/services/');

$service = get_service_info($id);

if (!isset($service['id'])) redirect($set['home'].'/services/');

if ($service['status'] != 'Active') {
	
	$_SESSION['service_not_active'] = true;
	redirect($set['home'].'/services/');
	
}

$page_title = stripslashes($service['title']);
$buyer = get_user_info($service['user_id']);


if (is_loggedin()) {
    $user = get_loggedin_info();	
	if ($buyer['id'] == $user['id']) $i_am_buyer = true;
}

$single_service_page = true;
include('header.php'); 
?>

<div class="service_content">
  
     <div class="box">
    	<h2 class="service_title"> <?php echo $service['title']; ?></h2>
        <div class="service_meta">Published <?php datetime($service['datetime']); ?>, in <?php the_category($service); ?></div>
      </div><!-- .box -->     
      
      <div class="box service_info">
        <div class="bal_box">
           <strong><?php echo $service['duration']; ?> Day<?php if ($service['duration'] != 1) echo 's'; ?></strong><br> Deliver Time
        </div><!-- .bal_box -->
        <div class="bal_box">
        	<strong><?php echo $service['sales']; ?></strong> <br>Sale<?php if ($service['sales'] != 1) echo 's'; ?>
        </div><!-- .bal_box -->
        <div class="bal_box">
        	<strong><?php echo $service['reviews']; ?> </strong> <br> Reviews
        </div><!-- .bal_box -->
        <div class="bal_box no_border">
        		<strong class="type_ultimate"><?php echo $service['rating']; ?>%</strong>	<br>Rating
        </div><!-- .bal_box -->
         <div class="clear"></div>
    </div><!-- .box -->
      
      <div class="box service_img">
      		<img src="<?php echo img($set['home'].'/uploads/service-imgs/'.$service['image'],640,400); ?>" alt="<?php echo $service['title']; ?>">
    </div><!-- .box -->
   
    <div class="box service_desc">
  	<?php echo nl2br($service['description']); ?>
    </div><!-- .box -->
    
    <?php if ($service['extra_fast_ticked'] || $service['extra_1_ticked'] || $service['extra_2_ticked'] || $service['extra_3_ticked']) { ?>
    
    <div class="box">
    	<h2>Providing Extras</h2>
        <table class="data_table extras_table">
        <?php for ($a=1;$a<=3;$a++) {
			if ($service['extra_'.$a.'_ticked']) {
			 ?>
        	<tr>
        		<td><?php echo $service['extra_'.$a.'_title']; ?></td>
                <td class="alignright">
                <?php if ($service['extra_'.$a.'_duration'] == 0){
						 echo "No Additional Time";
				} else {
					$days = ($service['extra_'.$a.'_duration'] == 1) ? 'Day':'Days';
					echo '+'.$service['extra_'.$a.'_duration'].' '.$days;
				} ?>

                </td>
                <td width="40" class="alignright"><strong>$<?php echo $service['extra_'.$a.'_price']; ?></strong></td>
        	</tr>
        <?php } } ?>
        <?php if ($service['extra_fast_ticked']) { ?>
        <tr>
        		<td><strong>[Extra Fast]</strong> I will deliver this order in just <?php if ($service['extra_fast_duration'] == 0){
						 echo "No Additional Time";
				} else {
					$days = ($service['extra_fast_duration'] == 1) ? 'Day':'Days';
					echo $service['extra_fast_duration'].' '.$days;
				} ?> </td>
                <td class="alignright"></td>
                <td width="40" class="alignright"><strong>$<?php echo $service['extra_fast_price']; ?></strong></td>
        	</tr>
         <?php }?>
        </table>
    </div>
    
    <?php } ?>
    
    <?php if ($service['reviews'] > 0) { ?>
	<div id="service_reviews"><div class="loading"></div></div>
    <?php } ?>
	
	<div class="aligncenter">
    	<?php if (!isset($i_am_buyer)) { ?>
        <a href="<?php echo $set['home']; ?>/buy-service/<?php echo $service['id']; ?>/" class="button buy_now_btn">Buy Now</a>
        <?php } else { ?>
        <a href="<?php echo $set['home']; ?>/edit-service/<?php echo $service['id']; ?>/" class="button buy_now_btn">Edit Service</a>
        <?php } ?>
    </div>
    
</div><!-- .side_content -->

<div class="service_sidebar">
	
    <div class="box service_price">
    	For <strong>$<?php echo $service['price']; ?></strong> only! <br />
        <?php if (!isset($i_am_buyer)) { ?>
        <a href="<?php echo $set['home']; ?>/buy-service/<?php echo $service['id']; ?>/" class="button buy_now_btn">Buy Now</a>
        <?php } else { ?>
        <a href="<?php echo $set['home']; ?>/edit-service/<?php echo $service['id']; ?>/" class="button buy_now_btn">Edit Service</a>
        <?php } ?>
    </div><!-- .box -->
    
	<div class="box">
    
    	<div class="service_seller">
        
        	<?php the_avatar($buyer['id'],60,'thumb'); ?>
        	
            <div class="seller">
            	<a href="<?php echo user_permalink($buyer['id']); ?>"><?php echo $buyer['username']; ?></a> <?php the_flag($buyer['last_ip']); ?> <br />
                Overall Rating: <strong><?php  echo $buyer['rating']; ?>%</strong> 
            </div>
            
            <div class="clear"></div>
            
            <?php if ($buyer['description'] != '') { ?>
            <hr />
            <div class="info"><?php echo nl2br($buyer['description']); ?></div>
			<?php } ?>
            
            <?php if (!isset($i_am_buyer)) { ?>
            <hr />
            <div class="aligncenter">
            	<a href="<?php echo $set['home']; ?>/messages/<?php echo $buyer['username']; ?>/" class="new_button">Contact Seller</a>
            </div>
            <?php } ?>
            
            <div class="clear"></div>
            
        </div><!-- .service_seller -->
    
	</div><!-- .box -->
    
    <div class="box service_gurantee">
    	<strong>100% Money Back Guarantee</strong>
        <small>Get your job done or your money back.</small>
    </div><!-- .service_gurantee -->

    <div class="service_tags">
    	<h3>Related Services</h3>
     <?php $tags = explode(',',$service['tags']);
	 foreach($tags as $tag) {
		echo '<a href="'.$set['home'].'/services/'.urlencode(trim($tag)).'/" class="button">'.trim($tag).'</a>';
	 } ?>

        <div class="clear"></div>
        
    </div><!-- .box -->

    

</div><!-- .sidebar -->

<div class="clear"></div>

<?php include('footer.php');  ?>    