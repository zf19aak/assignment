<?php
include_once('includes/connection.php');
if (isset($_SESSION['user_login']))  unset($_SESSION['user_login']);

if (isset($_COOKIE['user_login'])) {
  $expire=time()-60*60*24*2;
  setcookie("user_login", $_COOKIE['user_login'], $expire,'/');
  unset($_COOKIE['user_login']);
}

echo "<meta http-equiv=\"REFRESH\" content=\"0; url=".$set['home']."/\">";
?>