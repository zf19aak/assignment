<?php
if (isset($user_id,$payment_amount,$via)) :
if ( $user_id != '' && $payment_amount != '' && $via != '') {
	$this_user = get_user_info($user_id);
	$new_balance = $this_user['purchase_balance'] + $payment_amount;
	$new_deposit = $this_user['total_deposit'] + $payment_amount;
	mysql_query("UPDATE `users` SET `purchase_balance` = '".mres($new_balance)."', `total_deposit` = '".mres($new_deposit)."' WHERE `id` = " . $user_id);
	
	$noti_url = '/payments/';
	add_noti('You deposited <strong>($'.round($payment_amount).')</strong> into your account via <strong>'.$via.'</strong>.',$user_id,$noti_url,'Deposit Added!');
	
	$datetime = date('Y-m-d H:i:s');
	$payment_desc = "Deposit via " . $via;
	mysql_query("INSERT INTO `payments` (
		  `user_id`,
		  `amount`,
		  `description`,
		  `type`,
		  `datetime`
	  ) VALUES (
	  	  '".$this_user['id']."',
		  '".$payment_amount."',
		  '".$payment_desc."',
		  'Deposit',
		  '".$datetime."'
	  )");
	
	// Adding Referral Bonus
	if ($this_user['first_deposit'] == 0) {
		if ($this_user['referrer'] != '') {
			
			$referrer = get_user_info($this_user['referrer'],true);
			
			if (isset($referrer['id'])) {
			mysql_query("UPDATE `users` SET `balance` = `balance` + 3 WHERE `id` = " . $referrer['id']);
			mysql_query("UPDATE `users` SET `first_deposit` = 1 WHERE `id` = " . $this_user['id']);
			
			$noti_url = '/referrals/';
			add_noti('Congrats! You received <strong>$3</strong> Referral Bonus because your referral <strong>('.$this_user['username'].')</strong> just made a first deposit.',$referrer['id'],$noti_url,'Referral / Deposit Bonus!');
			}
			
		}
	} 
	
}
endif;
?>