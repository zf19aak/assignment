<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

/*
$new_payza_test = $set['payza_test'] . " Payza was here at " . date("Y-m-d g:i:s A") . '\n';
mysql_query("UPDATE `options` SET `option_value` = '".$new_payza_test."' WHERE `option_name` = 'payza_test'");
*/

/**
 * 
 * Sample IPN V2 Handler for Item Payments
 * 
 * The purpose of this code is to help you to understand how to process the Instant Payment Notification 
 * variables for a payment received through Payza's buttons and integrate it in your PHP site. The following
 * code will ONLY handle ITEM payments. For handling IPNs for SUBSCRIPTIONS, please refer to the appropriate
 * sample code file.
 *	
 * Put this code into the page which you have specified as Alert URL.
 * The conditional blocks provide you the logical placeholders to process the IPN variables. It is your responsibility
 * to write appropriate code as per your requirements.
 *	
 * If you have any questions about this script or any suggestions, please visit us at: dev.payza.com
 * 
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
 * OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO THE IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE.
 * 
 * @author Payza
 * @copyright 2011
 */
 
 	//The value is the url address of IPN V2 handler and the identifier of the token string 
	
	//define("IPN_V2_HANDLER", "https://sandbox.Payza.com/sandbox/IPN2.ashx"); 	
	define("IPN_V2_HANDLER", "https://secure.payza.com/ipn2.ashx");
	
	define("TOKEN_IDENTIFIER", "token=");
	
	// get the token from Payza
	$token = urlencode($_POST['token']);

	//preappend the identifier string "token=" 
	$token = TOKEN_IDENTIFIER.$token;
	
	/**
	 * 
	 * Sends the URL encoded TOKEN string to the Payza's IPN handler
	 * using cURL and retrieves the response.
	 * 
	 * variable $response holds the response string from the Payza's IPN V2.
	 */
	
	$response = '';
	
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, IPN_V2_HANDLER);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $token);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	$response = curl_exec($ch);

	curl_close($ch);
	
	if(strlen($response) > 0) {
		if(urldecode($response) == "INVALID TOKEN") {
			//the token is not valid
			
			$new_payza_test = $set['payza_test'] . " INVALID TOKEN " . date("Y-m-d g:i:s A") . ' token =  ' . $_POST['token'] . '\n';
			mysql_query("UPDATE `options` SET `option_value` = '".$new_payza_test."' WHERE `option_name` = 'payza_test'");
			
		} else {
			
			//urldecode the received response from Payza's IPN V2
			$response = urldecode($response);
			
			//split the response string by the delimeter "&"
			$aps = explode("&", $response);
				
			//create a file to save the response information from Payza's IPN V2	
			$myFile = "IPNRes.txt";
			$fh = fopen($myFile,'a') or die("can't open the file");
			
			//define an array to put the IPN information
			$info = array();
			
			foreach ($aps as $ap) {
				//put the IPN information into an associative array $info
				$ele = explode("=", $ap);
				$info[$ele[0]] = $ele[1];
				
				//write the information to the file IPNRes.txt
				fwrite($fh, "$ele[0] \t");
				fwrite($fh, "=\t");
				fwrite($fh, "$ele[1]\r\n");
			}
			fclose($fh);
			
			//setting information about the transaction from the IPN information array
			$receivedMerchantEmailAddress = $info['ap_merchant'];
			$transactionStatus = $info['ap_status'];
			$testModeStatus = $info['ap_test'];
			$purchaseType = $info['ap_purchasetype'];
			$totalAmountReceived = $info['ap_totalamount'];
			$feeAmount = $info['ap_feeamount'];
			$netAmount = $info['ap_netamount'];
			$transactionReferenceNumber = $info['ap_referencenumber'];
			
			//setting the customer's information from the IPN information array
			$customerEmailAddress = $info['ap_custemailaddress'];
			
			//setting information about the purchased item from the IPN information array
			$myItemAmount = $info['ap_amount'];
			
			$currency = $info['ap_currency'];
			
			//setting your customs fields received from the IPN information array
			$user_id = $info['apc_1'];
			$payment_amount = $totalAmountReceived;
			
			
			/*
			
			IF security codes match THEN
			IF ap_referencenumber has a value AND ap_test equal 0 THEN
			Do some further processing with the contents of the POST array
			ELSE
			Ignore the post since it is not from Payza 
			
			*/
			
			$txn_id_check = mysql_query("SELECT `txn_id` FROM `payment_logs` WHERE `txn_id` = '". mres($transactionReferenceNumber) ."'");
			
			if (mysql_num_rows($txn_id_check) != 1 && $receivedMerchantEmailAddress == $set['payza_email'] && $currency == 'USD' && $transactionStatus == 'Success' && $testModeStatus == 0 && $transactionReferenceNumber != ''):
			
				$log_query = mysql_query("INSERT INTO `payment_logs` (`txn_id`,`user_id`,`user_email`,`amount`,`fee`,`method`,`datetime`) VALUES (
					'". mres($transactionReferenceNumber)."', 
					'". intval($user_id) ."',
					'". mres($customerEmailAddress) ."', 
					'". mres($payment_amount) ."',
					'". mres($feeAmount) ."',  
					'Payza',
					'". date("Y-m-d H:i:s") ."'
					)");
				
				$via = "Payza";
				
				include('ipn_process.php');
			
			endif;
			
		}
	}
	else
	{
		//something is wrong, no response is received from Payza
	}
	
?>