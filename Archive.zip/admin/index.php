<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link href="css/admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>
<table style="width:100%; height:100%;">
	<tr>
		<td>
        <div class="login_box">	
<?php if (isset($_POST['login_submit'])) { ?>
<div class="display_error">Login Failed!</div>
<?php } ?>        
            <form action="index.php" method="post">
            <table class="form_table admin_login_table">
            	<tr>
                	<td></td>
                    <td><h1>Login</h1></td>
                </tr>
            	<tr>
            		<td>Email:</td>
                    <td ><input type="text" name="username" required></td>
            	</tr>
                <tr>
                	<td class="field_td">Password:</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                	<td></td>
                    <td><input type="submit" name="login_submit" value="Login"></td>
                </tr>
                <tr>
                	<td></td>
                	<td style="font-size:12px;"><br> Your IP address will be saved!. </td>
                </tr>
             </table>
             </form>
        </div><!-- .login_box -->
        </td>
	</tr>
</table>
</body>
</html>