<?php 
include('includes/header_account.php');

if (isset($_GET['delete'])) {
	
	$delete_id = intval($_GET['delete']);
	$this_service = get_service_info($delete_id);
	
	if ($this_service['user_id'] != $user['id']) $error[] = "Permission denied!";
	
	if (empty($error)){
		if (delete_service($this_service['id'])) $message = "Service is deleted now!";
	}
			
}

if (isset($_GET['pause'])){
	$pause_id = intval($_GET['pause']);
	$service = get_service_info($pause_id);
	if ($service['user_id'] != $user['id']) $error[] = "That's not your service.";
	if (empty($error)){
		$pause= mysql_query("UPDATE `services` SET `status` = 'Paused' WHERE `id` = ". $service['id']);
		if ($pause) $message = "Your service is Paused now.";
	}
}
if (isset($_GET['resume'])){
	$resume_id = intval($_GET['resume']);
	$service = get_service_info($resume_id);
	if ($service['user_id'] != $user['id']) $error[] = "That's not your service.";
	if (empty($error)){
		$resume = mysql_query("UPDATE `services` SET `status` = 'Active' WHERE `id` = ". $service['id']);
		if ($resume) $message = "Your service is resumed now.";
	}
}


if (isset($_SESSION['service_pending'])) {
	$notice = "Thank you! your service is currently pending for approval. Will be live soon!";
	unset($_SESSION['service_pending']);
}

if (isset($_GET['type'])) {
	$type =	 mres($_GET['type']);
} 

$page_title = "My Services";
include('header.php'); 
?>

<div class="side_content">
<?php display_error(); display_message(); display_notice(); ?>  
       <div class="box">
 
        <h2>My Services</h2>
        
        <table class="main_stats"> 
          <tr>
            <td><a href="<?php echo $set['home']; ?>/my-services/type/active/"><strong><?php echo count_services($user['id'],'Active'); ?></strong><br>Active<br>&nbsp;</a></td>
            <td><a href="<?php echo $set['home']; ?>/my-services/type/paused/"><strong><?php echo count_services($user['id'],'Paused'); ?></strong><br>Paused<br>&nbsp;</a></td>
            <td><a href="<?php echo $set['home']; ?>/my-services/type/requires-modification/"><strong><?php echo count_services($user['id'],'Requires Modification'); ?></strong><br>Requires<br>Modification</a></td>
            <td><a href="<?php echo $set['home']; ?>/my-services/type/pending/"><strong><?php echo count_services($user['id'],'Pending'); ?></strong><br>Pending<br>Approval</a></td>
            <td class="last"><a href="<?php echo $set['home']; ?>/my-services/type/denied/"><strong><?php echo count_services($user['id'],'Denied'); ?></strong><br>Denied<br>&nbsp;</a></td>
          </tr>
        </table>
        
    </div><!-- .box -->
  
  
 <?php
 	
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;
 	
	
	if (isset($type)) {
		
		if ($type == 'requires-modification') $type = 'Requires Modification';
		
		$statement = "`services` WHERE `user_id` = '".$user['id']."' AND `Status` = '".ucwords($type)."' ORDER BY `id` DESC";
	} else {
		$statement = "`services` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC";
	}
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$total = mysql_num_rows($result);
 ?>
	
     <?php echo pagination($statement,$limit,$page); ?>
    
    <div class="box">
    
    <h2><?php if (isset($type)) echo ucwords($type); ?> Services <span class="right"><a href="<?php echo $set['home']; ?>/new/" class="new_button">Add New Service</a></span></h2>
    
    <?php if ($total != 0) { ?>
    
        <table class="data_table">
        	<tr class="head">
        		<td width="70" align="left"></td>
                <td align="left">Service</td>
        	</tr>
            <?php
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
			?>
            <tr class="even<?php if ($row['status'] == 'Requires Modification') echo " pending"; ?>">
            	<td align="left" valign="top">
                <?php if ($row['status'] == 'Active'){ ?>
                	<a href="<?php echo service_permalink($row['id']); ?>">
                <?php } ?>
                		<img src="<?php echo img($set['home'] . '/uploads/service-imgs/' . $row['image'],80,50); ?>" class="thumb" alt="" />
                <?php if ($row['status'] == 'Active'){ ?>
                    </a>
                <?php } ?>
                </td>
                <td align="left">
                <?php if ($row['status'] == 'Active'){ ?>
                <a href="<?php echo service_permalink($row['id']); ?>"><?php echo $row['title']; ?></a>
                <?php } else { echo $row['title']; } ?>
					
					
                <div class="my_service_meta">
                 <span class="service_status <?php echo strtolower($row['status']); ?>"><?php echo $row['status']; ?></span>
                  <?php echo $row['sales']; ?> Sales with <?php echo $row['rating']; ?>% Ratings
                </div>
                
                <div class="service_action_box">
                	<?php if ($row['status'] == 'Active') { ?>
                	<a href="<?php echo $set['home']; ?>/my-services/?pause=<?php echo $row['id']; ?>" class="new_button">Pause Service</a> 
                <?php } elseif($row['status'] == 'Paused') { ?>
                	<a href="<?php echo $set['home']; ?>/my-services/?resume=<?php echo $row['id']; ?>" class="new_button">Resume Service</a> 
                <?php } ?>
                	<a href="<?php echo $set['home']; ?>/edit-service/<?php echo $row['id']; ?>/" class="new_button">Edit</a> 
                    <a href="<?php echo $set['home']; ?>/my-services/?delete=<?php echo $row['id']; ?>" class="new_button del_link" onclick="return confirm('Are you sure you want to delete this service?');">Delete Service</a>
                </div>
                
                </td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
        </table>
        <?php } else { ?>
        <p>No <?php if (isset($type)) echo $type; ?> Services found.</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <?php } ?>
			
    </div><!-- .box -->

	<?php echo pagination($statement,$limit,$page); ?>


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-sales.php');  ?>  
<?php include('footer.php');  ?>    