<?php
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = "Privacy Policy";
$meta_desc = "This privacy policy regards how we store and deal with your user information.";
include('header.php');
?>
  
  <h2>Privacy Policy</h2>
  
  <p>This privacy policy regards how we store and deal with your user information.</p>
  
  <p>When signing up at <?php echo $set['name']; ?>, you will agree to have read, understood, and accepted the following terms and conditions of this Privacy Policy. If you do not agree to any of these terms, you must not signup.</p>
  
	        <table class="terms_table">
          <tr>
            <td valign="top" colspan="2"><h2>COOKIES</h2></td>
          </tr>
          <tr>
            <td valign="top" class="nr">1.1.</td>
            <td>Your browser must accept cookies.</td>
          </tr>
          <tr>
            <td valign="top" class="nr">1.2.</td>
            <td>Cookies will only be used to store your preferences.</td>
          </tr>
          <tr>
            <td valign="top" colspan="2"><h2>USER EMAILS</h2></td>
          </tr>
          <tr>
            <td valign="top" class="nr">2.1.</td>
            <td>Your email addresses will not be shown, given or sold.</td>
          </tr>
          <tr>
            <td valign="top" class="nr">2.2.</td>
            <td>Your personal email address will only be used for <?php echo $set['name']; ?> to communicate with you and to send you a new password in case you request it.</td>
          </tr>
          <tr>
            <td valign="top" class="nr">2.3.</td>
            <td>Your payment processor email addresses will only be used for us to send you your requested payments and to confirm what you purchase.</td>
          </tr>
          <tr>
            <td valign="top" colspan="2"><h2>USER PASSWORD</h2></td>
          </tr>
          <tr>
            <td valign="top" class="nr">3.1.</td>
            <td>Your user password will be stored in an irreversible format.</td>
          </tr>
          <tr>
            <td valign="top" class="nr">3.2.</td>
            <td>Your user password will never be shown, sold or given.</td>
          </tr>
          <tr>
            <td valign="top" colspan="2"><h2>USERNAME</h2></td>
          </tr>
          <tr>
            <td valign="top" class="nr">4.1.</td>
            <td>Your username will be kept hidden by default from other users if you sign up without a referrer.</td>
          </tr>
          <tr>
            <td valign="top" class="nr">4.2.</td>
            <td>Your username will be shown by default to other users if you sign up under a referrer.</td>
          </tr>
          <tr>
            <td valign="top" class="nr">4.3.</td>
            <td>Regardless of the default setting, you will still be able to override the display status at any time.</td>
          </tr>
          <tr>
            <td valign="top" class="nr">4.4.</td>
            <td>Regardless of the setting you have, your username will always be displayed in the Forum.</td>
          </tr>
        </table>   
    
<?php include('footer.php'); ?>