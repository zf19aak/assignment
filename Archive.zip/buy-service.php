<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
check_login();

$id = intval($_GET['id']);
if ($id == '') redirect($set['home']);

$service = get_service_info($id);

if (!isset($service['id'])) redirect($set['home'].'/services/');

$user = get_loggedin_info();

if ($service['status']!='Active') {
	$_SESSION['service_not_active'] = true;
	redirect($set['home'].'/services/');
}

if ($service['user_id']== $user['id']) $error[] = "You cannot buy you own service.";

$page_title = "Buy Service: " . $service['title'];

$service_user = get_user_info($service['user_id']);

if ($user['purchase_balance'] < $service['price'] && !isset($_POST['form_submited'])) {
	 $error[] = "Sorry, You don't have enough purchase balance to buy this service. <a href='".$set['home']."/deposit/'><strong>Deposit Money</strong></a>";
}

if (isset($_POST['form_submited'])) {
	
	
	$extra_fast_bought = (isset($_POST['extra_fast_ticked'])) ? intval($_POST['extra_fast_ticked']) : '0';
	$extra_1_bought = (isset($_POST['extra_1_ticked'])) ? intval($_POST['extra_1_ticked']) : '0';
	$extra_2_bought = (isset($_POST['extra_2_ticked'])) ? intval($_POST['extra_2_ticked']) : '0';
	$extra_3_bought = (isset($_POST['extra_3_ticked'])) ? intval($_POST['extra_3_ticked']) : '0';
	
	$number = gen_order_number();
	
	$order_price = $service['price'];
	$order_duration = $service['duration'];
	
	if ($extra_1_bought == 1) {
		 $order_price = $order_price + $service['extra_1_price'];
		 $order_duration = $order_duration + $service['extra_1_duration'];
	}
	if ($extra_2_bought == 1) {
		 $order_price = $order_price + $service['extra_2_price'];
		 $order_duration = $order_duration + $service['extra_2_duration'];
	}
	
	if ($extra_3_bought == 1) {
		 $order_price = $order_price + $service['extra_3_price'];
		 $order_duration = $order_duration + $service['extra_3_duration'];
	}
	
	if ($extra_fast_bought == 1) {
		 $order_price = $order_price + $service['extra_3_price'];
		 $order_duration = $service['extra_fast_duration'];
	}

	if ($user['purchase_balance'] < $order_price) {
	 	$error[] = "Sorry, You don't have enough purchase balance to buy this service. <a href='".$set['home']."/deposit/'><strong>Deposit Money</strong></a>";
	}
  	
	if (empty($error)) {
		$query = mysql_query("INSERT INTO `orders` (
		  	`number`,
			`service_id`,
			`seller_id`,
			`buyer_id`,
			`price`,
			`duration`,
			`status`,
			`extra_fast_bought`,
			`extra_1_bought`,
			`extra_2_bought`,
			`extra_3_bought`,
			`datetime`
		) VALUES (
		'".$number."',
		'".$service['id']."',
		'".$service['user_id']."',
		'".$user['id']."',
		'".$order_price."',
		'".$order_duration."',
		'pending',
		'".$extra_fast_bought."',
		'".$extra_1_bought."',
		'".$extra_2_bought."',
		'".$extra_3_bought."',
		'".date('Y-m-d H:i:s')."'
		)");	
		
		$update = mysql_query("UPDATE `users` SET `purchase_balance` = `purchase_balance` - ".$order_price." WHERE `id` = " . $user['id']);
		
		$payment_desc = "Service Purchased from Purcahse Balance";
		mysql_query("INSERT INTO `payments` (
			  `user_id`,
			  `order_number`,
			  `amount`,
			  `description`,
			  `type`,
			  `datetime`
		  ) VALUES (
		  	  '".$user['id']."',
			  '".$number."',
			  '".$service['price']."',
			  '".$payment_desc."',
			  '0',
			  '".date('Y-m-d H:i:s')."'
		  )");
		
		
		if ($query && $update) {
			$success = true;
			
			$noti_desc = $user['username'] . ' just ordered your service. Hold tight while ' .$user['username'] . ' submits the additional information you requested.';
			$noti_url = '/order/'.$number.'/';
			$to_id = $service['user_id'];
			add_noti($noti_desc,$to_id,$noti_url);
			
		}  else {
			$error[] = "Error creating order. " . mysql_error();	
		}
	
	}
	
} 

include('header.php'); 
?>

<div class="form_box">
<?php display_error(); display_message(); ?>
<?php if (!isset($success)) { ?>

	<div class="box">

    	<h2>Please confirm you order</h2>
        <form class="<?php echo $set['home']; ?>/buy-service/<?php echo $id; ?>/" method="post">
  		<table class="activate_form">
  			<tr>
  				<td class="label">Service:</td>
                <td class="field"><a href="<?php echo service_permalink($service['id']); ?>"><?php echo $service['title']; ?></a></td>
  			</tr>
            <?php for ($a=1;$a<=3;$a++) {
			if ($service['extra_'.$a.'_ticked']) {
 			?>
            <tr>
  				<td class="label">Extra: 
                	<input type="hidden" name="extra_<?php echo $a; ?>_ticked" checked="checked" value="0" />
                	<input type="checkbox" class="check_checked" name="extra_<?php echo $a; ?>_ticked" value="1" data-price="<?php echo $service['extra_'.$a.'_price']; ?>" /></td>
                <td class="field"><?php echo $service['extra_'.$a.'_title']; ?> 
                in <strong><?php if ($service['extra_'.$a.'_duration'] == 0){
						 echo "No Additional Time";
				} else {
					$days = ($service['extra_'.$a.'_duration'] == 1) ? 'Day':'Days';
					echo '+'.$service['extra_'.$a.'_duration'].' '.$days;
				} ?></strong>
                for <strong>$<?php echo $service['extra_'.$a.'_price']; ?></strong> </td>
  			</tr>
  			<?php } } ?>
            <?php if ($service['extra_fast_ticked']) { ?>
            <tr>
            	<td class="label">Extra: <input type="hidden" name="extra_fast_ticked" checked="checked" value="0" />
                	<input type="checkbox" class="check_checked" name="extra_fast_ticked" value="1" data-price="<?php echo $service['extra_fast_price']; ?>" /></td>
                 <td class="field">
            	<strong>[Extra Fast]</strong> I will deliver this order in just 
				<strong><?php if ($service['extra_fast_duration'] == 0){
						 echo "No Additional Time";
				} else {
					$days = ($service['extra_fast_duration'] == 1) ? 'Day':'Days';
					echo $service['extra_fast_duration'].' '.$days;
				} ?></strong> for <strong>$<?php echo $service['extra_fast_price']; ?></strong>
                </td>
            </tr>
            <?php } ?>
			<tr>
  				<td class="label"><strong>Total:</strong></td>
                <td class="field"><strong>$<span class="total_price"><?php echo $service['price']; ?></span></strong>
                <input type="hidden" value="<?php echo $service['price']; ?>" class="service_price" />
                </td>
  			</tr>            
            <tr>
  				<td class="label">Purcahsing balance:</td>
                <td class="field">
                <strong>$<?php echo $user['purchase_balance']; ?></strong> &nbsp; <a href="<?php echo $set['home']; ?>/deposit/">+ Make a Deposit</a>
                </td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo service_permalink($service['id']); ?>">Cancel</a></td>
                <td><input type="submit" value="Buy Now" name="form_submited" /></td>
            </tr>
  		</table>
        
         </form>
         
    </div><!-- .box -->

<?php } else { ?>
<?php display_message('<strong>Thank you!</strong> Your order has been successfully placed!'); ?>
<div class="box centered">

    	<h2>Order #<?php echo $number; ?></h2>
        <p>Kindly view your order and provide the required information.</p>
        <p><a href="<?php echo $set['home']; ?>/order/<?php echo $number; ?>/" class="button">View Your Order</a></p>

    </div><!-- .box -->

<?php } ?>

</div><!-- .form_box -->

<div class="clear"></div>

<?php include('footer.php');  ?>    