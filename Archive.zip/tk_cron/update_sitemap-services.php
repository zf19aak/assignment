<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');
$home = $set['home'];
$file = '<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$query = "SELECT * FROM `services` WHERE `status` = 'Active'";
$result = mysql_query($query) or die ("Could not execute query");
while($row = mysql_fetch_array($result)) {
	$permalink = service_permalink($row['id']);
$file .= '
<url>
    <loc>'.$permalink.'</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
    <image:image>
      <image:loc>'. $home . '/uploads/service-imgs/'.$row['image'].'</image:loc>
	  <image:title>'.htmlentities($row['title']).'</image:title>
      <image:caption>'.htmlentities($row['title']).'</image:caption>
    </image:image>
  </url>';
} // end while

$file .= '
</urlset>';
$xml_file = '../sitemap-services.xml';
file_put_contents($xml_file,$file);
?>