<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

$home = $set['home'];
$file = '<?xml version="1.0" encoding="UTF-8"?>
<urlset
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$query = "SELECT * FROM `categories` WHERE `parent` = 0 ORDER BY `position` ASC";
$result = mysql_query($query) or die ("Could not execute query");
while($row = mysql_fetch_array($result)) {
	
$file .= '
  <url>
    <loc>'.category_url($row['id']).'</loc>
    <changefreq>weekly</changefreq>
    <priority>0.6</priority>
  </url>';
  
  $child_query = mysql_query("SELECT * FROM `categories` WHERE `parent` = ".$row['id']." ORDER BY `position` ASC");
  while ($child_row = mysql_fetch_array($child_query)){

$file .= '
  <url>
    <loc>'.category_url($child_row['id']).'</loc>
    <changefreq>weekly</changefreq>
    <priority>0.6</priority>
  </url>';

  }
  
} // end while

$file .= '
</urlset>';

$xml_file = '../sitemap-categories.xml';
file_put_contents($xml_file,$file);
?>