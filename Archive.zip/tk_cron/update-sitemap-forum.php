<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

function get_topic_info($id){
	$query = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = " . intval($id));
	if (mysql_num_rows($query) == 1) {
		return mysql_fetch_array($query);
	} else {
		return false;	
	}
}

function topic_permalink($id) {
	global $set;
	$topic = get_topic_info($id);
	$category = get_forum_category_info($topic['cat_id']);
	return $set['home'].'/forum/'.$category['slug'].'/'.make_slug($topic['title']) . '-'.$topic['id'].'/';
}

$home = $set['home'];
$file = '<?xml version="1.0" encoding="UTF-8"?>
<urlset
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$query = "SELECT * FROM `forum_categories` ORDER BY `position` ASC";
$result = mysql_query($query) or die ("Could not execute query");
while($row = mysql_fetch_array($result)) {
	
$file .= '
  <url>
    <loc>'.$home.'/forum/'.$row['slug'].'</loc>
    <changefreq>weekly</changefreq>
    <priority>0.2</priority>
  </url>';
  
  $child_query = mysql_query("SELECT * FROM `forum_topics` WHERE `cat_id` = ".$row['id']." ORDER BY `updated` DESC");
  while ($child_row = mysql_fetch_array($child_query)){

$file .= '
  <url>
    <loc>'.topic_permalink($child_row['id']).'</loc>
    <changefreq>weekly</changefreq>
    <priority>0.2</priority>
  </url>';
  }
  
} // end while

$file .= '
</urlset>';

$xml_file = '../sitemap-forum.xml';
file_put_contents($xml_file,$file);
?>