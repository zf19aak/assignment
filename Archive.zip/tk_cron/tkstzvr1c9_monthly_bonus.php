<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

$result = mysql_query("SELECT * FROM `users` WHERE `active` = 1 AND `expired` = 0 AND `suspended` = 0 AND `username` != 'admin'");

while ($row = mysql_fetch_array($result)) :
	
	$count_days = check_days($row['active_date'], $row['active_days']);
	
	if ($count_days > 0) {
		
		$today = explode('-',date('d-m-Y'));  
		$active_date = explode( '-', $row['active_date']);  
		
		$active_day = $active_date[0];
		$active_month = $active_date[1];
		
		$this_today = $today[0];
		$this_month = $today[1];
		
		if ($active_day == $this_today && $active_month != $this_month && $row['monthly_paid_month'] != $this_month ) {
			
			// yes this is the day for monthly comission.
			$get_result = mysql_query("SELECT * FROM `users` WHERE `referrer` = '".$row['username']."' AND `active` = 1 AND `expired` = 0 AND `suspended` = 0" );
			$get_count = mysql_num_rows($get_result);
			
			if ($get_count > 0) {
				$monthly_bonus = $get_count * 1;
				$new_balance = $row['balance'] + $monthly_bonus;
				mysql_query("UPDATE `users` SET `balance` = '".$new_balance."', `monthly_paid_month` = '".$this_month."' WHERE `id` =" . $row['id']);
				add_noti('<strong>[Monthly Bonus]</strong> You have received <strong>($'.$monthly_bonus.')</strong> for <strong>'.$get_count.'</strong> active '.$set['anu_name'].'s.',$row['id'],'Monthly Bonus!');
			}
			
		}
	
	}
	
endwhile;

$set['cron_test'];
$val = "Monthly Bonus Cron Job executed! on " . date('Y-m-d g:i:s A') . '\n\n';
$new_val = $set['cron_test'] . $val;
mysql_query("UPDATE `options` SET `option_value` = '".$new_val."' WHERE  `option_name` = 'cron_test' ");

?>