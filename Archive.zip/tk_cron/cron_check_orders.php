<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

// Check if an Active Order is late
$result = mysql_query("SELECT * FROM `orders` WHERE `status` = 'Active'");
while ($row = mysql_fetch_array($result)) :
	if (check_due($row['due_datetime'])) {
		mysql_query("UPDATE `orders` SET `status` = 'Late' WHERE `id` = " . $row['id']);
	} 
endwhile;

// Check if delivered orders has passed three days
$result = mysql_query("SELECT * FROM `orders` WHERE `status` = 'Delivered'");
while ($row = mysql_fetch_array($result)) :
	$due_datetime = get_due_completion_datetime($row['delivered_datetime']);
	if (check_due($due_datetime)) {
		complete_order($row['id'],true);
	} 
endwhile;
?>