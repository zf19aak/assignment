<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

function array_flatten($array) {
   $return = array();
   foreach ($array as $key => $value) {
       if (is_array($value)){ $return = array_merge($return, array_flatten($value));}
       else {$return[$key] = $value;}
   }
   return $return;
}

$home = $set['home'];
$file = '<?xml version="1.0" encoding="UTF-8"?>
<urlset
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

//$tags = array();

$query = "SELECT * FROM `services` WHERE `status` = 'Active'";
$result = mysql_query($query) or die ("Could not execute query");
while($row = mysql_fetch_array($result)) {
  $tags[] = explode(',',trim($row['tags']));
} // end while

$result = array_flatten($tags);
$all_tags = array_unique($result);

foreach ($all_tags as $tag) {
$file .= '
  <url>
    <loc>'.$home.'/services/'.urlencode(trim(strtolower($tag))).'/</loc>
    <changefreq>weekly</changefreq>
    <priority>0.2</priority>
  </url>';
}
$file .= '
</urlset>';

$xml_file = '../sitemap-tags.xml';
file_put_contents($xml_file,$file);
?>