<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

$result = mysql_query("SELECT * FROM `users` WHERE `email_verified` = 0 AND `username` != 'admin'");

while ($row = mysql_fetch_array($result)) :
	
  send_email_verification($row['id']);
	
endwhile;

?>