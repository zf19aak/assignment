<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');
$home = $set['home'];
$file = '<?xml version="1.0" encoding="UTF-8"?>
<urlset 
      xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<url>
  <loc>'.$home.'/</loc>
  <priority>1.00</priority>
</url>
';

$query = "SELECT * FROM `services` WHERE `status` = 'Active'";
$result = mysql_query($query) or die ("Could not execute query");
while($row = mysql_fetch_array($result)) {
	$category_link = service_permalink($row['id']);
$file .= '
<url>
  <loc>'.$category_link.'</loc>
  <priority>0.90</priority>
</url>';
} // end while

$file .= '
<url>
	<loc>'.$home.'/forum/</loc>
	<priority>0.80</priority>
</url>
<url>
	<loc>'.$home.'/how-it-works/</loc>
	<priority>0.80</priority>
</url>
<url>
	<loc>'.$home.'/sign-in/</loc>
	<priority>0.64</priority>
</url>
<url>
	<loc>'.$home.'/sign-up/</loc>
	<priority>0.64</priority>
</url>
<url>
	<loc>'.$home.'/support/</loc>
	<priority>0.64</priority>
</url>
<url>
	<loc>'.$home.'/terms-of-services/</loc>
	<priority>0.64</priority>
</url>
<url>
	<loc>'.$home.'/privacy-policy/</loc>
	<priority>0.64</priority>
</url>
</urlset>';
$xml_file = '../sitemap.xml';
file_put_contents($xml_file,$file);
?>