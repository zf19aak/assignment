<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');

$result = mysql_query("SELECT * FROM `users` WHERE `active` = 1 AND `expired` != 1 AND `username` != 'admin'");

while ($row = mysql_fetch_array($result)) :
	
	$count_days = check_days($row['active_date'], $row['active_days']);
	
	// Auto Renewal
	if ($count_days == 2 && $row['auto_renew'] == 1 && $row['balance'] >= 5) {
		
		$new_days = $row['active_days'] + 31;
		$new_balance = $row['balance'] - 5;
		$new_used = $row['total_used'] + 5;
		mysql_query("UPDATE `users` SET `active_days` = '".$new_days."', `balance` = '".$new_balance."', `total_used` = '".$new_used."' WHERE `id` = " . $row['id']);
		add_noti('<strong>[Auto Renewal] -$5 </strong> Your account has been successfully renewed for <strong>(31)</strong> days.',$row['id'],'Auto Renewal!');
		
	}
	
	// Expiring an Account
	if ($count_days <= 0 ) {
		mysql_query("UPDATE `users` SET `expired` = 1 WHERE `id` = " . $row['id']);
		add_noti('Your account has been expired',$row['id'],'Account Expired!');
	}
	
endwhile;

$set['cron_test'];
$val = "Check Expire Cron Job executed! on " . date('Y-m-d g:i:s A') . '\n\n';
$new_val = $set['cron_test'] . $val;
mysql_query("UPDATE `options` SET `option_value` = '".$new_val."' WHERE  `option_name` = 'cron_test' ");

?>