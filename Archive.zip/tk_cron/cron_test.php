<?php 
require_once('../includes/connection.php');
require_once('../includes/functions.php');

$set['cron_test'];
$val = "Test Cron Job executed! this file on " . date('Y-m-d g:i:s A') . '\n\n';
$new_val = $set['cron_test'] . $val;
mysql_query("UPDATE `options` SET `option_value` = '".$new_val."' WHERE  `option_name` = 'cron_test' ");
?>