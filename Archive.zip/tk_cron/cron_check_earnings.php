<?php
require_once('../includes/connection.php');
require_once('../includes/functions.php');
$result = mysql_query("SELECT * FROM `earnings` WHERE `status` = 'Pending'");
while ($row = mysql_fetch_array($result)) :
	
if (check_due($row['due_datetime'])) {
	
	$paying_user = get_user_info($row['user_id']);
	$update_user = mysql_query("UPDATE `users` SET `balance` = `balance` + '".$row['amount']."' WHERE `id` = " . $paying_user['id']);	
	$update_earnings = mysql_query("UPDATE `earnings` SET `status` = 'Completed' WHERE `id` = " . $row['id']);
	
} 
	
endwhile;
?>