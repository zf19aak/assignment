<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = "Refer your friends and earn $3! - Referral Program";
$meta_desc = "Refer your friends and earn $3 at each referral. " . $set['meta_desc'];

 include('header.php'); ?>
	
<div class="form_box referral_box">
<div class="box">
	<h2>Refer Your Friends and Earn $3!</h2>
    <img src="<?php echo $set['home']; ?>/img/earn-money-with-referral-program.jpg" alt="Earn Money With Referral program" />
	<p>When a new user clicks your referral link, signs up for an account and purchases any service (or deposits money) in Lancer Desk Marketplace, you will receive <strong>$3</strong> on that person's first cash deposit.</p>
	<p>
    <?php if (is_loggedin()) {?>
    	<a href="<?php echo $set['home']; ?>/account/" class="button">Got to Your Account</a>
    <?php } else { ?>
    	<a href="<?php echo $set['home']; ?>/sign-up/" class="button">Sign Up Now</a>
    <?php } ?><br><br>
    <a href="<?php echo $set['home']; ?>/how-it-works/">How Lancer Desk works?</a>
    
    </p>
    <div class="small_note">Your referral link will be located on your main "Account" Page.</div>
</div>
</div><!-- .form_box -->

    
<?php include('footer.php'); ?>