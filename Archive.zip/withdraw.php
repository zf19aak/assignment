<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = "Withdraw"; 
$withdraw_page = 1;

check_login();
$user = get_loggedin_info();
if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");	
$check_date = check_date($user['signup_date']);

if ($user['balance'] < $set['minimum_withdrawal']) { $error[] = "<strong>NOTE:</strong> Minimum withdrawal limit is <strong>$" . $set['minimum_withdrawal'] . "</strong>"; }
if ($user['payza_email'] == '') { redirect($set['home'].'/settings/?payment_emails=1');}
if (!isset($_POST['withdraw_submit']) && !isset($_POST['request_submit'])) {
if ($check_date < $set['withdraw_after_days']) { $error[] = "<strong>Note:</strong> Sorry, Your account must be ".$set['withdraw_after_days']." days old to withdraw funds. (".($set['withdraw_after_days'] -$check_date)." Days Left)"; }
}
if (isset($_POST['withdraw_submit'])) {
	
	$method = mres($_POST['method']);
	$from_balance = mres($_POST['from_balance']);
	$from_other = mres($_POST['from_other']);
	
	if ($method == "payza" && $user['payza_email'] == '') {  redirect($set['home'].'/settings/?payment_emails=1s'); exit; } 
	
	
	if ($from_other != '') 
		$amount = $from_other;
	else 
		$amount = $from_balance;
		
	if ($amount > $user['balance']) {
		$error[] = "Sorry, Requested amount cannot be greate than your available balance.";
	}
	
	if ($amount < $set['minimum_withdrawal']) {
		$error[] = "Sorry, Withdrawal amount should be at least <strong>$" . $set['minimum_withdrawal'] . "</strong>";
	}
	
	if ($check_date < $set['withdraw_after_days']) {
		$error[] = "<strong>Declind:</strong> Sorry, Your account must be ".$set['withdraw_after_days']." days old to withdraw funds. (".($set['withdraw_after_days'] -$check_date)." Days Left)";	
	}
	
	if (empty($error)){
		$confirm_form = 1;
	}
		
}

if (isset($_POST['request_submit'])) {
	
	$amount = mres($_POST['amount']);
	$method = mres($_POST['method']);
	$date = date("Y-m-d H:i:s");
	$new_balance = $user['balance'] - $amount;
	
	if (empty($error)) {
		
		$result = mysql_query("INSERT INTO `withdrawals` (`user_id`, `amount`, `method`, `datetime`, `completed`) VALUES (
		'".$user['id']."',
		'".($amount - 1)."', 
		'".$method."', 
		'".$date."', 
		'0'
		)");
		
		
		if ($result) {
			mysql_query("UPDATE `users` SET `balance` = '".$new_balance."' WHERE `id` = " . $user['id']);
			add_noti("You have sent a withdrawal request for <strong>($".($amount - 1).")</strong> via <strong>$method</strong>.", $user['id'],'Withdrawal Request Sent!');
			add_noti("You have paid <strong>($1)</strong> withdrawal fee.", $user['id'],0,true);
			redirect($set['home'].'/account/withdrawal-sent/');
		}
	}
		
}

include('header.php'); 
?>

<div class="activate_box">

<?php display_error(); display_notice(); ?>

<?php if (isset($_POST['withdraw_submit']) && isset($confirm_form)) { ?>
	
  <div class="box">

    	<h2>Please Confirm your withdrawal</h2>
        <form class="<?php echo $set['home']; ?>/withdraw/" method="post">
        <input type="hidden" name="amount" value="<?php echo $amount; ?>" />
        <input type="hidden" name="method" value="<?php echo $method; ?>" />
  		<table class="activate_form">
        	<tr>
  				<td class="label">Withdrawal Fee:</td>
                <td class="field" align="center"><strong class="big">$1</strong> (USD)</td>
  			</tr>
  			<tr>
  				<td class="label">You'll receive:</td>
                <td class="field" align="center"><strong class="big">$<?php echo $amount -1; ?></strong> (USD)</td>
  			</tr>
            
            <tr>
  				<td class="label">Method:</td>
                <td class="field" align="center">
                    <img src="<?php echo $set['home']; ?>/img/pmt-icons/<?php echo $method; ?>.png" alt="" />
                </td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo $set['home']; ?>/withdraw">Back</a></td>
                <td><input type="submit" value="Send Request" name="request_submit" /> </td>
            </tr>
  		</table>
         </form>
         
    </div><!-- .box -->
    
<?php } else { ?>
	
<div class="box">

    	<h2>Request a withdrawal</h2>
        <form class="<?php echo $set['home']; ?>/withdraw/" method="post">
  		<table class="activate_form">
  			<tr>
  				<td class="label">Amount:</td>
                <td class="field"><input type="radio" id="from_balance" checked="checked" name="from_balance" value="<?php echo $user['balance']; ?>" /> <label for="from_balance">Available Balance <strong>($<?php echo $user['balance']; ?>)</strong></label></td>
  			</tr>
            <tr>
  				<td class="label">Other Amount:</td>
                <td class="field"><input type="text" onkeyup="this.value=this.value.replace(/\D/g,'');" name="from_other" /></td>
  			</tr>
            <tr>
  				<td class="label">Method:</td>
                <td class="field">
                    <input type="radio" name="method" id="payza" checked="checked" value="payza" /> <label for="payza"><img src="<?php echo $set['home']; ?>/img/pmt-icons/payza.png" alt="Payza" /></label>
                </td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo $set['home']; ?>/account/">Cancel</a></td>
                <td><input type="submit" value="Proceed" name="withdraw_submit" /></td>
            </tr>
  		</table>
         </form>
         
    </div><!-- .box -->
	    
<?php } ?>

 
</div><!-- .activate_box -->

<div class="clear"></div>

<?php include('footer.php');  ?>    