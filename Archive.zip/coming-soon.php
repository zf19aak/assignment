<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = 'Upgrading...';
$meta_desc = 'Upgrading our webiste';

?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<?php if (isset($nofollow)) { ?>
<meta name="robots" content="noindex, nofollow"> 
<?php } ?>
<title><?php if (isset($page_title)) echo $page_title . " - "; echo $set['name']; ?></title>
<meta name="generator" content="<?php echo $set['name']; ?>">
<meta name="author" content="<?php echo $set['name']; ?>">
<meta name="description" content="<?php if (isset($meta_desc)) echo $meta_desc; else echo $set['meta_desc']; ?>">
<meta name="keywords" content="<?php if (isset($meta_keywords)) echo $meta_keywords; else echo $set['meta_keywords']; ?>">
<link rel="shortcut icon" href="<?php echo $set['home']; ?>/img/favicon.ico">
<link type="text/css" rel="stylesheet" href="<?php echo $set['home']; ?>/css/style_404.css">
</head>
<body>
<div class="wrap">
	<h1>We're cooking something!</h1>
	<h2>[Upgrading our webiste]</h2>
    <p>This won't take so long, please come back soon. <br>If you have any questions, contact us here at <a href="mailto:support@etallu.com<">support@etallu.com</a></p>
</div>
</body>
</html>