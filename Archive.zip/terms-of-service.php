<?php
require_once('includes/connection.php');
require_once('includes/functions.php');
$page_title = "Terms of Services";
$meta_desc = "These Terms of Service apply to you as a member, being a user at ". $set['name'] ." When registering at ". $set['name'] .", you confirm you have read, understood and accepted the following terms and conditions of these Terms of Service. If you do not agree to any of these terms, you must not register.";
include('header.php');
?>
  
  <div class="terms_of_service_wrap">
  
  
  
  <h2>TERMS OF SERVICE <span class="heading_meta">Last update: May 2014</span></h2>
  
  
  <p>Welcome to the <?php echo $set['name']; ?>.com. The following terms and conditions (these "Terms of Service"), govern your access to and use of the <?php echo $set['name']; ?> website, including any content, functionality and services offered on or through www.<?php echo $set['name']; ?>.com (the "Site").</p>

<p>Please read the Terms of Service carefully before you start to use the Site. By using the Site, opening an account or by clicking to accept or agree to the Terms of Service when this option is made available to you, you accept and agree to be bound and abide by these Terms of Service and our <a href="<?php echo $set['home']; ?>/privacy-policy/">Privacy Policy</a>, incorporated herein by reference. If you do not want to agree to these Terms of Service or the Privacy Policy, you must not access or use the Site.</p>

<p>This Site is offered and available to users who are 13 years of age or older. If you are under 13 you may not use this Site or the <?php echo $set['name']; ?> services. By using this Site, you represent and warrant that you are of legal age to form a binding contract with the Company and meet all of the foregoing eligibility requirements. If you do not meet all of these requirements, you must not access or use the Site.</p>
  
  
  <h2>The Short Version</h2>
  
  <ul>
    <li>Services on <?php echo $set['name']; ?> are offered for a fixed price set by sellers.</li>
    <li>Only registered users may buy and sell on <?php echo $set['name']; ?>. Registration is free.</li>
    <li>Sellers gain account statuses (Levels) based on their performance and reputation. Advanced levels provide their owners with benefits, including offering services for more than $10 or allowing the seller to offer multiple services or selling their services in multiples.</li>
    <li>Some sellers may offer additional upgrades to their service or sell their service a number of times, depending on their status.</li>
    <li>Sellers must fulfill their orders, and may not cancel on a regular basis or without cause.</li>
    <li>Users may not offer or accept payments using any method other than placing an order through <?php echo $set['name']; ?>.com. Services must be ordered using the Order Now button.</li>
    <li>Buyers are granted all rights for the delivered work, unless otherwise specified by the seller in the Gig description. <?php echo $set['name']; ?> retains the right to use all published delivered works for <?php echo $set['name']; ?> marketing and promotion purposes.</li>
    <li>We care about your privacy. You can read our Privacy Policy <a href="<?php echo $set['home']; ?>/privacy-policy/">here</a>. The Privacy Policy is a part of these Terms of Service.</li>
</ul>
  
  <h2>SELLERS</h2>
  <h3>BASICS</h3>
  
   <ul>
    	<li>Each $6 service you sell and successfully deliver, accredits your account with a net revenue of $4.</li>
    	<li>Buyers pay <?php echo $set['name']; ?> for orders in advance.</li>
    	<li><?php echo $set['name']; ?> accredits sellers once an order is completed.</li>
    	<li>Sellers may withdraw their revenues using one of <?php echo $set['name']; ?>’s withdrawal options.</li>
    	<li>If an order is cancelled (for any reason), the payment funds will be returned to the buyer.</li>
    	<li>Sellers may withdraw their revenues to a PayPal account of their choice, according to the terms specified below.</li>
    	<li>The seller's rating is calculated based on a number of factors, including feedback received from buyers, amount of orders, cancelled orders, and late deliveries.</li>
    </ul>

	<h3>SELLER STATUSES</h3>
	
    <ul>
    	<li><?php echo $set['name']; ?> is all about helping sellers leverage their skills. We seek to empower top performing sellers with helpful tools to grow their business.</li>
    	<li>Sellers who invest in self-promotion may achieve greater customer satisfaction. And, if they deliver on time and maintain high quality and ratings, <?php echo $set['name']; ?> may reward them with new statuses, special opportunities, benefits, and tools that come with it.</li>
    </ul>
    
    <h3>LEVELS</h3>
    
    <ul>
    	<li><?php echo $set['name']; ?> sellers can gain account statuses (Level 1, Level 2 and Level3) based on their activity, performance and reputation.</li>
    	<li>Each level opens up additional opportunities and tools for the sellers to extend their business. Sellers who are promoted to a higher level are required to maintain their service level and high rating to keep their preferred status.</li>
    	<li>Levels are updated periodically by an automated system. Sellers who cannot maintain their high quality service, experience a rating drop, or stop delivering on time risk losing their seller status and the benefits that come with it. For example, late deliveries or cancellations can cause a seller to move to a different Level. For more information, see <a href="<?php echo $set['home']; ?>/levels/">Seller Levels</a>.</li>
    </ul>
    

<h3>ELITE SELLERS</h3>

    Elite Sellers are chosen manually by <?php echo $set['name']; ?> editors from the list of the highest seller level based on a list of criteria, including seniority, volume of sales, an extremely high rating, exceptional customer care and community leadership. Elite Sellers gain access to more extensive features than previous levels, including exclusive access to beta features and VIP support. For more information, see <a href="<?php echo $set['home']; ?>/levels/">Seller Levels</a>.

<h3>Handling Orders</h3>

    <ul>
    	<li>When a buyer orders a service, the seller is notified by email as well as notifications on the site while logged in to your account.</li>
    	<li>Sellers are required to meet the delivery time they specified when creating their services. Failing to do so will allow the buyer to cancel the order and may harm the seller's rating.</li>
    	<li>Both buyers and sellers have the option to cancel an order by mutual agreement. Mutual cancellations have no negative effect on rating. However, excessive cancellations, of any type, have a negative effect on Levels eligibility.</li>
    	<li>Unanswered mutual cancellation requests will automatically be accepted after 48 hours, while reducing the non-responding user's rating.</li>
    </ul>

<h3>Staying out of Trouble</h3>

    <ul>
    	<li>To protect our users' privacy, user identities must be kept anonymous. Requesting or providing Email addresses, Skype/IM usernames, telephone numbers or any other personal contact details (other than your name) to communicate outside of the <?php echo $set['name']; ?> network is not permitted.</li>
    	<li>All communications, information and file exchanges must be performed exclusively using <?php echo $set['name']; ?>'s messaging system.</li>
    	<li>Posting or sending adult, illegal, rude, abusive, improper, copyright protected, promotional, spam, violent, nonsense or any uncool stuff is strictly prohibited. Doing so will get your account blocked permanently.</li>
    </ul>

<h3>Work Delivery &amp; Communications</h3>

<ul>
    	<li>You are responsible for scanning all transferred files for viruses and malware. <?php echo $set['name']; ?> will not be held responsible for any damages which might occur due to site usage, use of content or files transferred.</li>
    	<li>Sellers must deliver completed files and/or proof of work using the Deliver Completed Work checkbox (located on the Order page).</li>
    	<li>Responding and posting a review: Once work is delivered, the buyer has three days to respond and post a review. If no response is provided within the response time, the order will be considered completed.</li>
    </ul>

<h3>Withdrawing Revenues</h3>

    <ul>
    	<li>To withdraw your revenues, you must have an account with at least one of <?php echo $set['name']; ?>'s withdrawal providers.</li>
    	<li>Your <?php echo $set['name']; ?> profile can be associated with only one account from each <?php echo $set['name']; ?> withdrawal providers. A withdrawal provider account can be associated with only one <?php echo $set['name']; ?> profile.</li>
    	<li>Revenues are only made available for withdrawal from the Revenue page after a safety clearance period of 10 days after the order is marked as complete.</li>
    	<li>Withdrawal fees vary depending on the withdrawal provider / method.</li>
    	<li>Withdrawals are final and cannot be undone. We will not be able to refund or change this process once it has begun.</li>
    </ul>

<h2>BUYERS</h2>
    
<h3>Ordering</h3>

    <ul>
    	<li>Services may be purchased using a PayPal account, in certain countries Skrill and from your available ettallu account balance.</li>
    	<li>Once payment is confirmed, your order will be created.</li>
    	<li>As a buyer, your identity is kept anonymous at all times. To protect your privacy, avoid requesting or providing Email addresses, Skype/IM usernames, telephone numbers or any other personal contact information to communicate outside of <?php echo $set['name']; ?>.</li>
    	<li>You may not offer sellers to pay, or make payment using any method other than through the <?php echo $set['name']; ?>.com site.</li>
    	<li>You may not pay other users directly using any method other than ordering through the <?php echo $set['name']; ?> order page. In case you have been asked to use an alternative payment method, please report it immediately <a href="<?php echo $set['home']; ?>/support/">here</a>.</li>
    	<li>Filing a dispute or reversing a payment through your payment provider or your bank prior to attempting to resolve the matter by working it out with the Seller through the <?php echo $set['name']; ?> dispute resolution tools and contacting customer support through this Site may get your account suspended to investigate possible security violations.</li>
    	<li>In case of a problem, always try and work things out with your seller. If you need further assistance, contact our customer support <a href="<?php echo $set['home']; ?>/support/">here</a>.</li>
    	<li>Order cancellations (when eligible) can be performed by customer support only up to a period of 10 days from order completion date. We will not be able to cancel orders after that time.</li>
    </ul>

<h2>FORUM AND GENERAL USER BEHAVIOR</h2>

<ul>
          <li>You have access to reading the Forum, except for private areas.</li>
          <li>When registered and logged in, you can post new topics and answer in previously created ones in the Forum.</li>
          <li>You must respect other users in all of these areas under the penalty of being banned from them if you don&#39;t.</li>
          <li>You have the right to express yourself without offending other users.</li>
          
          <li>All kinds of publicity, attempts to get referrals, money offers/exchange/requests and the offer or request of services are prohibited in Forum replies/topics. Spamming the Forum with nonsense posts/messages, duplicated topics, illegal content, sharing email addresses, social website links and instant messenger IDs is also prohibited.</li>
          
          <li>Any accusation without proof, intimidation, threat or disrespect against <?php echo $set['name']; ?> and / or <?php echo $set['name']; ?> staff / assistants, here or elsewhere will be seen as disrespectful and may lead to the removal of the privilege of using the Forum as well as the permanent suspension of your account, temporary suspension of membership or any other benefits.</li>
          
          <li>Posting topics or messages that may directly or indirectly be prejudicial to <?php echo $set['name']; ?>, its users, sponsors or service providers will be considered an offense and are strictly prohibited.</li>

</ul> 

<h2>ANTI-CHEAT POLICY</h2>
<ul>
<li>Each attempt, in any way, to hack into the system will be logged.</li>
<li>Sometimes we will warn you, sometimes we will not. In either way, when you request payout, our monitoring system will analyze your actions and take its own actions in return. Normally, attempts to hack the system will result in account termination.</li>
<li>We may or may not inform you that your account was terminated. In the first case, we will send you an email. In either case, you will be notified as soon as you try to use any of the services at <?php echo $set['name']; ?>.</li>
</ul>

<h2>General Terms</h2>

    <ul>
    	<li>Violation of <?php echo $set['name']; ?>'s Terms of Service may get your account blocked permanently.</li>
    	<li>Sellers will be able to withdraw their revenues from blocked accounts after a safety period of 45 to 90 days, depending on the reason, from the day of the last cleared payment received in their account and subject to <?php echo $set['name']; ?>'s approval.</li>
    	<li>Disputes should be handled by contacting <?php echo $set['name']; ?> customer support.</li>
    	<li><?php echo $set['name']; ?> reserves the right to put any account on hold or permanently cancel accounts due to breach of these terms or any illegal or inappropriate use of the site or services. Users with accounts on hold will not be able to sell or buy on <?php echo $set['name']; ?>.</li>
    	<li><?php echo $set['name']; ?> may make changes to its Terms of Service from time to time. When these changes are made, <?php echo $set['name']; ?> will make a new copy of the terms of service available on this page.</li>
    	<li>You understand and agree that if you use <?php echo $set['name']; ?> after the date on which the Terms of Service have changed, <?php echo $set['name']; ?> will treat your use as acceptance of the updated Terms of Service.</li>
    </ul>

	<h3>Disputes</h3>
    
    <ul>
    	<li>We encourage our buyers and sellers to try and settle conflicts amongst themselves. If for any reason this fails, users can contact <?php echo $set['name']; ?>'s customer support department for assistance <a href="<?php echo $set['home']; ?>/support/">here</a>.</li>
    	<li><?php echo $set['name']; ?> will not refund payments made for cancelled orders back to your payment provider. Funds from order refunds are returned to the buyer's purcahse balance and are available for future purchases on <?php echo $set['name']; ?>.</li>
    </ul>

<h2>Ownership and Limitations (Legal Stuff)</h2>

<p>Ownership and limitations: unless clearly stated otherwise in the service description text, when the work is delivered, the buyer is granted all intellectual property rights, including but not limited to, copyrights for the work delivered from the seller and the seller waives any and all moral rights therein. For removal of doubt, in custom created work (such as art work, design work, report generation etc.), the delivered work shall be the exclusive property of buyer. The seller expressly agrees to assign to buyer the copyright in any delivered work that do not meet the requirements of a work-for-hire under the U.S. Copyright Act. Additionally, independent of the U.S. Copyright Act, the seller agrees that unless indicated otherwise in the service description, once the order is completed the seller assigns along with it to the buyer, to the fullest extent possible under the law, all of its rights, title and interest, if any, in and to the delivered work and waives any and all moral rights in connection therewith. All transfer and assignment of intellectual property to buyer shall be subject to full payment for the Gig.</p>

<p>Sellers further confirm that whatever information they receive from the buyer, which is not public domain, shall not be used for any purpose whatsoever other than for the delivery of the work to the buyer.</p>

<p>Furthermore, users (both buyers and sellers) agree that unless they explicitly indicate otherwise, the content users voluntarily create/upload to <?php echo $set['name']; ?>, including service texts, photos, videos, usernames,  user photos, user videos and any other information, including the display of delivered work, may be used by <?php echo $set['name']; ?> for no consideration for marketing and/or other purposes.</p>

<p>We wish to remind that <?php echo $set['name']; ?>.com's content is based on User Generated Content (UGC). <?php echo $set['name']; ?> does not check user uploaded/created content for violations of copyright, trademarks or other rights. We invite everyone to report violations together with proof of ownership. Reported violating content may be removed or disabled. Furthermore, <?php echo $set['name']; ?> is not responsible for the content, quality or the level of service provided by the Sellers. We provide no warranty with respect to the Gigs, their delivery, and any communications between buyers and sellers. We encourage users to take advantage of our rating system, our community and common sense in choosing appropriate service offers.</p>

<p>By offering a service, the seller undertakes that he has sufficient permissions, rights and/or licenses to provide, sell or resell the service that they offer on <?php echo $set['name']; ?>.</p>

<p>Sellers advertising their service online must comply with laws and terms of service of the advertising platform or relevant website used to advertise. Failing to do so may result in removal of the service and may lead to the suspension of seller's account.</p>

<h3>Disclaimer of Warranties</h3>

<p>YOUR USE OF THE SITE, ITS CONTENT AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE IS AT YOUR OWN RISK. THE SITE, ITS CONTENT AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE ARE PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. NEITHER <?php echo $set['name']; ?> NOR ANY PERSON ASSOCIATED WITH <?php echo $set['name']; ?> MAKES ANY WARRANTY OR REPRESENTATION WITH RESPECT TO THE COMPLETENESS, SECURITY, RELIABILITY, QUALITY, ACCURACY OR AVAILABILITY OF THE WEBSITE.
	
	THE FOREGOING DOES NOT AFFECT ANY WARRANTIES WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.</p>

<h3>Limitation on Liability</h3>

<p>IN NO EVENT WILL <?php echo $set['name']; ?>, ITS AFFILIATES OR THEIR LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, THE WEBSITE, ANY WEBSITES LINKED TO IT, ANY CONTENT ON THE WEBSITE OR SUCH OTHER WEBSITES OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE OR SUCH OTHER WEBSITES, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO, PERSONAL INJURY, PAIN AND SUFFERING, EMOTIONAL DISTRESS, LOSS OF REVENUE, LOSS OF PROFITS, LOSS OF BUSINESS OR ANTICIPATED SAVINGS, LOSS OF USE, LOSS OF GOODWILL, LOSS OF DATA, AND WHETHER CAUSED BY TORT (INCLUDING NEGLIGENCE), BREACH OF CONTRACT OR OTHERWISE, EVEN IF FORESEEABLE.</p>
<p>THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.</p>


    
</div><!-- .terms_of_service_wrap -->
  
 
    
<?php include('footer.php'); ?>