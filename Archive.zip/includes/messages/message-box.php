<?php $msg_user = get_user_info($row['user_id']); ?>
<?php if ($row['type'] == 'order_delivery') {?>
<div class="msg_note">
	<?php if (isset($i_am_seller)) { ?>
    	<h2>Order Delivered!</h2>
    <?php } else { ?>
    	<h2>Here is your delivery!</h2>
    <?php } ?>
    <?php $due_datetime = get_due_completion_datetime($order['delivered_datetime']); ?>
    <p>Delivered on <?php echo get_date($order['delivered_datetime'],'F j, Y'); ?></p>
    <?php if ($order['status'] == 'Delivered') { ?>
    <p>This ordere will be marked as completed in 3 days on <strong><?php echo get_date($due_datetime,'F j, Y'); ?></strong>.</p>
    <?php } ?>
    
</div><!-- .msg_note -->        
<?php } ?>
<div class="message_box<?php echo $box_class; ?>">
<div class="thumb">
	<a href="<?php echo user_permalink($msg_user['id']); ?>"><?php the_avatar($msg_user['id'],50); ?></a>
</div><!-- .thumb -->

<?php

$check_attachments = mysql_query("SELECT * FROM `files` WHERE `msg_id` = " . $row['id']);
if (mysql_num_rows($check_attachments) > 0) {
$attach_class = ' with_attachment';
?>
<div class="attachments">
    <strong>ATTACHMENTS</strong>
    <?php while ($file_row = mysql_fetch_array($check_attachments)) { 
		$filename = get_original_file_name($file_row['name']);
		$show_name = (strlen($filename) > 32) ? substr($filename,0,27).'...' : $filename;
	?>
    <div class="attachment">
        <a href="<?php echo file_permalink($file_row['id']); ?>" title="<?php echo $filename; ?>"><?php echo $show_name ?></a> <span>(<?php echo $file_row['size']; ?>)</span>
        
    </div>
    <?php } ?>
</div><!-- .attachments -->
<?php } else { $attach_class = ''; } ?>
<div class="info<?php echo $attach_class; ?>">
	 <div class="user">
     <span class="name"><a href="<?php echo user_permalink($msg_user['id']); ?>"><?php echo $msg_user['username'] ?></a></span>
     <small class="meta"><?php datetime($row['datetime']); ?> <a href="#">Report</a></small>
     </div>
     <div class="clear"></div>
    <div class="message"><?php echo nl2br($row['message']); ?></div>
</div><!-- .info -->

<div class="clear"></div>
</div><!-- .message_box -->
<?php if ($row['type'] == 'info_submitted') {?>
<div class="msg_note">    
    	<h2>Order Started!</h2>
        
		<?php
		$today = new DateTime(date('Y-m-d H:i:s'));
	   	$date = $today->diff(new DateTime($order['due_datetime']));
		$elivery_time = '';
		
		if ($date->d != 0) {
			$elivery_time .= $date->d . ' Day';
		}
		if ($date->d != 0 && $date->d != 1) {
			$elivery_time .= 's';
		}
		if ($date->h != 0) {
			$elivery_time .= ' '.$date->h . ' Hour';
		}
		if ($date->h != 0 && $date->h != 1) {
			$elivery_time .= 's ';
		} ?>
        
        <?php  if ($order['status'] == 'Active' && !check_due($order['due_datetime'])) { ?>
        <p>Delivery due on: <strong><?php echo get_date($order['due_datetime'],'F j, Y'); ?></strong> in <strong><?php echo $elivery_time; ?></strong></p>
        <?php } elseif($order['status'] == 'Active') { ?>
        <p>Delivery was due <strong><?php echo $elivery_time; ?> ago</strong> on <strong><?php echo get_date($order['due_datetime'],'F j, Y'); ?></strong></p>
        <?php } else { ?>
        <p>Order Was Due on <?php echo get_date($order['due_datetime'],'F j, Y H:i'); ?></p>
        <?php } ?>
        
</div><!-- .msg_note -->
<?php } ?>
<?php $first_count = 0; ?>