<div class="box send_reply_box">
<h3>Send Message</h3>
    <form action="<?php echo $form_url; ?>" method="post">
		<textarea name="message" rows="4" cols="40" required="required"></textarea>
		
        <?php if (!isset($no_attachment)) { ?>
		<div class="left"><input type="file" name="file_upload" id="file_upload" /></div>
        <?php } else { $rel_id = ''; } ?>
		
		<div class="right">
            <?php if(isset($i_am_seller)) { ?>
            	<input type="hidden" value="0" name="delivered" checked="checked" />
            	<input type="checkbox" value="1" id="deliver_work" name="delivered"><label for="deliver_work">Deliver Work</label>
            <?php } ?>
             <input type="submit" name="<?php echo $form_submit_name; ?>" value="Send Message" />
		</div>
        
		<div class="clear"></div>
    </form>
</div><!-- .send_reply_box -->

