<?php
	require_once('recaptchalib.php');
	
	$publickey = $set['recaptcha_public_key'];
	$privatekey = $set['recaptcha_private_key'];
	
	$resp = null;
	$error_captcha = null;
	
	// checking captcha
	if (isset($_POST["recaptcha_response_field"])) {
	        $resp = recaptcha_check_answer ($privatekey, $_SERVER["REMOTE_ADDR"], $_POST["recaptcha_challenge_field"], $_POST["recaptcha_response_field"]);
	        if (!$resp->is_valid) {
	                $error_captcha = $resp->error;
					$error[] = "<strong>Warning:</strong> Please enter the correct words!";
	        }
	}
?>