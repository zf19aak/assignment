<?php

//$user_id = 4;
//$new_active_days = 30;

if (isset($user_id) && isset($new_active_days)) :

$this_user = get_user_info($user_id);
$new_used = $this_user['total_used'] + $payment_amount;

if (check_days($this_user['active_date'], $this_user['active_days']) >= 1) {

	// Account is not expired
	$new_days = $this_user['active_days'] + $new_active_days;
	$result = mysql_query("UPDATE `users` SET  `active_days` = '".mres($new_days)."', `total_used` = '".$new_used."' WHERE `id` = ".intval($user_id));
	
} else {
	
	// Accunt was expired and renew now
	$active_date = date('d-m-Y');
	$active_time = date('g:i:s A');
	
	$result = mysql_query("UPDATE `users` SET 
	`expired` = '0',  
	`total_used` = '".$new_used."',  
	`active_date` = '".mres($active_date)."', 
	`active_time` = '".mres($active_time)."',  
	`active_days` = '".mres($new_active_days)."' 
	WHERE `id` = ".intval($user_id));
	
}

add_noti('Congrats! You have successfully renewed your account for <strong>(' . $new_active_days . ')</strong> days.', $user_id,'Account Renewed!');

endif;
?>