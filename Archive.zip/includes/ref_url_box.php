<div class="box banners_wrap">
    <h2>Your Referral URL is: <span class="right"><a href="<?php echo $set['home']; ?>/referral-program/" class="new_button">For What?</a></span></h2>
    <div class="banner_box">
        <?php echo $set['home'] . "/?ref=".  $user['username']; ?>
    </div>
     <div class="clear"></div>
</div><!-- .box -->