<?php
require_once('includes/connection.php');
require_once('includes/functions.php');


function users_by_date($year,$month=false,$day=false) {
	
	$sql = "SELECT COUNT(id) as `stat_count` FROM `users` WHERE YEAR(signup_date) = ".intval($year);
	if ($month) $sql .= " AND MONTH(signup_date) = ".intval($month);
	if ($day) $sql .= " AND DAY(signup_date) = ".intval($day);
	
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	return $row['stat_count'];
	
}






?>
<html>
  <head>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['List', 'Users'],
		  <?php
for ($i = 0 ; $i < 12 ; $i++) {
	$timestamp = strtotime("-$i months");
	$count = users_by_date(date('Y', $timestamp),date('m', $timestamp));
	$month = date('F', $timestamp);
	echo "['$month',  $count],\n";
}
?>
        ]);

        var options = {
          //title: '',
		  lineWidth: 4,
		  pointSize: 7,
		  colors: ['#058dc7'],
		  legend: {position: 'top', textStyle: {color: '#444', fontSize: 12}},
		  hAxis: {textStyle: { color: '#444', fontName: 'Arial', fontSize: 12, bold: '400', italic: 'false' }, direction: -1, viewWindowMode: "explicit", viewWindow:{ min: 0 }},
		  vAxis: {textStyle: { color: '#444', fontName: 'Arial', fontSize: 12, bold: '400', italic: 'false' }, gridlines: {color: '#f1f1f1'}, textPosition: 'in', viewWindowMode: "explicit", viewWindow:{ min: 0 }},
		  tooltip: {textStyle: { color: '#444', fontName: 'Arial', fontSize: 12, bold: '400', italic: 'false' }},
		  chartArea: {width: '98%', height: '78%'},
		  axisTitlesPosition: 'in',
		  
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
    <style type="text/css">
    body { font-family:Arial, Helvetica, sans-serif; color:#444; font-size:13px; }
    </style>
  </head>
  <body>
    <div id="chart_div" style="width: 100%; height: 300px;"></div>
  </body>
</html>
<?php
for ($i = 0 ; $i < 12 ; $i++) {
	$multiply_by = 31;
	$new_i = ($i * $multiply_by);
	$timestamp = strtotime("-$new_i days");
	//$count = users_by_date(date('Y', $timestamp),date('m', $timestamp));
	//$month = date('M', $timestamp);
	
	echo date('Y-m-d', $timestamp) . '<br>';
}
?>



