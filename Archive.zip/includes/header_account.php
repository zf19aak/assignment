<?php
require_once('includes/connection.php');
require_once('includes/functions.php');
check_login();
$user = get_loggedin_info();
if ($user['email_verified'] == 0) redirect($set['home']."/verify-email/");
//if ($user['settings_updated'] == 0) { redirect($set['home']."/settings/update/");}
?>