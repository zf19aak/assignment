<div class="sidebar">
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/inbox/">All</a></li>
        <li><a href="<?php echo $set['home']; ?>/inbox/">Unread</a></li>
        <li><a href="<?php echo $set['home']; ?>/inbox/">Stared</a></li>
    </ul>
	<hr>
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/forum/">Forum</a></li>
        <li><a href="<?php echo $set['home']; ?>/support/">Support</a></li>
    </ul>
</div><!-- .sidebar -->

<div class="clear"></div>