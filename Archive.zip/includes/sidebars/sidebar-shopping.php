<div class="sidebar">
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/shopping/">My Shopping</a></li>
        <li><a href="<?php echo $set['home']; ?>/payments/">Payments</a></li>
    </ul>
	<hr>
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/services/" class="button">Explore Services</a></li>
    </ul>
</div><!-- .sidebar -->

<div class="clear"></div>