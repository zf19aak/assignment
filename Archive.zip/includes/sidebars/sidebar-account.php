<div class="sidebar">
    <ul>
        <li><a href="<?php echo $set['home']; ?>/inbox/">Inbox</a></li>
        <li><a href="<?php echo $set['home']; ?>/settings/">Settings</a></li>
        <li><a href="<?php echo $set['home']; ?>/referrals/">Referrals</a></li>
    </ul>
    <h2>Sales</h2>
    <ul>
      	<li><a href="<?php echo $set['home']; ?>/sales/">All Sales</a></li>
        <li><a href="<?php echo $set['home']; ?>/my-services/">My Services</a></li>
        <li><a href="<?php echo $set['home']; ?>/earnings/">Earnings</a></li>
    </ul>
    <h2>Shopping</h2>
    <ul>
      	<li><a href="<?php echo $set['home']; ?>/shopping/type/active/">My Shopping</a></li>
        <li><a href="<?php echo $set['home']; ?>/payments/">Payments</a></li>
    </ul>
    <h2>Global</h2>
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/forum/">Forum</a></li>
        <li><a href="<?php echo $set['home']; ?>/support/">Support</a></li>
    </ul>
    <hr>
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/new/" class="button">Create Service</a></li>
    </ul>
</div><!-- .sidebar -->

<div class="clear"></div>