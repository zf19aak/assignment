<div class="sidebar">
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/sales/">All Sales</a></li>
        <li><a href="<?php echo $set['home']; ?>/my-services/">My Services</a></li>
        <li><a href="<?php echo $set['home']; ?>/earnings/">Earnings</a></li>
    </ul>
	<hr>
    <ul>
    	<li><a href="<?php echo $set['home']; ?>/new/" class="button">Create Service</a></li>
    </ul>
</div><!-- .sidebar -->

<div class="clear"></div>