<?php

if (isset($user_id) && isset($package)) :

$active_date = date('d-m-Y');
$active_time = date('g:i:s A');

if ($package == "Basic") $active_days = 60;
if ($package == "Golden" || $package == "Ultimate") $active_days = 90;

$result = mysql_query("UPDATE `users` SET 
	`active` = '1', 
	`active_date` = '".mres($active_date)."', 
	`active_time` = '".mres($active_time)."', 
	`active_days` = '".mres($active_days)."',
	`package` = '".mres($package)."' 
	 WHERE `id` = ".intval($user_id));

$user_result = mysql_query("SELECT * FROM `users` WHERE `id` = ".intval($user_id));
$user_row = mysql_fetch_array($user_result);

add_noti('You have successfully activated your account with <strong>('.$package.')</strong> Package.', $user_id,'Account Activated!');


// level one =====================================================================================

$result_one = mysql_query("SELECT * FROM `users` WHERE `username` = '".$user_row['referrer']."'");
$check_count = mysql_num_rows($result_one);

if ($check_count == 1){
	$row_one = mysql_fetch_array($result_one);
	
	if ($row_one['active'] == 1 && check_days($row_one['active_date'],$row_one['active_days']) >= 1 && $row_one['suspended'] == 0) {
		if ($row_one['package'] == 'Basic') $new_balance = $row_one['balance'] + 5;
		if ($row_one['package'] == 'Golden') $new_balance = $row_one['balance'] + 5;
		if ($row_one['package'] == 'Ultimate') $new_balance = $row_one['balance'] + 10;
		
		$total_anu = $row_one['total_anu'] + '1';
		
		if ($row_one['package'] == 'Golden' || $row_one['package'] == 'Ultimate') {
			
			if ($total_anu == 15) $fixed_bonus = 15;
			if ($total_anu == 25) $fixed_bonus = 25;
			if ($total_anu == 50) $fixed_bonus = 50;
			if ($total_anu == 100) $fixed_bonus = 100;
			if ($total_anu == 200) $fixed_bonus = 300;
			if ($total_anu == 300) $fixed_bonus = 300;
			if ($total_anu == 400) $fixed_bonus = 400;
			if ($total_anu == 500) $fixed_bonus = 500;
			if ($total_anu == 1000 && $row_one['package'] == 'Ultimate') $fixed_bonus = 1000;

		}
		
		if (isset($fixed_bonus)) {
			$new_balance += $fixed_bonus;
			add_noti('Congrats! You have received <strong>($'.$fixed_bonus.')</strong> fixed bonus for reaching <strong>'.$total_anu.'</strong> '.$set['anu_name'].'s.', $row_one['id'], 'Fixed Bonus!');	 
		}
		
		$update_one = mysql_query("UPDATE `users` SET `balance` = '".$new_balance."', `total_anu` = '".$total_anu."' WHERE `id` =".$row_one['id']);
		$got_bonous = $new_balance - $row_one['balance'];
		add_noti('Congrats! You have got an <strong>'.$set['anu_name'].'</strong> <strong> ('.$user_row['username'].')</strong> &amp; received <strong>($'.$got_bonous.')</strong> commission.', $row_one['id'],'New ' . $set['anu_name']);
	} else {
		add_noti('You have got a new <strong>'.$set['anu_name'].'</strong> referral, but unfortunately your account was not active.', $row_one['id'],'Bad News for you :(');		
	}
	
	
		// level Two =====================================================================================
		
		if ($row_one['referrer'] != '') {
			
			$result_two = mysql_query("SELECT * FROM `users` WHERE `username` = '".$row_one['referrer']."'");
			$count_tow = mysql_num_rows($result_two);
			
			if ($count_tow == 1){
			$row_two = mysql_fetch_array($result_two);
	
				if ($row_two['active'] == 1 && check_days($row_two['active_date'],$row_two['active_days']) >= 1 && $row_two['suspended'] == 0 ) {
					if ($row_two['package'] == 'Basic') $new_balance = $row_two['balance'] + 1;
					if ($row_two['package'] == 'Golden') $new_balance = $row_two['balance'] + 5;
					if ($row_two['package'] == 'Ultimate') $new_balance = $row_two['balance'] + 5;
					
					$total_manu = $row_two['total_manu'] + 1;
					
					$update_two = mysql_query("UPDATE `users` SET `balance` = '".$new_balance."', `total_manu` = '".$total_manu."' WHERE `id` =".$row_two['id']);
					
					
					$got_bonous = $new_balance - $row_two['balance'];
					add_noti('Congrats! You have got a <strong>'.$set['manu_name'].'</strong> referral &amp; received <strong>($'.$got_bonous.')</strong> commission.', $row_two['id'],'New '.$set['manu_name']);
				} else {
				  	add_noti('You have got a <strong>'.$set['manu_name'].'</strong>, but unfortunately your account was not active.', $row_two['id'],'Bad News for you :(');	
				}
			
			
				// level Three =====================================================================================
		
				if ($row_two['referrer'] != '') {
					
					$result_three = mysql_query("SELECT * FROM `users` WHERE `username` = '".$row_two['referrer']."'");
					$count_three = mysql_num_rows($result_three);
					
					if ($count_three == 1){
					$row_three = mysql_fetch_array($result_three);
					
						if ($row_three['active'] == 1 && check_days($row_three['active_date'],$row_three['active_days']) >= 1 && $row_three['suspended'] == 0 ) {
							if ($row_three['package'] == 'Basic') $new_balance = $row_three['balance'] + 0;
							if ($row_three['package'] == 'Golden') $new_balance = $row_three['balance'] + 0;
							if ($row_three['package'] == 'Ultimate') $new_balance = $row_three['balance'] + 1;
							
							$total_tanu = $row_three['total_tanu'] + 1;
							
							$update_three = mysql_query("UPDATE `users` SET `balance` = '".$new_balance."', `total_tanu` = '".$total_tanu."' WHERE `id` =".$row_three['id']);

							$got_bonous = $new_balance - $row_three['balance'];
							add_noti('Congrats! You have got a <strong>'.$set['tanu_name'].'</strong> referral and received <strong>($'.$got_bonous.')</strong> commission.', $row_three['id'],'New '.$set['tanu_name']);
						} else {
							add_noti('You have got a <strong>'.$set['tanu_name'].'</strong> referral, but unfortunately your account was not active.', $update_three['id'],'Bad news for you :(');	
						}
					}
						
				} // if Thirsd Referrer exist
				
		}
	} // if Second Referrer exist
	
} // if First Referrer exists

endif;
	
?>