﻿<?php

function count_services($user_id,$status){
	$query = mysql_query("SELECT `id` FROM `services` WHERE `status` = '".mres($status)."' AND `user_id` = " . intval($user_id));
	return mysql_num_rows($query);
}

function get_conversation_id($this_id,$user_id) {
	$query = mysql_query("SELECT `id` FROM `conversations` WHERE (`to_id` = '".$this_id."' OR `from_id` = '".$this_id."') AND (`to_id` = '".$user_id."' OR `from_id` = '".$user_id."')");
	$count = mysql_num_rows($query);
	if ($count == 1) {
		$row = mysql_fetch_array($query);
		return $row['id'];
	} else {
		return false;	
	}
}

function get_file_info($val,$by_code=false) {
	if ($by_code) {
		$query = mysql_query("SELECT * FROM `files` WHERE `code` = '".$val."' ");
	} else {
		$query = mysql_query("SELECT * FROM `files` WHERE `id` = ".$val);
	}
	
	$count = mysql_num_rows($query);
	if ($count == 1) {
		return mysql_fetch_array($query);
	} else {
		return false;	
	}
}

function get_original_file_name($file_name){
	$filename = explode('-',$file_name,3);
	return $filename[2];
}

function file_permalink($id){
	global $set;
	$file = get_file_info($id);
	return $set['home'] . '/download/'.$file['code'].'/'.get_original_file_name($file['name']);
}

function filesize_formatted($size){
    $units = array( 'B', 'KB', 'MB', 'GB');
    $power = $size > 0 ? floor(log($size, 1024)) : 0;
    return number_format($size / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power];
}

function get_conversation_info($id) {
	$query = mysql_query("SELECT * FROM `conversations` WHERE `id` = ".$id);
	$count = mysql_num_rows($query);
	if ($count == 1) {
		return mysql_fetch_array($query);
	} else {
		return false;
	}
}

function get_message_info($id) {
	$query = mysql_query("SELECT * FROM `messages` WHERE `id` = ".intval($id));
	$count = mysql_num_rows($query);
	if ($count == 1) {
		return mysql_fetch_array($query);
	} else {
		return false;	
	}
}

function get_service_info($id) {
	$query = mysql_query("SELECT * FROM `services` WHERE `id` = ".$id);
	$count = mysql_num_rows($query);
	if ($count == 1) {
		return mysql_fetch_array($query);
	} else {
		return false;	
	}
}

function allowed_prices($level){
	if ($level == 'No Level') return array(3,5,10);
	if ($level == 'Level 1') return array(3,5,10,15,20);
	if ($level == 'Level 2') return array(3,5,10,15,20,30,40,50);
	if ($level == 'Level 3') return array(3,5,10,15,20,30,40,50,60,70,80,90,100);
}

function get_order_info($by_val,$by_id = false) {
	if ($by_id == true) {
		$query = mysql_query("SELECT * FROM `orders` WHERE `id` = " . $by_val);
	} else {
		$query = mysql_query("SELECT * FROM `orders` WHERE `number` = '".$by_val."'");
	}
	$count = mysql_num_rows($query);
	if ($count == 1) {
		return mysql_fetch_array($query);
	} else {
		return false;	
	}
}

function get_category_info($val,$by_slug=false) {
	if ($by_slug == true) {
		$query = "SELECT * FROM `categories` WHERE `slug` = '".mres($val)."'";
	} else {
		$query = "SELECT * FROM `categories` WHERE `id` = '".$val."'";
	}
	$result = mysql_query($query);
	$count = mysql_num_rows($result);
	if ($count == 1) {
		return mysql_fetch_array($result);
	} else {
		return false;	
	}
}

function get_forum_category_info($val,$by_slug=false) {
	if ($by_slug == true) {
		$query = "SELECT * FROM `forum_categories` WHERE `slug` = '".mres($val)."'";
	} else {
		$query = "SELECT * FROM `forum_categories` WHERE `id` = '".$val."'";
	}
	$result = mysql_query($query);
	$count = mysql_num_rows($result);
	if ($count == 1) {
		return mysql_fetch_array($result);
	} else {
		return false;	
	}
}

function check_due($datetime){
	if (time() < strtotime($datetime)){
		return false;
	} else {
		return true;	
	}
}

function get_due($datetime){
	$today = new DateTime(date('Y-m-d H:i:s'));
	$date = $today->diff(new DateTime($datetime));
	return array('days' => $date->d,'hours' => $date->h,'minutes' => $date->m,'seconds' => $date->s);
}

function get_seller_earning_amount($price) {
	$amount = 0;
	if ($price == 3) {
		$amount = 2;	
	} else {
		$fee_amount = $price / 5;	
		$amount = $price - $fee_amount;
	}
	return $amount;
}

function update_rating($id,$for='service'){
	if ($for == 'service') {
		$rating = get_rating($id,'service');
		$query = "UPDATE `services` SET `rating` = '".$rating."' WHERE `id` = " . $id;
	} else {
		$rating = get_rating($id,'user');
		$query = "UPDATE `users` SET `rating` = '".$rating."' WHERE `id` = " . $id;
	}
	$result = mysql_query($query);
}

function remove_reviews($order_number){
	
	$order = get_order_info($order_number);
	$buyer = get_user_info($order['buyer_id']);
	$seller = get_user_info($order['seller_id']);
	$service = get_service_info($order['service_id']);
	
	remove_review($order['id'],$service['id'],$buyer['id'],$seller['id']);
	remove_review($order['id'],$service['id'],$seller['id'],$buyer['id']);
	
	$update = mysql_query("UPDATE `orders` SET `buyer_rated` = 0, `seller_rated` = 0 WHERE `id` = " . $order['id']);
	if (!$update) echo 'Error: ' . mysql_error();
}

function remove_review($order_id,$service_id,$user_id,$for_user_id){
	
	$remove = mysql_query("DELETE FROM `ratings` WHERE `order_id` = ".$order_id." AND `service_id` = ".$service_id." AND `user_id` = ".$user_id." AND `for_user_id` = ".$for_user_id);
	if (!$remove) echo'Error: ' . mysql_error();
	
	update_rating($service_id,'service');
	update_rating($for_user_id,'user');
	update_rating($user_id,'user');
	
}

function count_reviews($id,$up_or_down,$for = 'service',$exclude_id=false){
		if ($for == 'service') {
			$query = "SELECT `rating` FROM `ratings` WHERE `service_id` = '".intval($id)."' AND `user_id` != '". $exclude_id ."' AND `rating` = '".$up_or_down."' ";
		} else {
			$query = "SELECT `rating` FROM `ratings` WHERE `for_user_id` = ".intval($id)." AND `rating` = '".$up_or_down."' ";
		}
		$result = mysql_query($query);
		echo mysql_error();
		return mysql_num_rows($result);
}

function refund_buyer($order_id){
	$order = get_order_info($order_id,true);
	$check = mysql_query("SELECT * FROM `earnings` WHERE `status` = 'Pending' AND `order_id` = " . $order['id']);
	$check_count = mysql_num_rows($check);	
	
	if ($check_count == 1) {
		
		$row = mysql_fetch_array($check);
		$update_earnings = mysql_query("UPDATE `earnings` SET `status` = 'Cancelled' WHERE `id` = " . $row['id']);
		$update_user = mysql_query("UPDATE `users` SET `purchase_balance` = `purchase_balance` + '".$row['amount']."' WHERE `id` = " . $order['buyer_id']);
		$update_rating = mysql_query("DELETE FROM `ratings` WHERE `order_id` = " . $order['id']);
		$update_service = mysql_query("UPDATE `services` SET `reviews` = `reviews` - 1, `sales` = `sales` - 1 WHERE `id` = " . $order['service_id']);
		update_rating($order['service_id'],'service');
		update_rating($order['seller_id'],'user');
		
	}
}

function get_rating($id,$for='service'){

	if ($for == 'user') {
		$ups = count_reviews($id,'up','user');
		$downs = count_reviews($id,'down','user');
	} else {
		$service = get_service_info($id);
		$ups = count_reviews($id,'up','service',$service['user_id']);
		$downs = count_reviews($id,'down','service',$service['user_id']);
	}
	$devide_by = ($ups + $downs) * 100;
	if ($devide_by == 0) {
		return 0;
	} else {
		$ratio = $ups / $devide_by;
		return round($ratio);
	}
}

function pay_seller($order_id,$auto = false){
	$this_order = get_order_info($order_id,true);
	$this_buyer = get_user_info($this_order['buyer_id']);
	$this_seler = get_user_info($this_order['seller_id']);
	
	$due_datetime = date('Y-m-d H:i:s', strtotime(' +10 days'));
	$amount = get_seller_earning_amount($this_order['price']);
	
	$pay_seller = mysql_query("INSERT INTO `earnings` (
		`user_id`,
		`order_id`,
		`amount`,
		`status`,
		`due_datetime`,
		`datetime`
	) VALUES (
		'".$this_seler['id']."',
		'".$this_order['id']."',
		'".$amount."',
		'Pending',
		'".$due_datetime."',
		'".date('Y-m-d H:i:s')."'
		)");
	confirm_query($pay_seller,true);
	
	$update_user = mysql_query("UPDATE `users` SET `sales` = `sales` + 1 WHERE `id` = " . $this_seler['id']);
	
	$noti_desc = $this_buyer['username']. '! just marked your order as completed.';
	if ($auto) $noti_desc = 'Order '.$this_order['number'].' is automatically marked as completed.';
	$noti_url = '/order/'.$this_order['number'].'/';
	add_noti($noti_desc,$this_seler['id'],$noti_url);
	
}

function complete_order($id,$auto = true){
	$this_order = get_order_info($id,true);
	$this_service = get_service_info($this_order['service_id']);
	mysql_query("UPDATE `orders` SET `status` = 'Completed', `completed_datetime` = '".date('Y-m-d H:i:s')."' WHERE `id` = " . $id);
	mysql_query("UPDATE `services` SET `sales` = `sales` + 1 WHERE `id` = " . $this_service['id']);
	pay_seller($this_order['id'],$auto);
}

function get_due_completion_datetime($dellivered_datetime,$days = 3){
	return date('Y-m-d H:i:s', strtotime("+".$days." day", strtotime($dellivered_datetime)));
}

function service_permalink($id) {
	global $set;
	$service = get_service_info($id);
	return $set['home'] . '/service/'.make_slug($service['title']).'/'.$service['id'].'/';
}

function user_permalink($id) {
	global $set;
	$this_user = get_user_info($id);
	return $set['home'] . '/user/'.$this_user['username'].'/';
}

function category($term,$get = 'name', $by_slug = false){
	$search = 'id';
	if ($by_slug) $search = 'slug';
	$query = mysql_query("SELECT * FROM `categories` WHERE `".$search."` = '".$term."'");
	if (mysql_num_rows($query) != 0) {
		$row = mysql_fetch_array($query);
		switch ($get) {
			case 'name':
				return $row['name'];
				break;
			case 'slug':
				return $row['slug'];
				break;
			case 'id':
				return $row['id'];
				break;
		}
	} else {
		return false;	
	}
}

function category_url($id){
	global $set;
	$query = mysql_query("SELECT * FROM `categories` WHERE `id` = '".$id."'");
	if (mysql_num_rows($query) != 0) {
		$row = mysql_fetch_array($query);
		if ($row['parent'] != 0) {
			$parent = get_category_info($row['parent']);
			$url = $set['home'] . '/category/'.$parent['slug'].'/' . $row['slug'].'/';	
		} else {
			$url = $set['home'] . '/category/' . $row['slug'].'/';		
		}
		return $url;
	} else {
		return false;	
	}
}

function the_category($var){ 
	$output = '<a href="'. category_url($var['cat_id']) .'">'.category($var['cat_id']) . '</a>';
	if ($var['sub_cat_id']!=0) {
	$output .= ' / <a href="'.category_url($var['sub_cat_id']).'">'.category($var['sub_cat_id']).'</a>';
	}
	echo $output;
};

function img($url,$width=false,$height=false){
	global $set;
	$width ?  $add_width = "&amp;w=".$width : $add_width = '';
	$height ? $add_height = "&amp;h=".$height : $add_height = '';
	return $set['home'] . '/img.php?src='.$url.$add_width.$add_height;
}

function count_orders($status='all',$seller_or_buyer,$user_id) { 
	$add_status = '';
	if ($status != 'all') $add_status = " AND `status` = '".$status."'";	
	$query = mysql_query("SELECT `id` FROM `orders` WHERE `".$seller_or_buyer."` = '".$user_id."' ".$add_status);
	return mysql_num_rows($query);
}

function count_all_services($column,$value,$all=false) {
	if ($all){
		$add_status = '';
	} else {
		$add_status = " WHERE `".$column."` = '".$value."' ";
	}
	$query = mysql_query("SELECT `id` FROM `services` ".$add_status);
	return mysql_num_rows($query);
}

function count_all_orders($column,$value,$all=false) {
	if ($all){
		$add_status = '';
	} else {
		$add_status = " WHERE `".$column."` = '".$value."' ";
	}
	$query = mysql_query("SELECT `id` FROM `orders` ".$add_status);
	return mysql_num_rows($query);
}

function count_all_approved_services($column,$value,$all=false) {
	if ($all){
		$add_status = " WHERE `status` = 'Active'";
	} else {
		$add_status = " WHERE `".$column."` = '".$value."' AND `status` = 'Active'";
	}
	$query = mysql_query("SELECT `id` FROM `services` ".$add_status);
	return mysql_num_rows($query);
}

function count_shopping($user_id,$term,$value){
	$query = mysql_query("SELECT `id` FROM `orders` WHERE `buyer_id` = '".$user_id."' AND `".mres($term)."` = '".mres($value)."' ");
	return mysql_num_rows($query);
}

function mres($var){
	if (get_magic_quotes_gpc()){
		$var = stripslashes(trim($var));
	}
	return mysql_real_escape_string(trim($var));
}

function confirm_query($query, $print = 0){
	global $error;
	if (!$query) {
		if ($print == 1) {
			echo "Error performing MYSQL Query <br>" . mysql_error();
			die();
		} else {
		  $error[] = "Error performing MYSQL Query <br>" . mysql_error();
		  return FALSE;
		}
	} else {
	  return true;
	}
}

function delete_service($id) {
	$this_service = get_service_info($id);
	if ($this_service) {
		
		$image_location = 'uploads/service-imgs/';
		if (file_exists($image_location.$this_service['image']) && !empty($this_service['image'])){
			unlink($image_location.$this_service['image']) or die('Error Deleting image');
		}
	
	$delete = mysql_query("DELETE FROM `services` WHERE `id` = " . $this_service['id']);
	if ($delete)
		return true;
	else
		return false;
	}	
}

function delete_message($id) {
	$this_message = get_message_info($id);
	if (isset($this_message['id'])) {
		
		$get_attachments = mysql_query("SELECT * FROM `files` WHERE `msg_id` = " . $this_message['id']);
		while ($file_row = mysql_fetch_array($get_attachments)) {
			$files_location = '../uploads/attachments/';
			if (file_exists($files_location.$file_row['name']) && !empty($file_row['name'])){
				unlink($files_location.$file_row['name']) or die('Error Deleting File:' . $file_row['name']);
			}
			
			$delete_file = mysql_query("DELETE FROM `files` WHERE `id` = " . $file_row['id']);
			
		}
	
	$delete = mysql_query("DELETE FROM `messages` WHERE `id` = " . $this_message['id']);
	if (!$delete) die('error deleting message' . mysql_error());
	if ($delete)
		return true;
	else
		return false;
	}	
}

function delete_messages($rel_id,$by_column = 'order_id') {
	$get_messages = mysql_query("SELECT * FROM `messages` WHERE `".$by_column."` = " . intval($rel_id));	
	if (!$get_messages) echo 'Error:' . mysql_error();
	if (mysql_num_rows($get_messages) > 0) {
		while($message_row = mysql_fetch_array($get_messages)){
			delete_message($message_row['id']);
		}
	}
}

function service_box($var){
	global $set;
	$this_user = get_user_info($var['user_id']);
?>
<div class="service_box box" id="service-<?php echo $var['id']; ?>">
    <a href="<?php echo service_permalink($var['id']); ?>">
        <img src="<?php echo img($set['home'].'/uploads/service-imgs/'.$var['image'],203,131); ?>" class="preview" alt="<?php echo $var['title']; ?>">
        <span><?php echo $var['title']; ?></span>
    </a>
    <div class="clear"></div>
    <div class="seller">
        <div class="left">
        	<div class="thumb">
            <a href="<?php echo user_permalink($this_user['id']); ?>"><?php the_avatar($this_user['id'],30,'thumb'); ?></a>
            </div>
        	<div class="name">
            	<a href="<?php echo user_permalink($this_user['id']); ?>"><?php echo $this_user['username']; ?></a> <?php the_flag($this_user['last_ip']); ?>
                
                <div class="rating">
                <div class="sales"><strong><?php echo $var['sales']; ?></strong> Sales</div>
                <?php if ($var['reviews'] != 0) { ?>
                <strong><?php echo $var['rating']; ?>%</strong> Rating (<?php echo $var['reviews']; ?>)
                <?php } else { ?>
                New Service
                <?php } ?>
                <div class="clear"></div>
                </div>
            </div><!-- .name -->
         <div class="clear"></div>
        </div>
        
        <div class="clear"></div>
    </div><!-- .seller -->
    <div class="price">
    	<a href="<?php echo service_permalink($var['id']); ?>">$<?php echo $var['price']; ?></a>
    </div>
</div><!-- .service_box -->	
<?php }

function display_message($new_msg = NULL){
	global $message;
	if (isset($message)) {
		echo "<div class='display_message'>{$message}</div>";
	} elseif($new_msg != NULL) {
		echo "<div class='display_message'>{$new_msg}</div>";
	}
}

function display_notice($new_notice = NULL){
	global $notice;
	if ($new_notice != NULL) {
		echo "<div class='display_notice'>{$new_notice}</div>";
	} elseif( isset($notice)) {
		echo "<div class='display_notice'>{$notice}</div>";
	}
}

function display_error($new_error = NULL){
	global $error;
	$br = '<br>';
	if (count($error) == 1) $br = '';
	if($new_error != NULL) {
		echo "<div class='display_error'>{$new_error}</div>";
	} elseif (!empty($error)){ 
		echo "<div class='display_error'>";
		if (is_array($error)) {
			foreach($error as $er):
				echo $er . $br;
			endforeach;
		} else {
			echo $error;	
		}
		echo "</div>";
	}
}

function redirect($locaiont, $delay = 0){
	echo "<meta http-equiv=\"REFRESH\" content=\"{$delay}; url={$locaiont}\">";
	exit;
}

function is_loggedin(){
	if (isset($_SESSION['user_login']) || isset($_COOKIE['user_login'])) return true; else return false; 
}

function get_loggedin_info($admin = NULL){
	if ($admin == NULL) {
		if (isset($_SESSION['user_login']) || isset($_COOKIE['user_login'])){
			
			if (isset($_COOKIE['user_login'])) {
				$check_username = $_COOKIE['user_login'];
			} else {
				$check_username = $_SESSION['user_login'];
			}
			
			$query = "SELECT * FROM `users` WHERE `username` = '".mres($check_username)."'";
			$result = mysql_query($query);
			if (mysql_num_rows($result) == 0) {
				global $set;
				redirect($set['home']. '/logout.php');
			}
			confirm_query($result);
			$rows = mysql_fetch_array($result);
			return $rows;
		}
	} else {
		if (isset($_SESSION['admin_login'])){
			$query = "SELECT * FROM `users` WHERE `username` = '".mres($_SESSION['admin_login'])."'";
			$result = mysql_query($query);
			confirm_query($result);
			$rows = mysql_fetch_array($result);
			return $rows;
		}
	}
}

function get_user_info($by_var, $by_username = FALSE){
	if ($by_username == FALSE) {
		$query = "SELECT * FROM `users` WHERE `id` = '".intval($by_var)."'";
	} else {
		$query = "SELECT * FROM `users` WHERE `username` = '".mres($by_var)."'";
	}
		$result = mysql_query($query);
		$rows = mysql_fetch_array($result);
		return $rows;
}

function count_noti($user_id){
	$result = mysql_query('SELECT * FROM `notifications` WHERE `user_id` = '.intval($user_id).' AND `viewed` = 0');
	return mysql_num_rows($result);
}

function data_image($file_path,$type='jpg'){
	global $set;
	echo "data:image/".$type.";base64,".base64_encode(file_get_contents_curl($set['home'].'/'.$file_path));
}

function forum_mod($user_id = NULL){
	if (is_loggedin()){
		global $user;
		if ($user_id == NULL){
			if ($user['forum_mod'] == 1 || $user['role'] == 'admin' ) {
				return true;
			} else {
				return false;	
			}
		} else {
			if ($user['id'] == $user_id || $user['forum_mod'] == 1 || $user['role'] == 'admin' ) {
				return true;
			} else {
				return false;	
			}
		}
	} else {
		return false;
	}
}

function check_login($location = NULL){
		if (!isset($_SESSION['user_login']) && !isset($_COOKIE['user_login'])){
			if (isset($_SERVER['REQUEST_URI'])) {
				$_SESSION['login_redirect'] = $_SERVER['REQUEST_URI'];
			global $set;
			    redirect($set['home']. '/sign-in/');
			} else {
				redirect($location);	
			}
			exit;
		}
}

function the_flag($ip,$admin = NULL) {
	global $set;
	if ($ip != 'null') {
 	$obj = json_decode(ip_json($ip));
	if ($obj != ''){
		if ($obj->geoplugin_countryName != 'null') {
			if ($admin != NULL) {
			$flag = '../img/flags/'. strtolower($obj->geoplugin_countryCode) . '.png';
			} else {
			$flag = 'img/flags/'. strtolower($obj->geoplugin_countryCode) . '.png';	
			}
			
			$add_flag = $set['home'] . '/img/flags/'. strtolower($obj->geoplugin_countryCode) . '.png';
			
			if (file_exists($flag)) { ?>
			<img src="<?php echo $add_flag; ?>" title="<?php echo $obj->geoplugin_countryName; ?>" alt="<?php echo $obj->geoplugin_countryName; ?>" /> 
		    <?php } else { ?>
            <!-- http://api.hostip.info/flag.php?ip=iphere -->
            <img src="http://cdn.whatismyipaddress.com/images/flags/<?php echo strtolower($obj->geoplugin_countryCode); ?>.png" width="16" title="<?php echo $obj->geoplugin_countryName; ?>" alt="<?php echo $obj->geoplugin_countryName; ?>" />	<?php
			}
		}
	  }
	}
}

function check_days($date, $days){
	$today = date('d-m-Y');
	$count_days = round(abs(strtotime($today)-strtotime($date))/86400);
	$total_count = $days - $count_days;
	return $total_count;
}

function check_date($date){
	$total_count = round(abs(strtotime(date('Y-m-d h:i:s A'))-strtotime($date))/86400);
	return $total_count;
}

function add_noti($desc,$user_id,$url='', $subject = 'Email Alert!',$no_email = false){
	global $set;
	$add_noti = mysql_query("INSERT INTO `notifications` (`description`, `user_id`,`url`, `datetime`) VALUES ('".$desc."', '".$user_id."','".$url."', '".date("Y-m-d H:i:s")."')");	
	confirm_query($add_noti, 1);

	if ($no_email == false){
	$message = '<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;color:#66aa1e;font-weight:normal;font-size:19px;padding:15px 0px 0px 0px;line-height:24px;" class="ecxannouncement">';
	
	if ($url != '') {
		$add_url = $set['home'].$url;
	} else {
		$add_url = $set['home'].'/account/';
	}
		
	$message .='<a href="'.$add_url.'" target="_blank" style="color:#66aa1e;">'.$desc.'</a></p>';
	send_email($user_id, $subject, $message);
	}
}

function send_email($user_id,$subject,$message,$regards='Thanks'){
	global $set;
	$this_user = get_user_info($user_id); 
	$to = $this_user['email'];
	
	if ($this_user['first_name'] == '' && $this_user['last_name'] == '') {
	  $dear = $this_user['username'];
	} else {
	  $dear = $this_user['first_name'] . ' ' . $this_user['last_name'];
	}
	
	$headers = "From: LancerDesk <no-reply@lancerdesk.com> \r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	
	$final_message = '<style>
.ExternalClass{font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;color:#545454;padding:0;}
.ExternalClass h1{color:#66aa1e;font-weight:400;font-size:24px;padding:10px 0 0;}
.ExternalClass h2{color:#f79422;font-size:19px;padding:10px 0 0;}
.ExternalClass p.ecxannouncement{color:#7ebd41;font-weight:400;font-size:19px;line-height:24px;padding:0;}
.ExternalClass p{font-size:13px;line-height:21px;}
.ExternalClass a{color:#1b90ea;}
.ExternalClass .ecxbutton{display:block;text-align:center;padding:15px 0;}
.ExternalClass .ecxnotice{font-size:12px;color:#9f9f9f;}
.ExternalClass .ecxthanks{font-size:17px;color:#66aa1e;}
.ExternalClass .ecxteam{color:#66aa1e;font-size:15px;}
.ExternalClass .ecxsocial{color:#36C;font-size:15px;}
.ExternalClass .ecxfooter-title{font-size:13px;font-weight:700;}
.ExternalClass .ecxfooter-info{font-size:12px;color:#545454;padding:10px 0 0;}
.ExternalClass .ecxemail-id{font-size:11px;color:#66aa1e;}
</style>

<table width="100%" height="100%" cellspacing="0" cellpadding="10" style="background:#F9F9F6 url('.$set['home'].'/img/email/body_bg.png); background-color:#F9F9F6;">
<tbody><tr>
<td valign="top" align="center"> 
<table width="580px" cellspacing="0" class="ExternalClass" cellpadding="0" border="0" align="center" style="background:#fff; padding:15px 15px 5px; border-bottom:2px solid #25a7a8; box-shadow:0 0 10px rgba(0,0,0,0.05) ">
  <tbody><tr class="header">
  	<td  align="left" style="background:#25a7a8; background:#25a7a8 url('.$set['home'].'/img/header_bg.png); padding:17px 0 10px; border-radius:3px 0 0 3px;"><a href="'.$set['home'].'" target="_blank"><img src="'.$set['home'].'/img/email/lancerdedk-logo.png" alt="'.$set['name'].'"></a></td>
	<td valign="bottom" style="background:#25a7a8;  background:#25a7a8 url('.$set['home'].'/img/header_bg.png); padding:17px 20px 10px; border-radius:0 3px 3px 0;" align="right">
    <span style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:12px;color:#ccefef; display:inline-block;" class="ecxnotice">This is an automated email, please do not reply</span></td>    
  </tr>
  <tr>
    <td colspan="2">
<h1 style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;color:#25a7a8;font-weight:normal;font-size:24px;padding:15px 0px 0px 0px;">Dear '.$dear.',</h1>

'.$message.'

    </td>
  </tr>
  <tr>
    <td colspan="2">

<div style="padding:5px 0 0;">
    <span style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;color:#25a7a8;font-size:12px;" class="ecxsocial">Follow Us </span><a target="_blank" href="#" style="text-decoration:none;"> <img width="16" border="0" height="16" alt="on Facebook" src="'.$set['home'].'/img/email/facebook.png"> </a><a target="_blank" href="#" style="text-decoration:none;"><img width="16" border="0" height="16" alt="on Twitter" src="'.$set['home'].'/img/email/twitter.png"></a>
</div>    
    
<div style="padding:10px 0 0;">
<span style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:17px;color:#25a7a8;" class="ecxthanks">'.$regards.', </span> <br>
<span style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;color:#25a7a8;font-size:16px;" class="ecxteam">'.$set['name'].' Team</span>
</div>    
</td>
  </tr>
  <tr class="ecxhorizontal-bar">
  	<td valign="bottom" height="14" colspan="2">
    <img width="100%" height="3" src="'.$set['home'].'/img/email/bar.png">
    </td>
  </tr>
  <tr>
  	<td colspan="2">
    <p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:12px;color:#545454;padding:10px 0px 0px 0px;" class="ecxfooter-info"><span style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;font-weight:bold;" class="ecxfooter-title">Need Assistance?</span><br>
    We\'re happy to help  <a target="_blank" style="color:#25a7a8;" href="'.$set['home'].'/support/">by email</a><br>
    Copyright '.date('Y').' '.$set['name'].'. All rights reserved.</p>
    </td>
  </tr>
</tbody></table>
</td>
</tr>
</tbody></table>';
	
	require_once 'phpmailer/PHPMailerAutoload.php';
	$mail = new PHPMailer();
	$mail->isSMTP();
	$mail->Host = 'gator4160.hostgator.com';
	$mail->Port = 465;
	$mail->SMTPAuth = true;
	$mail->Username = 'no-reply@lancerdesk.com'; 
	$mail->Password = 'm{7_Ha4M}%X($}Q^vc';
	$mail->SMTPSecure = 'ssl';  
	$mail->setFrom('no-reply@lancerdesk.com', 'LancerDesk');
	
	$mail->addAddress($this_user['email'], $this_user['username']);
	$mail->Subject = $subject;
	$mail->msgHTML($final_message);
	
	if (!$mail->send()) {
	    echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
	   return true;
	}

}

function email_verify_code($username) {
	$code = strtoupper(substr(md5(date('ymdhis').$username), 0, 12));
	
	$rand_check = mysql_query("SELECT `id` FROM `users` WHERE `email_verify_code` = '".$code."' ");
	
	if (mysql_num_rows($rand_check) == 1) {
		do {
      		$code = strtoupper(substr(md5(date('ymdhis').$username), 0, 12));
		} while(mysql_num_rows($rand_check) != 1);
	}
	
return $code;
}

function gen_order_number() {
	$code = strtoupper(substr(md5(date('ymdhis')), 0, 11));
	$rand_check = mysql_query("SELECT * FROM `orders` WHERE `number` = '".$code."' ");
	if (mysql_num_rows($rand_check) == 1) {
		do {
      		$code = strtoupper(substr(md5(date('ymdhis')), 0, 12));
		} while(mysql_num_rows($rand_check) != 1);
	}
return 'E'.$code;
}

function gen_file_code() {
	$code = strtoupper(substr(md5(date('ymdhis')), 0, 10));
	$rand_check = mysql_query("SELECT * FROM `files` WHERE `code` = '".$code."' ");
	if (mysql_num_rows($rand_check) == 1) {
		do {
      		$code = strtoupper(substr(md5(date('ymdhis')), 0, 10));
		} while(mysql_num_rows($rand_check) != 1);
	}
return 'E'.$code;
}

function pass_verify_code($username) {
	$code = strtoupper(md5(date('ymdhis').$username));
	
	$rand_check = mysql_query("SELECT * FROM `users` WHERE `password_verify_code` = '".$code."' ");
	if (mysql_num_rows($rand_check) == 1) {
		do {
      		$code = strtoupper(md5(date('ymdhis').$username));
		} while(mysql_num_rows($rand_check) != 1);
	}
return $code;
}

function send_email_verification($user_id,$code = false,$subject = 'Please verify your email address'){ 
global $set;
$this_user = get_user_info($user_id); 

if ($code == false) {
	$email_verify_code = $this_user['email_verify_code'];
} else {
	$email_verify_code = $code;
}

$email_verify_message = '<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">Please click on the following link to verify your email address:</p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;"><b><a target="_blank" href="'.$set['home'].'/?verify='.$email_verify_code.'" style="color:#1b90ea;">Click here to verify your email address.</a></b></p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">If you cannot click on the link in this email, simply copy and paste it into the address bar of your web browser. </p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">'.$set['home'].'/?verify='.$email_verify_code.'</p>';

send_email($user_id,$subject,$email_verify_message);

}

function send_password_request($user_id,$code = false,$subject = 'LancerDesk: Reset Password Request'){ 
global $set;

$this_user = get_user_info($user_id); 

$code = pass_verify_code($this_user['username']);
$update = mysql_query("UPDATE `users` SET `password_verify_code` = '".$code."' WHERE `id` = " . $user_id);

$key = strtoupper(md5($this_user['username'].$this_user['member_id'].$this_user['email']));

$recover_url = $set['home'].'/recover-password/?key='.$key.'&code='.$code;

$pass_verify_message = '<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">Please click on the following link to reset your password:</p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;"><b><a target="_blank" href="'.$recover_url.'" style="color:#1b90ea;">Click here to reset your password.</a></b></p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">If you cannot click on the link in this email, simply copy and paste it into the address bar of your web browser. </p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">'.$recover_url.'</p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">Your Username is: <strong> '.$this_user['username'].' </strong> </p>
<p style="font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif;font-size:13px;line-height:21px;color:#545454;">If you didn\'t send this request then you can ignore this email or contact our <a href="'.$set['home'] . '/support/">support</a> for any issue.</p>
';

send_email($user_id,$subject,$pass_verify_message);

}

function get_topic_link($id){
	global $set;
	$result = mysql_query("SELECT * FROM `forum_topics` WHERE `id` = ".$id);
	$row = mysql_fetch_array($result);
	$link = $set['home'] . "/topic-" . $id . "/" .make_slug($row['title']);
	return $link;
}

function limit_words($string, $word_limit){
	  $words = explode(' ', $string, ($word_limit + 1));
	  if(count($words) > $word_limit)
	  array_pop($words);
	  return implode(' ', $words);
}

function file_get_contents_curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

function ip_json($ip=NULL){
	if ($ip==NULL){
		$use_ip = $_SERVER['REMOTE_ADDR'];
	} else {
		$use_ip	= $ip;
	}
	//return file_get_contents("http://api.hostip.info/get_json.php?ip=".($use_ip)."&position=true");
	//return file_get_contents_curl("http://api.hostip.info/get_json.php?ip=".$use_ip."&position=true");
	return file_get_contents_curl("http://www.geoplugin.net/json.gp?ip=".$use_ip);
}

function get_gravatar( $email, $s = 80, $d = 'mm', $r = 'g', $img = false, $atts = array() ) {
    $url = 'https://www.gravatar.com/avatar/';
    $url .= md5( strtolower( trim( $email ) ) );
    $url .= "?s=$s&amp;d=$d&amp;r=$r";
    if ( $img ) {
        $url = '<img src="' . $url . '"';
        foreach ( $atts as $key => $val )
            $url .= ' ' . $key . '="' . $val . '"';
        $url .= ' />';
    }
    return $url;
}

function the_avatar($user_id, $size = 80, $class = false) {
	global $set;
	$now_user = get_user_info($user_id);
	($class != false) ? $avatar_class = $class : $avatar_class = "thumb";
if ( $now_user['avatar'] != '') { ?>

   <img src="<?php echo img($set['home']. '/uploads/avatars/'. $now_user['avatar'],$size); ?>" class="<?php echo $avatar_class; ?>" alt="<?php echo $now_user['username']; ?>">
<?php } else { ?>
   <img src="<?php echo get_gravatar($now_user['email'],$size); ?>" class="<?php echo $avatar_class; ?>" alt="<?php echo $now_user['username']; ?>" />
<?php }
}

function pagination($query, $per_page = 10,$page = 1, $url = '?', $pretty = 0){        
    	$query = "SELECT COUNT(*) as `num` FROM {$query}";
    	$row = mysql_fetch_array(mysql_query($query));
    	$total = $row['num'];
        $adjacents = "2"; 
  		
		if ($pretty == 0) {
		$page_var = "page=";
		$after_url = "";
		} else {
		$page_var = "page/";
		$after_url = "/";
		}
		
    	$page = ($page == 0 ? 1 : $page);  
    	$start = ($page - 1) * $per_page;								
		
    	$prev = $page - 1;							
    	$next = $page + 1;
		
        $lastpage = ceil($total/$per_page);
		
    	$lpm1 = $lastpage - 1;
    	
    	$pagination = "";
    	if($lastpage > 1)
    	{	
			$pagination.= "<div class='box pagination_wrap'>";
			$pagination .= "<span class='details'>Page $page of $lastpage</span>";
    		$pagination .= "<ul class='pagination'>";
            	
				if ($page > 1) {
					$pagination.= "<li><a href='{$url}{$page_var}$prev{$after_url}'>Previous</a></li>";
				}
				
    		if ($lastpage < 7 + ($adjacents * 2))
    		{	
    			for ($counter = 1; $counter <= $lastpage; $counter++)
    			{
    				if ($counter == $page)
    					$pagination.= "<li><a class='current'>$counter</a></li>";
    				else
    					$pagination.= "<li><a href='{$url}{$page_var}$counter{$after_url}'>$counter</a></li>";					
    			}
    		}
    		elseif($lastpage > 5 + ($adjacents * 2))
    		{
    			if($page < 1 + ($adjacents * 2))		
    			{
    				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}{$page_var}$counter{$after_url}'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>...</li>";
    				$pagination.= "<li><a href='{$url}{$page_var}$lpm{$after_url}1'>$lpm1</a></li>";
    				$pagination.= "<li><a href='{$url}{$page_var}$lastpag{$after_url}e'>$lastpage</a></li>";		
    			}
    			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
    			{
    				$pagination.= "<li><a href='{$url}{$page_var}1{$after_url}'>1</a></li>";
    				$pagination.= "<li><a href='{$url}{$page_var}2{$after_url}'>2</a></li>";
    				$pagination.= "<li class='dot'>...</li>";
    				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}{$page_var}$counter{$after_url}'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>..</li>";
    				$pagination.= "<li><a href='{$url}{$page_var}$lpm1{$after_url}'>$lpm1</a></li>";
    				$pagination.= "<li><a href='{$url}{$page_var}$lastpage{$after_url}'>$lastpage</a></li>";		
    			}
    			else
    			{
    				$pagination.= "<li><a href='{$url}{$page_var}1{$after_url}'>1</a></li>";
    				$pagination.= "<li><a href='{$url}{$page_var}2{$after_url}'>2</a></li>";
    				$pagination.= "<li class='dot'>..</li>";
    				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}{$page_var}$counter{$after_url}'>$counter</a></li>";					
    				}
    			}
    		}
    		
    		if ($page < $counter - 1){ 
    			$pagination.= "<li><a href='{$url}{$page_var}$next{$after_url}'>Next</a></li>";
                $pagination.= "<li><a href='{$url}{$page_var}$lastpage{$after_url}'>Last</a></li>";
    		}else{
    			//$pagination.= "<li><a class='current'>Next</a></li>";
               // $pagination.= "<li><a class='current'>Last</a></li>";
            }
    		$pagination.= "</ul>\n</div>\n";		
    	}
    
    
        return $pagination;
    }

function reviews_pagination($query, $per_page = 10,$page = 1, $type='all'){        
    	$query = "SELECT COUNT(*) as `num` FROM {$query}";
    	$row = mysql_fetch_array(mysql_query($query));
    	$total = $row['num'];
        $adjacents = "2"; 

		$page_var = "page/";
		$after_url = "/";
		
    	$page = ($page == 0 ? 1 : $page);  
    	$start = ($page - 1) * $per_page;								
		
    	$prev = $page - 1;							
    	$next = $page + 1;
		
        $lastpage = ceil($total/$per_page);
		
    	$lpm1 = $lastpage - 1;
    	
    	$pagination = "";
    	if($lastpage > 1)
    	{	
			$pagination.= "<div class='box pagination_wrap'>";
			$pagination .= "<span class='details'>Page $page of $lastpage</span>";
    		$pagination .= "<ul class='pagination reviews_pagination'>";
            	
				if ($page > 1) {
					$pagination.= "<li><a class='trigger' data-type='$type' data-page='$prev'>Previous</a></li>";
				}
				
    		if ($lastpage < 7 + ($adjacents * 2))
    		{	
    			for ($counter = 1; $counter <= $lastpage; $counter++)
    			{
    				if ($counter == $page)
    					$pagination.= "<li><a class='current'>$counter</a></li>";
    				else
    					$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$counter'>$counter</a></li>";					
    			}
    		}
    		elseif($lastpage > 5 + ($adjacents * 2))
    		{
    			if($page < 1 + ($adjacents * 2))		
    			{
    				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$counter'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>...</li>";
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$lpm'>$lpm1</a></li>";
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$lastpage'>$lastpage</a></li>";		
    			}
    			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
    			{
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='1'>1</a></li>";
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='2'>2</a></li>";
    				$pagination.= "<li class='dot'>...</li>";
    				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$counter'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>..</li>";
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$lpm1'>$lpm1</a></li>";
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$lastpage'>$lastpage</a></li>";		
    			}
    			else
    			{
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='1'>1</a></li>";
    				$pagination.= "<li><a class='trigger' data-type='$type'  data-page='2'>2</a></li>";
    				$pagination.= "<li class='dot'>..</li>";
    				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$counter'>$counter</a></li>";					
    				}
    			}
    		}
    		
    		if ($page < $counter - 1){ 
    			$pagination.= "<li><a class='trigger' data-type='$type'  data-page='$next'>Next</a></li>";
                $pagination.= "<li><a class='trigger' data-type='$type'  data-page='$lastpage'>Last</a></li>";
    		}else{
    			//$pagination.= "<li><a class='trigger' data-type='$type'  class='current'>Next</a></li>";
               // $pagination.= "<li><a class='trigger' data-type='$type'  class='current'>Last</a></li>";
            }
    		$pagination.= "</ul>\n</div>\n";		
    	}
    
    
        return $pagination;
    }

function search_pagination($query, $per_page = 10,$page = 1, $search_query,$tag,$filter){        
    	$query = "SELECT COUNT(*) as `num` FROM {$query}";
    	$row = mysql_fetch_array(mysql_query($query));
    	$total = $row['num'];
        $adjacents = "2"; 
  		
    	$page = ($page == 0 ? 1 : $page);  
    	$start = ($page - 1) * $per_page;								
		
    	$prev = $page - 1;							
    	$next = $page + 1;
		
        $lastpage = ceil($total/$per_page);
		
    	$lpm1 = $lastpage - 1;
    	
    	$pagination = "";
    	if($lastpage > 1)
    	{	
			$pagination.= "<div class='pagination_wrap'>";
    		$pagination .= "<ul class='pagination search_pagination'>";
            	
				if ($page > 1) {
					$pagination.= "<li><a class='pagi_trigger' data-page='$prev' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>Previous</a></li>";
				}
				
    		if ($lastpage < 7 + ($adjacents * 2))
    		{	
    			for ($counter = 1; $counter <= $lastpage; $counter++)
    			{
    				if ($counter == $page)
    					$pagination.= "<li><a class='current'>$counter</a></li>";
    				else
    					$pagination.= "<li><a data-page='$counter' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>$counter</a></li>";					
    			}
    		}
    		elseif($lastpage > 5 + ($adjacents * 2))
    		{
    			if($page < 1 + ($adjacents * 2))		
    			{
    				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a data-page='$counter' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>...</li>";
    				$pagination.= "<li><a href='{$url}{$page_var}$lpm{$after_url}1'>$lpm1</a></li>";
    				$pagination.= "<li><a data-page='$lastpage' data-query='$search_query' data-tag='$tag' data-filter='$filter' href=''>$lastpage</a></li>";		
    			}
    			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
    			{
    				$pagination.= "<li><a href='{$url}{$page_var}1{$after_url}'>1</a></li>";
    				$pagination.= "<li><a href='{$url}{$page_var}2{$after_url}'>2</a></li>";
    				$pagination.= "<li class='dot'>...</li>";
    				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}{$page_var}$counter{$after_url}'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>..</li>";
    				$pagination.= "<li><a data-page='$lpm1' data-query='$search_query' data-tag='$tag' data-filter='$filter'  href='#'>$lpm1</a></li>";
    				$pagination.= "<li><a data-page='$lastpage' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>$lastpage</a></li>";		
    			}
    			else
    			{
    				$pagination.= "<li><a data-page='1' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>1</a></li>";
    				$pagination.= "<li><a data-page='2' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>2</a></li>";
    				$pagination.= "<li class='dot'>..</li>";
    				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a data-page='$counter' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>$counter</a></li>";					
    				}
    			}
    		}
    		
    		if ($page < $counter - 1){ 
    			$pagination.= "<li><a data-page='$next' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>Next</a></li>";
                $pagination.= "<li><a data-page='$lastpage' data-query='$search_query' data-tag='$tag' data-filter='$filter' href='#'>Last</a></li>";
    		}
    		$pagination.= "</ul>\n</div>\n";		
    	}
    
    
        return $pagination;
    }

function services_pagination($query, $per_page = 10,$page = 1, $category,$subcategory,$filter){        
    	$query = "SELECT COUNT(*) as `num` FROM {$query}";
    	$row = mysql_fetch_array(mysql_query($query));
    	$total = $row['num'];
        $adjacents = "2"; 
  		
		$page_var = "page/";
		$after_url = "/";
		
		
    	$page = ($page == 0 ? 1 : $page);  
    	$start = ($page - 1) * $per_page;								
		
    	$prev = $page - 1;							
    	$next = $page + 1;
		
        $lastpage = ceil($total/$per_page);
		
    	$lpm1 = $lastpage - 1;
    	
    	$pagination = "";
    	if($lastpage > 1)
    	{	
			$pagination.= "<div class='pagination_wrap'>";
    		$pagination .= "<ul class='pagination services_pagination'>";
            	
				if ($page > 1) {
					$pagination.= "<li><a class='pagi_trigger' data-page='$prev' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>Previous</a></li>";
				}
				
    		if ($lastpage < 7 + ($adjacents * 2))
    		{	
    			for ($counter = 1; $counter <= $lastpage; $counter++)
    			{
    				if ($counter == $page)
    					$pagination.= "<li><a class='current'>$counter</a></li>";
    				else
    					$pagination.= "<li><a data-page='$counter' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>$counter</a></li>";					
    			}
    		}
    		elseif($lastpage > 5 + ($adjacents * 2))
    		{
    			if($page < 1 + ($adjacents * 2))		
    			{
    				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a data-page='$counter' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>...</li>";
    				$pagination.= "<li><a href='{$url}{$page_var}$lpm{$after_url}1'>$lpm1</a></li>";
    				$pagination.= "<li><a data-page='$lastpage' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href=''>$lastpage</a></li>";		
    			}
    			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
    			{
    				$pagination.= "<li><a href='{$url}{$page_var}1{$after_url}'>1</a></li>";
    				$pagination.= "<li><a href='{$url}{$page_var}2{$after_url}'>2</a></li>";
    				$pagination.= "<li class='dot'>...</li>";
    				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}{$page_var}$counter{$after_url}'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>..</li>";
    				$pagination.= "<li><a data-page='$lpm1' data-category='$category' data-subcategory='$subcategory' data-filter='$filter'  href='#'>$lpm1</a></li>";
    				$pagination.= "<li><a data-page='$lastpage' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>$lastpage</a></li>";		
    			}
    			else
    			{
    				$pagination.= "<li><a data-page='1' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>1</a></li>";
    				$pagination.= "<li><a data-page='2' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>2</a></li>";
    				$pagination.= "<li class='dot'>..</li>";
    				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a data-page='$counter' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>$counter</a></li>";					
    				}
    			}
    		}
    		
    		if ($page < $counter - 1){ 
    			$pagination.= "<li><a data-page='$next' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>Next</a></li>";
                $pagination.= "<li><a data-page='$lastpage' data-category='$category' data-subcategory='$subcategory' data-filter='$filter' href='#'>Last</a></li>";
    		}else{
    			//$pagination.= "<li><a class='current'>Next</a></li>";
               // $pagination.= "<li><a class='current'>Last</a></li>";
            }
    		$pagination.= "</ul>\n</div>\n";		
    	}
    
    
        return $pagination;
    }

function ago($datefrom,$dateto=-1){
  
        if($datefrom==0) { return "No date provided"; }
        if($dateto==-1) { $dateto = time(); }

        $datefrom = strtotime($datefrom);
   
        $difference = $dateto - $datefrom;

        switch(true)
        {
            case(strtotime('-1 min', $dateto) < $datefrom):
                $datediff = $difference;
                $res = 'Few seconds ago';
                break;
            case(strtotime('-1 hour', $dateto) < $datefrom):
                $datediff = floor($difference / 60);
                $res = ($datediff==1) ? $datediff.' minute ago' : $datediff.' minutes ago';
                break;
            case(strtotime('-1 day', $dateto) < $datefrom):
                $datediff = floor($difference / 60 / 60);
                $res = ($datediff==1) ? $datediff.' hour ago' : $datediff.' hours ago';
                break;
          
            case(strtotime('-1 week', $dateto) < $datefrom):
                $day_difference = 1;
                while (strtotime('-'.$day_difference.' day', $dateto) >= $datefrom) {
                    $day_difference++;
                }
               
                $datediff = $day_difference;
                $res = ($datediff==1) ? 'yesterday' : $datediff.' days ago';
                break;
         
            case(strtotime('-1 month', $dateto) < $datefrom):
                $week_difference = 1;
                while (strtotime('-'.$week_difference.' week', $dateto) >= $datefrom)
                {
                    $week_difference++;
                }
               
                $datediff = $week_difference;
                $res = ($datediff==1) ? 'last week' : $datediff.' weeks ago';
                break;           

            case(strtotime('-1 year', $dateto) < $datefrom):
                $months_difference = 1;
                while (strtotime('-'.$months_difference.' month', $dateto) >= $datefrom)
                {
                    $months_difference++;
                }
               
                $datediff = $months_difference;
                $res = ($datediff==1) ? $datediff.' month ago' : $datediff.' months ago';

                break;

            case(strtotime('-1 year', $dateto) >= $datefrom):
                $year_difference = 1;
                while (strtotime('-'.$year_difference.' year', $dateto) >= $datefrom)
                {
                    $year_difference++;
                }
               
                $datediff = $year_difference;
                $res = ($datediff==1) ? $datediff.' year ago' : $datediff.' years ago';
                break;
               
        }
        return $res;
}

function datetime($date, $print=false) {
	echo "<span class='datetime' title='" . date('l, F j, Y g:i A', strtotime($date)) . "'>" . ago($date) . "</span>";
}

function show_date($date, $timestamp='l, F j, Y g:i A') {
	echo "<span class='show_date'>" . date($timestamp, strtotime($date)) . " | " . ago($date) ."</span>";
}

function get_date($date, $timestamp='l, F j, Y g:i A') {
	return date($timestamp, strtotime($date));
}

function remove_accent($str) {
  $a = array('À','Á','Â','Ã','Ä','Å','Æ','Ç','È','É','Ê','Ë','Ì','Í','Î','Ï','Ð','Ñ','Ò','Ó','Ô','Õ','Ö','Ø','Ù','Ú','Û','Ü','Ý','ß','à','á','â','ã','ä','å','æ','ç','è','é','ê','ë','ì','í','î','ï','ñ','ò','ó','ô','õ','ö','ø','ù','ú','û','ü','ý','ÿ','Ā','ā','Ă','ă','Ą','ą','Ć','ć','Ĉ','ĉ','Ċ','ċ','Č','č','Ď','ď','Đ','đ','Ē','ē','Ĕ','ĕ','Ė','ė','Ę','ę','Ě','ě','Ĝ','ĝ','Ğ','ğ','Ġ','ġ','Ģ','ģ','Ĥ','ĥ','Ħ','ħ','Ĩ','ĩ','Ī','ī','Ĭ','ĭ','Į','į','İ','ı','Ĳ','ĳ','Ĵ','ĵ','Ķ','ķ','Ĺ','ĺ','Ļ','ļ','Ľ','ľ','Ŀ','ŀ','Ł','ł','Ń','ń','Ņ','ņ','Ň','ň','ŉ','Ō','ō','Ŏ','ŏ','Ő','ő','Œ','œ','Ŕ','ŕ','Ŗ','ŗ','Ř','ř','Ś','ś','Ŝ','ŝ','Ş','ş','Š','š','Ţ','ţ','Ť','ť','Ŧ','ŧ','Ũ','ũ','Ū','ū','Ŭ','ŭ','Ů','ů','Ű','ű','Ų','ų','Ŵ','ŵ','Ŷ','ŷ','Ÿ','Ź','ź','Ż','ż','Ž','ž','ſ','ƒ','Ơ','ơ','Ư','ư','Ǎ','ǎ','Ǐ','ǐ','Ǒ','ǒ','Ǔ','ǔ','Ǖ','ǖ','Ǘ','ǘ','Ǚ','ǚ','Ǜ','ǜ','Ǻ','ǻ','Ǽ','ǽ','Ǿ','ǿ');
  $b = array('A','A','A','A','A','A','AE','C','E','E','E','E','I','I','I','I','D','N','O','O','O','O','O','O','U','U','U','U','Y','s','a','a','a','a','a','a','ae','c','e','e','e','e','i','i','i','i','n','o','o','o','o','o','o','u','u','u','u','y','y','A','a','A','a','A','a','C','c','C','c','C','c','C','c','D','d','D','d','E','e','E','e','E','e','E','e','E','e','G','g','G','g','G','g','G','g','H','h','H','h','I','i','I','i','I','i','I','i','I','i','IJ','ij','J','j','K','k','L','l','L','l','L','l','L','l','l','l','N','n','N','n','N','n','n','O','o','O','o','O','o','OE','oe','R','r','R','r','R','r','S','s','S','s','S','s','S','s','T','t','T','t','T','t','U','u','U','u','U','u','U','u','U','u','U','u','W','w','Y','y','Y','Z','z','Z','z','Z','z','s','f','O','o','U','u','A','a','I','i','O','o','U','u','U','u','U','u','U','u','U','u','A','a','AE','ae','O','o');
  return str_replace($a, $b, $str);
}

function make_slug($str) {
	return strtolower(preg_replace(array('/[^a-zA-Z0-9 -]/', '/[ -]+/', '/^-|-$/'), array('', '-', ''), remove_accent($str)));
}

class me {
	
 function refresh_sess($vb='none') {
  if($vb == "none") { 
	   $_SESSION['me'] = false;
	   $_SESSION['setting'] = false;
  } else {
	   $_SESSION[$vb] = false;
  } 
  return true;
 }

}
$do = new me();
function filter_data($val){
  return htmlentities($val,ENT_QUOTES);
}

?>