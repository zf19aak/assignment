<div class="box">

    	<h2>Deposit Money into your account</h2>
        <form class="<?php echo $set['home']; ?>/deposit" method="post">
  		<table class="activate_form">
  			<tr>
  				<td class="label">Amount: (USD)</td>
                <td class="field">
                	<select name="amount" class="toggle_other">
                    	<option value="3">$3</option>
                		<option value="5">$5</option>
                        <option value="10">$10</option>
                        <option value="20">$20</option>
                        <option value="30">$30</option>
                        <option value="40">$40</option>
                        <option value="50">$50</option>
                        <option value="60">$60</option>
                        <option value="70">$70</option>
                        <option value="80">$80</option>
                        <option value="90">$90</option>
                        <option value="100">$100</option>
                        <option value="other">Other Amount</option>
                    </select>
                </td>
  			</tr>
            <tr class="show_other">
  				<td class="label">Other in (USD)</td>
                <td class="field">
                    <input type="text" name="other_amount" value="" placeholder="e.g 3 or 200" /><br />
					<small style="color:#c18372;"><strong>Note:</strong> Min $3 -  Max $1000</small>
                </td>
  			</tr>
            <tr>
  				<td class="label">Payment Method:</td>
                <td class="field">
                	<input type="radio" name="method" id="balance" value="balance" checked="checked" />
                    <label for="balance"><img src="<?php echo $set['home']; ?>/img/pmt-icons/account-balance.png" title="Account Balance" alt="" /></label>
                    <input type="radio" name="method" id="paypal" value="paypal" /> 
                    <label for="paypal"><img src="<?php echo $set['home']; ?>/img/pmt-icons/paypal-big.png" title="Paypal" alt="" /></label>
                </td>
  			</tr>
            <tr class="last_row">
            	<td class="label"><a href="<?php echo $set['home']; ?>/account/">Cancel</a></td>
                <td><input type="submit" value="Proceed" name="form_submit" /></td>
            </tr>
  		</table>
        
        <div class="display_notice no_method">Please contact <a href="<?php echo $set['home']; ?>/support/"><strong>Support</strong></a> if you don't have any of these payment method.</div>
        
         </form>
         
    </div><!-- .box -->
