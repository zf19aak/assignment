<?php 
if (!isset($session_already_sarted)){ session_start(); }
define('HOST','localhost');
define('USER','dailyk8_lancer');
define('PASS','[4@.{[Tk+~Hd');
define('DATABASE','dailyk8_lancerdesk');

$connection = mysql_connect(HOST,USER,PASS);
mysql_set_charset('utf8',$connection); 
if (!$connection) {
	die("Database connection faild: ".mysql_error());
}
$db_selection = mysql_select_db(DATABASE);
if (!$db_selection){
	die("Database selection faild: ".mysql_error());
}

if(!isset($_SESSION['settings'])){
	$setq = mysql_query("SELECT * FROM `options`");
	
	while($r=mysql_fetch_array($setq))	{
	  	$set[$r['option_name']] = $r['option_value'];
	  	$_SESSION['setting'][$r['option_name']] = $r['option_value'];
	}
	
	} else {
	$set = $_SESSION['settings'];
	}

	if(!is_array($set)) {
	 die("An error occured while trying to process the settings, Please re-	access the site later or consult the administrator.");
	}
?>