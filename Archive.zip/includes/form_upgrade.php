<div class="box">

    	<h2>Yo <?php echo $user['username']; ?>! Upgrade your account From <?php echo $user['package']; ?></h2>
        <form class="<?php echo $set['home']; ?>/upgrade" method="post">
  		<table class="activate_form">
  			<tr>
  				<td class="label">Select Package:</td>
                <td class="field">
                	<select name="package">
                    <?php if ($user['package'] == "Golden") { ?>
                        <option value="Ultimate">Ultimate $<?php echo $set['ultimate_price']; ?></option>
                    <?php } elseif ($user['package'] == "Basic") { ?>
                    	<option value="Golden">Golden $<?php echo $set['golden_price']; ?></option>
                        <option value="Ultimate">Ultimate $<?php echo $set['ultimate_price']; ?></option>
                    <?php } ?>
                        
                    </select>
                </td>
  			</tr>
            <tr>
  				<td class="label">Payment From:</td>
                <td class="field">
                   Account Balance (<strong>$<?php echo $user['balance']; ?></strong>) &nbsp; - &nbsp; <a href="<?php echo $set['home']; ?>/deposit"><strong>Deposit</strong></a>
                </td>
  			</tr>
            <tr class="last_row">
            	<td class="label"></td>
                <td><input type="submit" value="Proceed" name="upgrade_submit" /></td>
            </tr>
  		</table>
         </form>
         
    </div><!-- .box -->