   <?php if (isset($expired)) display_error("Your account has been expired."); ?>
    
	<div class="box">

    	<h2>Yo <?php echo $user['username']; ?>! Please Renew your account</h2>
        <form class="<?php echo $set['home']; ?>/renew" method="post">
  		<table class="activate_form">
  			<tr>
  				<td class="label">Renew For:</td>
                <td class="field">
                	<select name="custom_days">
                		<option value="30">1 Month ($5 USD)</option>
                        <option value="185">6 Months ($25 USD)</option>
                        <option value="365">1 Year ($50 USD)</option>
                    </select>
                </td>
  			</tr>
            <tr>
  				<td class="label">Payment From:</td>
                <td class="field">
                   Account Balance (<strong>$<?php echo $user['balance']; ?></strong>) &nbsp; - &nbsp; <a href="<?php echo $set['home']; ?>/deposit"><strong>Deposit</strong></a>
                </td>
  			</tr>
            <tr class="last_row">
            	<td></td>
                <td><input type="submit" value="Proceed" name="renew_submit" /></td>
            </tr>
  		</table>
         </form>
         
    </div><!-- .box -->
