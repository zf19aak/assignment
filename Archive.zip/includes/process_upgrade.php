<?php
if (isset($user_id) && isset($package)) :

$this_user = get_user_info($user_id);

//$package_days = '93';
$package_days = '124';

$result = mysql_query("UPDATE `users` SET `package` = '".$package."', `package_days` = '".$package_days."' WHERE `id` = ".intval($user_id));
add_noti('Congrats! You have successfully upgraded your account to <strong>' . $package . '</strong> Package', intval($user_id),'Account Upgraded!');

endif;
?>