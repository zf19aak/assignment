  <div class="box reviews_wrap">
  	<?php
	$reviews_query = mysql_query("SELECT * FROM `ratings` WHERE `service_id` = '".$row['id']."' AND `user_id` != " . $buyer['id']);
	$count_reviews = mysql_num_rows($reviews_query);
	?>
  	<h2>Customer Reviews <strong><?php echo $row['rating']; ?>%</strong> 
    (<?php echo count_reviews($row['id'],'up','service',$row['user_id']); ?> 
    Ups &amp; <?php echo count_reviews($row['id'],'down','service',$row['user_id']); ?> Downs)</h2>
    <?php
	while ($review_row = mysql_fetch_array($reviews_query)) {
		$this_user = get_user_info($review_row['user_id']);
	?>
    <div class="review_box">
      	<div class="review_sign <?php echo $review_row['rating']; ?>"><?php echo $review_row['rating']; ?></div><!-- .review_sign -->
    	<div class="thumb">
        	<?php the_avatar($this_user['id'],50); ?>
        </div><!-- .thumb -->
        <div class="review">
        	<div class="from"><a href="<?php echo user_permalink($this_user['id']); ?>"><?php echo $this_user['username']; ?></a> 
            	<span>about <?php datetime($review_row['datetime']); ?></span>
            </div>
            <div class="feedback">
				<?php echo nl2br($review_row['review']); ?>
            </div>
        </div><!-- .review -->
    </div><!-- .review_box -->
    
    <?php
	
		$query = mysql_query("SELECT * FROM `ratings` WHERE `order_id` = '".$review_row['order_id']."' AND `user_id` != " . $review_row['user_id']);
		if (mysql_num_rows($query) == 1) {
		$child_row = mysql_fetch_array($query);
		$child_user = get_user_info($child_row['user_id']);
	?>
    
    <div class="review_box seller_review_box">
    	<div class="thumb">
        	<?php the_avatar($child_user['id'],24); ?>
        </div><!-- .thumb -->
        <div class="review">
        	<div class="from">Seller's Feedback:</div>
            <div class="feedback">
				<?php echo nl2br($child_row['review']); ?>
            </div>
        </div><!-- .review -->
    </div><!-- .review_box -->
    
    <?php } ?>
    
    <?php } ?>

    <div class="clear"></div>
  </div><!-- .box -->