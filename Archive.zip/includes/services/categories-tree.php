<h2 class="services_heading">Explore All Services</h2>
<div class="categories_wrap">
<?php
$count = 1;
$query = mysql_query("SELECT * FROM `categories` WHERE `parent` = 0 ORDER BY `position` ASC");
while ($row = mysql_fetch_array($query)) { ?>
<ul>
	<li class="parent_li"><a href="<?php echo category_url($row['id']); ?>"><?php echo $row['name']; ?></a></li>
    <?php
		$sub_query = mysql_query("SELECT * FROM `categories` WHERE `parent` = '".$row['id']."' ORDER BY `position` ASC");
		while ($row = mysql_fetch_array($sub_query)) { 
	?>
    <li><a href="<?php echo category_url($row['id']); ?>"><?php echo $row['name']; ?></a></li>
    <?php } ?>
</ul>
<?php
if ($count == 4) {
	echo'<div class="clear"></div>';
	$count = 0;
}
$count++;
 } ?>
<div class="clear"></div>
</div><!-- .categories_wrap -->