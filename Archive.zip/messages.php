<?php 
include('includes/header_account.php');
$page_title = "Messages";
$upload_files = true;

include('header.php');

$this_username = mres($_GET['username']);
$this_user = get_user_info($this_username,true);

if ($this_username == $user['username']) redirect($set['home'].'/inbox/');

$conversation_id = get_conversation_id($this_user['id'],$user['id']);

if ($conversation_id) {
	$conversation = get_conversation_info($conversation_id);
	if ($conversation['from_id'] == $user['id'] && $conversation['from_unread'] == 1) {
		$update = mysql_query("UPDATE `conversations` SET `from_unread` = 0 WHERE `id` = " . $conversation_id);		
	}
	if ($conversation['to_id'] == $user['id'] && $conversation['to_unread'] == 1) {
		$update = mysql_query("UPDATE `conversations` SET `to_unread` = 0 WHERE `id` = " . $conversation_id);		
	}
}

if (isset($_GET['unread'])) {
	$conversation = get_conversation_info($conversation_id);
	if ($conversation['from_id'] == $user['id'] && $conversation['from_unread'] == 0) {
		$update = mysql_query("UPDATE `conversations` SET `from_unread` = 1 WHERE `id` = " . $conversation_id);		
	}
	if ($conversation['to_id'] == $user['id'] && $conversation['to_unread'] == 0) {
		$update = mysql_query("UPDATE `conversations` SET `to_unread` = 1 WHERE `id` = " . $conversation_id);		
	}
}

if (isset($_POST['send_new_message'])) {
	
	$to_id = intval($this_user['id']);
	$from_id = $user['id'];
	$message = mres($_POST['message']);
	$datetime = date('Y-m-d H:i:s');
	
	$insert_query = mysql_query("INSERT INTO `conversations` (
		`to_id`,
		`from_id`,
		`to_unread`,
		`datetime`,
		`updated`,
		`last_msg_id`
	) VALUES (
		'".$to_id."',
		'".$from_id."',
		'1',
		'".$datetime."',
		'".$datetime."',
		'".$from_id."'
	)");
	
	$rel_id = mysql_insert_id();
	
	$add_msg = mysql_query("INSERT INTO `messages` (
		`conv_id`,
		`user_id`,
		`message`,
		`datetime`
	) VALUES (
		'".$rel_id."',
		'".$from_id."',
		'".$message."',
		'".$datetime."'
		)");
	
	$last_id = mysql_insert_id();
	
	$attach_files = mysql_query("SELECT `id` FROM `files` WHERE `rel_id` = 0 AND `user_id` = '".$user['id']."' AND `msg_id` = 0");
	if (mysql_num_rows($attach_files) > 0) {
		while ($file_row = mysql_fetch_array($attach_files))
		$update_file = mysql_query("UPDATE `files` SET `rel_id` = '".$rel_id."', `msg_id` = " . $last_id . " WHERE `id` = " . $file_row['id']);
	}
	
	$update_again = mysql_query("UPDATE `conversations` SET `last_msg_id` = ".$last_id." WHERE `id` = " .$rel_id);
	
	if ($insert_query && $add_msg && $update_again) {
		$message = "Message Sent!";
	} else {
		$error[] = "Error sending message" . mysql_error();	
	}
	
	$conversation_id = get_conversation_id($this_user['id'],$user['id']);
	
	$noti_desc = $user['username'] ." sent you a message. Click to reply.";
	$noti_url = '/messages/'.$user['username'].'/';
	add_noti($noti_desc,$this_user['id'],$noti_url);
		
}

if (isset($_POST['send_message'])) {
	
	$rel_id = $conversation_id;
	$user_id = $user['id'];
	$message = mres($_POST['message']);
	$datetime = date('Y-m-d H:i:s');
	
	if ($conversation['to_id'] == $user['id']) {
		$read_field = "from_unread";
	} else {
		$read_field = "to_unread";
	}
	
	$add_msg = mysql_query("INSERT INTO `messages` (
		`conv_id`,
		`user_id`,
		`message`,
		`datetime`
	) VALUES (
		'".$rel_id."',
		'".$user_id."',
		'".$message."',
		'".$datetime."'
		)");
	
	$last_id = mysql_insert_id();
	
	$attach_files = mysql_query("SELECT `id` FROM `files` WHERE `rel_id` = " .$rel_id." AND `user_id` = '".$user_id."' AND `msg_id` = 0");
	if (mysql_num_rows($attach_files) > 0) {
		while ($file_row = mysql_fetch_array($attach_files))
		$update_file = mysql_query("UPDATE `files` SET `msg_id` = " . $last_id . " WHERE `id` = " . $file_row['id']);
	}
	
	$update = mysql_query("UPDATE `conversations` SET `".$read_field."` = '1', `last_msg_id` = '".$last_id."' WHERE `id` = " . $rel_id);
	
	$noti_desc = $user['username'] ." sent you a message. Click to reply.";
	$noti_url = '/messages/'.$user['username'].'/';
	add_noti($noti_desc,$this_user['id'],$noti_url);
	
	if (!$update || !$add_msg) $error[] = "Error sending Message " .mysql_error();
		
}

display_error(); display_notice(); 

?>

<div class="side_content">
  
     <div class="box messages_wrap order_wrap">
    	<h2><?php if (!$conversation_id) echo 'Start'; ?> Conversation with <?php echo $this_user['username']; ?><span class="right">
        	<a href="<?php echo $_SERVER['REQUEST_URI']; ?>mark/unread/" class="new_button">Mark as Unread</a>
            </span></h2>
     	<div class="order_meta">&nbsp;</div>
    
<?php

if ($conversation_id == false) {
	
	  $form_submit_name = "send_new_message";
	  $form_url =  $set['home']. '/messages/'. $this_user['username']. '/';
	  echo "</div>";
	  include('includes/messages/send-message-box.php'); 
	 
	
} else {
	
	  $check = mysql_query("SELECT * FROM `messages` WHERE `conv_id` = " . $conversation_id);
	  $first_count = 1; 
	  
	  while ($row = mysql_fetch_array($check)) {
		  if ($row['user_id'] == $user['id']) {
			 $box_class = " my_msg";
		  } else {
			 $box_class = "";
		  }
		  include('includes/messages/message-box.php');
	  }
	  echo "</div>";

	  $form_submit_name = "send_message";
	  $form_url =  $set['home']. '/messages/'. $this_user['username']. '/';
	  include('includes/messages/send-message-box.php'); 
	
}
?>
         
         <div class="clear"></div>
   
</div><!-- .side_content -->
<?php
if (isset($conversation['id'])){
    $file_rel_id = $conversation_id;
} else {
	$file_rel_id = 0;	
}
?>
<?php include('includes/sidebars/sidebar-messages.php');  ?>  
<?php include('footer.php');  ?>    