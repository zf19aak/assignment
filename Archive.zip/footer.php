</div><!-- .wrap -->
</div><!-- .content -->
<div class="footer">
    <div class="footer_msg">
	    <div class="wrap">We're in beta at the moment and would love to hear your thoughts <a href="<?php echo $set['home']; ?>/support/">Feedback</a></div>
    </div><!-- .footer_msg -->
    <div class="wrap">
    <div class="footer_links">	
    	<ul>
        	<li><a href="<?php echo $set['home']; ?>/services/">Explore Services</a></li>
        	<li><a href="<?php echo $set['home']; ?>/how-it-works/">How it Works?</a></li>
        </ul>
        <ul>
        	<li><a href="<?php echo $set['home']; ?>/forum/">Forum</a></li>
        	<li><a href="<?php echo $set['home']; ?>/support/">Support</a></li>
        </ul>
		<ul class="last">
	    	<li><a href="<?php echo $set['home']; ?>/terms-of-service/">Terms of Service</a></li>
	    	<li><a href="<?php echo $set['home']; ?>/privacy-policy/">Privacy Policy</a></li>
	    </ul>
		<div class="footer_logos">
        	<img src="<?php data_image('img/comodo-secure.png'); ?>" alt="Verified by Comodo">
        </div><!-- .footer_logos -->
        <div class="clear"></div>
    </div><!-- .footer_links -->
	<div class="copyright">Copyright &copy; <?php echo date("Y") . " " .  $set['name']; ?>. All Rights Reserved</div>
    <div class="social_icons">
        	<a href="https://www.facebook.com/" target="_blank"><img src="<?php data_image('img/icons/fb.png'); ?>" height="30" width="30" alt=Facebook></a>
            <a href="https://twitter.com/" target="_blank"><img src="<?php data_image('img/icons/twitter.png'); ?>" height="30" width="30" alt=Twitter></a>
    </div><!-- .social_icons -->
    </div><!-- .wrap -->
</div><!-- .footer -->
<script src="<?php echo $set['home']; ?>/js/jquery-1.10.1.min.js"></script>
<?php if (isset($upload_files)) { ?>
<script src="<?php echo $set['home']; ?>/js/jquery.uploadify.js"></script>
<?php } ?>
<?php if (!isset($front_page)) { ?>
<script src="<?php echo $set['home']; ?>/js/jquery.validate.min.js"></script>
<script src="<?php echo $set['home']; ?>/js/jquery.easing.1.3.js"></script>
<?php } ?>
<script>
jQuery(document).ready(function() {
	jQuery('a.logout').click(function(){jQuery.ajax({type:"POST",url:"<?php echo $set['home']; ?>/logout.php",data:'',success:function(r){window.location='<?php echo $set['home']; ?>/'}});return false});
	jQuery('a.all_cat_trigger').click(function(){
		jQuery(this).toggleClass('current');
		jQuery('.sub_cat_list').hide();
		jQuery('#parent-of-6').show();
		jQuery('.cat_list a').removeClass();
		jQuery('.cat_list').slideToggle();
		jQuery('#6').addClass('hovered');
		return false;
	});
	jQuery("body").click(function(){ jQuery(".cat_list").hide(); jQuery('a.all_cat_trigger').removeClass('current'); });
	jQuery(".cat_list, a.all_cat_trigger").click(function(e) {e.stopPropagation();});
	jQuery('.cat_list a.parent_link').hover(function(e) {
        var id = jQuery(this).attr('id');
		jQuery(".cat_list a").removeClass();
		jQuery(this).addClass('hovered');
		jQuery('.sub_cat_list').hide();
		jQuery('#parent-of-'+id).show();
    });


	jQuery('.check_checked').click(function () {
		var price = jQuery(this).attr('data-price');
		var total = jQuery('span.total_price').text();
    	if(jQuery(this).is(':checked')) {
			jQuery('span.total_price').text(Number(total)+Number(price));
		} else {
			jQuery('span.total_price').text(Number(total)-Number(price));
		}
	});
<?php if (isset($this_order_page))	{ ?>
	jQuery('a.buy_extra').click(function () {
		 var extra = jQuery(this).attr('data-extra');
		 var order = jQuery(this).attr('data-order');
		 var this_link = jQuery(this);
		 jQuery(this_link).next('.loading').css('display','inline-block');
		 jQuery(this_link).addClass('current');
		   jQuery.ajax({
		       type: "POST",
		       url:"<?php echo $set['home']; ?>/ajax/buy-extras.php",
		       data: { 'extra': extra, 'order':order },
		       success: function (data) {
		          if ( data == 1) {
					 location.reload();
				  } else {
					 if (data == 'no fund'){
						 alert("Sorry, you don't have enought purchase balance to buy this extra.");
					 } else {
						 alert('Some error accoured: Please contact support')
					 }
				  }
		       }
		   });
		 return false;
      });
<?php }?>
<?php if (isset($upload_files)) { ?>	
	$('#file_upload').uploadify({
		  'swf' : '<?php echo $set['home']; ?>/js/uploadify.swf',
          'uploader' : '<?php echo $set['home']; ?>/ajax/file-upload.php',
		   'formData'      : {'rel_id' : '<?php echo $file_rel_id; ?>','u_id':'<?php echo $user['id']; ?>'},
		   'onUploadSuccess' : function(file, data, response) {
			    $('.uploadify-progress').hide();
			  	var got_data = data.split(',');
				var uploaded_id = got_data[1];
				if ( got_data[0] != 1) {
                     $('#'+file.id).addClass('uploadify-error');                                    
                     $('#'+file.id + ' .data').text( ' - ' + data);
                     return false;
                } else {
					$('#'+file.id + ' .cancel a').addClass('delete_file').attr('id',uploaded_id);
				}
          },
		  'onSelect' : function(file) {
            $('input[type=submit]').attr("disabled","disabled");
          },
		  'onQueueComplete' : function(queueData) {
            $('input[type=submit]').removeAttr("disabled","disabled");
        } 
      });
	  
	  $(document).on('click', 'a.delete_file', function(e) {
		 var delete_id = $(this).attr('id');
		 $(this).hide();
		   $.ajax({
		       type: "POST",
		       url:"<?php echo $set['home']; ?>/ajax/file-delete.php",
		       data: { id: delete_id},
		       success: function (data) {
		          if ( data == 1) {
					  
					 //return true;
					 
				  } else {
					 alert(data);
					 return false;
					 $(this).hide();
				  }
		       }
		   });
      });  
<?php } ?>	
<?php if (isset($single_service_page) && $service['reviews'] > 0) { ?>	
	jQuery("#service_reviews").load("<?php echo $set['home']; ?>/ajax/get-reviews.php", {
			'page':1,
			'type':'all',
			'service_id':<?php echo $service['id']; ?>}, function() {});
	jQuery(document).on('click', '.reviews_pagination a.trigger', function(e) {
        jQuery("#service_reviews .reviews_inside").html('<div class="loading"></div>');
		jQuery('.reviews_pagination a').removeClass();
		jQuery(this).addClass('current');
		var page = jQuery(this).attr('data-page');
		var type = jQuery(this).attr('data-type');
        jQuery("#service_reviews").load("<?php echo $set['home']; ?>/ajax/get-reviews.php", {'page':page,'type':type,'service_id':<?php echo $service['id']; ?>}, function() {});
        return false;
    });
	
	jQuery(document).on('click', 'a.rreview_type_trigger', function(e) {
	  	jQuery("#service_reviews .reviews_inside").html('<div class="loading"></div>');
		jQuery('.reviews_wrap h2 span a').removeClass();
	  	jQuery(this).addClass('active');
		var type = jQuery(this).attr('data-type');
        jQuery("#service_reviews").load("<?php echo $set['home']; ?>/ajax/get-reviews.php", {'page':1,'type':type,'service_id':<?php echo $service['id']; ?>}, function() {});
        return false;
      });
<?php } ?>	

<?php if (isset($this_search_page)) { ?>
	jQuery("#services_wrap").load("<?php echo $set['home']; ?>/ajax/get-search-results.php", {
			'page':1,
			'query':'<?php echo $search_query; ?>',
			'tag':'<?php echo $is_tag; ?>',
			'filter':'latest',
			}, function() {});
			
	  jQuery(document).on('click', 'a.filter_trigger', function(e) {
	  jQuery("#services_wrap .services_wrap").html('<div class="services_loading"></div>');
	  jQuery('.filter_wrap a').removeClass('current').addClass('filter_trigger');
	  jQuery(this).removeClass().addClass('current');
	  var filter = jQuery(this).attr('data-filter');
	  
	  jQuery("#services_wrap").load("<?php echo $set['home']; ?>/ajax/get-search-results.php", {
			  'page':1,
			  'query':'<?php echo $search_query; ?>',
			  'tag':'<?php echo $is_tag; ?>',
			  'filter':filter,
			  }, function(){});
	  return false;
      });
	
    jQuery(document).on('click', '.search_pagination a', function(e) {
        jQuery("#services_wrap .services_wrap").html('<div class="services_loading"></div>');
		jQuery('.search_pagination a').removeClass();
		jQuery(this).addClass('current');
		var page = jQuery(this).attr('data-page');
		var query = jQuery(this).attr('data-query');
		var tag = jQuery(this).attr('data-tag');
		var filter = jQuery(this).attr('data-filter');
        jQuery("#services_wrap").load("<?php echo $set['home']; ?>/ajax/get-search-results.php", {'page':page,'query':query,'tag':tag,'filter':filter}, function(){});
        return false;
    });
<?php } ?>	
<?php if (isset($this_services_page)) { ?>
	jQuery("#services_wrap").load("<?php echo $set['home']; ?>/ajax/get-services.php", {
			'page':1,
			'category':<?php echo $category['id']; ?>,
			'sub_category':<?php echo (isset($sub_category['id']))? $sub_category['id'] : 0; ?>,
			'filter':'latest',
			}, function() {});
	  jQuery(document).on('click', 'a.filter_trigger', function(e) {
	  jQuery("#services_wrap .services_wrap").html('<div class="services_loading"></div>');
	  jQuery('.filter_wrap a').removeClass('current').addClass('filter_trigger');
	  jQuery(this).removeClass().addClass('current');
	  var filter = jQuery(this).attr('data-filter');
	  
	  jQuery("#services_wrap").load("<?php echo $set['home']; ?>/ajax/get-services.php", {
			  'page':1,
			  'category':<?php echo $category['id']; ?>,
			  'sub_category':<?php echo (isset($sub_category['id']))? $sub_category['id'] : 0; ?>,
			  'filter':filter,
			  }, function(){});
	  return false;
      });
	
    jQuery(document).on('click', '.services_pagination a', function(e) {
        jQuery("#services_wrap .services_wrap").html('<div class="services_loading"></div>');
		jQuery('.services_pagination a').removeClass();
		jQuery(this).addClass('current');
		var page = jQuery(this).attr('data-page');
		var category = jQuery(this).attr('data-category');
		var subcategory = jQuery(this).attr('data-subcategory');
		var filter = jQuery(this).attr('data-filter');
        jQuery("#services_wrap").load("<?php echo $set['home']; ?>/ajax/get-services.php", {'page':page,'category':category,'sub_category':subcategory,'filter':filter}, function(){});
        return false;
    });
<?php } ?>	
<?php if (isset($id_new_page)) { ?>
	jQuery('.choose_cat').change(function(){
		jQuery('.sub_cat_wrap').hide();
		jQuery('span.loading').show();
		var id = jQuery(this).val();
		if (id == '5') {
			jQuery('.loading').hide();
		} else {
			jQuery.ajax({type:"POST",url:"<?php echo $set['home']; ?>/ajax/update_subcat.php",data:'id='+id,success:function(data){
			jQuery('.loading').hide();
			jQuery('.sub_cat_wrap').show().html(data);
			}});
		}
	});
jQuery("#new_service_form").validate({
		    rules: {
				username: {
					required: true
				},
		        password: {
		            required: true
		        },
				recaptcha_response_field: {
		            required: true
		        }
		    },
			messages: {
				username: {
					required: "Please enter your username."
				},
				password: {
					required: "Please enter your password."
				},
				recaptcha_response_field: {
		            required: "Required"
		        }
			}
		});
	
<?php } ?>
<?php if (isset($deposit_page)) { ?>
		jQuery('.toggle_other').change(function(){
			if ( jQuery(this).val() == 'other'){
				jQuery('tr.show_other').show('slow');
			} else {
				jQuery('tr.show_other').hide('slow');	
			}
		});
		jQuery("input[type='text'][name='other_amount']").change(function() {
		    if (jQuery(this).val() < 3 ) {
		        alert("Sorry, minimun deposit ammount is $3.");
		        jQuery(this).val('');
		        jQuery(this).focus();
		    } else {
				if (jQuery(this).val() > 1000 ) {
			        alert("Sorry, minimum deposit amount $1000.");
			        jQuery(this).val('');
			        jQuery(this).focus();
			    }      
			}
		}); 
		<?php }?>
	<?php if (isset($withdraw_page)) { ?>
	jQuery("input[type='text'][name='from_other']").change(function() {
	    if (jQuery(this).val() > <?php echo $user['balance']; ?> ) {
	        alert("Sorry, requested amount cannot be greate than your available balance.");
	        jQuery(this).val('');
	        jQuery(this).focus();
	    } else {
			if (jQuery(this).val() < <?php echo $set['minimum_withdrawal'] ?> ) {
		        alert("Sorry, Minimum withdrawal amount should be $<?php echo $set['minimum_withdrawal'] ?>.");
		        jQuery(this).val('');
		        jQuery(this).focus();
		    }      
		}
	});  
	<?php } ?>
	<?php if (isset($is_settings_page)) { ?>
		jQuery("#update_settings").validate({
		    rules: {
				new_password: {
					minlength: 5
		        },
				 email: {
		            required: true
		        },
				 first_name: {
		            required: true
		        },
				 last_name: {
		            required: true
		        },
		        current_password: {
		            required: true
		        }
		    },
			messages: {
				first_name: {
					required: "Please enter first name."
				},
				last_name: {
					required: "Please enter last name."
				},
				email: {
					required: "Email Address is required."
				},
				current_password: {
					required: "Current Password is required to update settings."
				}
			}
		});
		<?php } ?>
	<?php if (isset($is_signin_page)) { ?>
		jQuery("#signin_validate_form").validate({
		    rules: {
				username: {
					required: true
				},
		        password: {
		            required: true
		        },
				recaptcha_response_field: {
		            required: true
		        }
		    },
			messages: {
				username: {
					required: "Please enter your username."
				},
				password: {
					required: "Please enter your password."
				},
				recaptcha_response_field: {
		            required: "Required"
		        }
			}
		});
		<?php } ?>
	<?php if (isset($is_signup_page)) { ?>
	jQuery.validator.addMethod("alphanumeric", function(value, element) {
	    return this.optional(element) || /^[a-zA-Z0-9_]+$/i.test(value);
	}, "Letters, numbers, and underscores only please");
	
	jQuery.validator.addMethod("noSpace", function(value, element) { 
	     return value.indexOf(" ") < 0 && value != ""; 
	  }, "Space is not allowed");
	
		jQuery("#validate_signup_form").validate({
		    rules: {
				username: {
					required: true,
					noSpace: true,
					alphanumeric: true,
					minlength: 4
				},
		        password: {
		            required: true,
					minlength: 5
		        },
		        confirm_password: {
		            required: true,
		            equalTo: "input[name=password]"
		        },
				recaptcha_response_field: {
		            required: true
		        }
		    },
			messages: {
				first_name: {
					required: "Please enter your first name.",
				},
				last_name: {
					required: "Please enter your last name.",
				},
				username: {
					required: "Please enter your username.",
					minlength: "Username cannot have less than 4 characters"
				},
				password: {
					required: "Please enter your password.",
					minlength: "Password cannot have less than 5 characters"
				},
				agree: {
					required: "You must agree to our terms of service.",
				},
				confirm_password: {
					required: "Please enter your password again",
					equalTo: "Password doesn't match!"
				},
				recaptcha_response_field: {
		            required: "Required"
		        },
				email: "Please enter a valid email address"
			}
		});
		<?php } ?>
		<?php if (isset($email_verify_page)) { ?>
		jQuery('a.show_reset_email').click(function(){ jQuery('.set_new_email_table').slideDown('slow'); });
		jQuery("#validate").validate({
		    rules: {
				new_email: {
					required: true
				},
				username_or_email: {
					required: true
				},
				new_password: {
					required: true,
					minlength: 5
				},
				confirm_password: {
					required: true,
					minlength: 5
				}
		    },
			messages: {
				new_email: {
					required: "Please enter your email address."
				},
				username_or_email: {
					required: "Please enter your username or email address."
				}
			}
		});
		<?php } ?>
		<?php if (isset($action_box)) { ?>
			jQuery('.send_reply_box').hide();
			jQuery('a.click_complete_order').click(function(){
				jQuery('.send_reply_box').hide();
				jQuery('.post_review_box').fadeIn('fast');
				return false;	
			});
			jQuery('a.click_contact_seller').click(function(){
				jQuery('.post_review_box').hide();
				jQuery('.send_reply_box').not('.send_reply_box.post_review_box').fadeIn();
				return false;	
			});
		
		<?php } ?>
		
		<?php if (isset($is_settings_page)) { ?>
		jQuery('.check_length').keyup(function () {
		  var max = jQuery(this).attr('maxlength');
		  var len = jQuery(this).val().length;
		  if (len >= max) jQuery(this).next('.inst').addClass('error');
		  jQuery(this).next('div.inst').text('('+ len +' / '+max+' MAX)');
		});
		<?php } ?>
		});
</script>

</body>
</html>