<?php 
$page_title = "Manage Sales";
include('includes/header_account.php');
include('header.php'); 
display_error(); display_notice(); 
?>

<div class="side_content">
  
       <div class="box">
 
        <h2>Manage Sales</h2>
        
        <table class="main_stats"> 
          <tr>
            <td><a href="<?php echo $set['home']; ?>/sales/"><strong><?php echo count_orders('all','seller_id',$user['id']); ?></strong><br>All</a></td>
            <td><a href="<?php echo $set['home']; ?>/sales/type/active/"><strong><?php echo count_orders('Active','seller_id',$user['id']); ?></strong><br>Active</a></td>
            <td><a href="<?php echo $set['home']; ?>/sales/type/completed/"><strong><?php echo count_orders('Completed','seller_id',$user['id']); ?></strong><br>Completed</a></td>
            <td><a href="<?php echo $set['home']; ?>/sales/type/delivered/"><strong><?php echo count_orders('Delivered','seller_id',$user['id']); ?></strong><br>Delivered</a></td>
            <td class="last"><a href="<?php echo $set['home']; ?>/sales/type/cancelled/"><strong><?php echo count_orders('Cancelled','seller_id',$user['id']); ?></strong><br>Cancelled</a></td>
          </tr>
        </table>
        
    </div><!-- .box -->
  
 <?php
 	
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	if ($page == '') $page = 1;
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;

	$by_type = ' ';
	
	if (isset($_GET['type'])) {
		$type = mres($_GET['type']);
		$by_type = " AND `status` = '".ucfirst($type)."' ";
	} else {
		$type = 'all';
	}
	
	$statement = "`orders` WHERE `seller_id` = '".$user['id']."' ".$by_type." ORDER BY `id` DESC";
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$total = mysql_num_rows($result);
 ?>
	
     <?php echo pagination($statement,$limit,$page); ?>
    
    <div class="box">
    
    <h2><span class="left">
    	<a href="<?php echo $set['home']; ?>/sales/" class="new_button<?php if ($type == 'all') echo ' current'; ?>">All</a>
        <a href="<?php echo $set['home']; ?>/sales/type/active/" class="new_button<?php if ($type == 'active') echo ' current'; ?>">Active</a>
        <a href="<?php echo $set['home']; ?>/sales/type/completed/" class="new_button<?php if ($type == 'completed') echo ' current'; ?>">Completed</a>
        <a href="<?php echo $set['home']; ?>/sales/type/pending/" class="new_button<?php if ($type == 'pending') echo ' current'; ?>">Pending</a>
        <a href="<?php echo $set['home']; ?>/sales/type/cancelled/" class="new_button<?php if ($type == 'cancelled') echo ' current'; ?>">Cancelled</a>
     </span>&nbsp;</h2>
    
    <?php  ?>
    
        <table class="referrals_table">
        	<tr class="head">
        		<td width="70" align="left">Buyer</td>
                <td align="left">Service</td>
                <td>Date</td>
                <td>Total</td>
                <td>Status</td>
        	</tr>
            <?php
				if ($total != 0) {
				$count = 0;
				while ($row = mysql_fetch_array($result)) : 
				$buyer = get_user_info($row['buyer_id']);
				$service = get_service_info($row['service_id']);
			?>
            <tr class="<?php if($row['status'] != 'Completed') echo "even"; ?> <?php if($row['status'] == 'Canceled') echo "pending"; ?>" >
            	<td align="left"> <a href="<?php echo user_permalink($buyer['id']); ?>"><?php echo $buyer['username']; ?></a></td>
                <td align="left">
                	<a href="<?php echo $set['home']; ?>/order/<?php echo $row['number']; ?>/">
					<?php if (isset($service['id'])) {
						echo $service['title'];
					} else {
						echo 'Service Deleted!';
					} ?>
                    </a>
                </td>
                <td><?php echo get_date($row['datetime'],'M j, y'); ?></td>
                <td><strong>$<?php echo $row['price']; ?></strong></td>
                <td><?php echo $row['status']; ?></td>
            </tr>
            <?php $count++; ?>
            <?php endwhile;  ?>
            <?php } else { ?>
            <tr>
             <td colspan="5" class="alignleft">
             <?php if (count_orders('all','seller_id',$user['id']) == 0) { echo "No sales so far!"; 
			 } else { 
			 	echo "No " . $type . ' orders to show.';
			  } ?>
             </td>
            </tr>
            <?php } ?>
        </table>
        
    </div><!-- .box -->

	<?php echo pagination($statement,$limit,$page); ?>


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-sales.php');  ?>  
<?php include('footer.php');  ?>    