<?php
include('includes/header_account.php');
$page_title = "My Payments";
$meta_desc = "All your account info." . $set['meta_desc'];
include('header.php');

display_message(); display_error(); display_notice();

$active_count = mysql_query("SELECT `price` FROM `orders` WHERE `status` = 'Active' AND `buyer_id` = " . $user['id']);
$total_active = 0;
while ($count_row = mysql_fetch_array($active_count)){
	$amount = get_seller_earning_amount($count_row['price']);
	$total_active = $total_active + $amount;
}

$count_completed = mysql_query("SELECT `price` FROM `orders` WHERE `status` = 'Completed' AND `buyer_id` = " . $user['id']);
$total_completed = 0;
while ($complete_count_row = mysql_fetch_array($count_completed)){
	$complete_amount = get_seller_earning_amount($complete_count_row['price']);
	$total_completed = $total_completed + $complete_amount;
}

?>

<div class="side_content">

<div class="box">
        <h2>Payments</h2>
        <table class="main_stats"> 
          <tr>
            <td><strong>$<?php echo round($user['total_deposit'],2); ?></strong><br>Total Deposit</td>
            <td><strong>$<?php echo $total_active ?></strong><br>Active Orders</td>
            <td><strong>$<?php echo $total_completed ?></strong><br>Completed Orders</td>
            <td class="last"><a href="<?php echo $set['home']; ?>/deposit/"><strong>$<?php echo round($user['purchase_balance'],2); ?></strong><br>Purchase balance</a></td>
          </tr>
        </table>
    </div><!-- .box -->

    
  	<div class="clear"></div>
    
    <div class="box">
    
<?php
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	if ($page == '') $page = 1;
	$limit = 20;
	$startpoint = ($page * $limit) - $limit;

	$by_type = ' ';
	
	if (isset($_GET['type'])) {
		$type = mres($_GET['type']);
		$by_type = " AND `type` = '".ucfirst($type)."' ";
	} else {
		$type = 'all';
	}
	
	$statement = "`payments` WHERE `user_id` = '".$user['id']."' ".$by_type." ORDER BY `id` DESC";
	
 	$result = mysql_query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");
	$total = mysql_num_rows($result);
 ?>

    <?php  ?>
    
    	<h2><span class="left">
    	<a href="<?php echo $set['home']; ?>/payments/" class="new_button<?php if ($type == 'all') echo ' current'; ?>">All</a>
        <a href="<?php echo $set['home']; ?>/payments/type/deposit/" class="new_button<?php if ($type == 'deposit') echo ' current'; ?>">Deposit</a>
        <a href="<?php echo $set['home']; ?>/payments/type/payment/" class="new_button<?php if ($type == 'payment') echo ' current'; ?>">Payment</a>
        <a href="<?php echo $set['home']; ?>/payments/type/cancelled/" class="new_button<?php if ($type == 'cancelled') echo ' current'; ?>">Cancelled</a>
     	</span>&nbsp;</h2>
        
        <table class="data_table">
        	<tr class="head">
            	<td width="100">Amount</td>
        		<td class="alignleft">Description</td>
                <td width="120">Due Date</td>
        	</tr>
            <?php
				if ($total != 0) {
				while ($row = mysql_fetch_array($result)) : 
			?>
            <tr>
            	<td><strong>$<?php echo $row['amount']; ?></strong></td>
            	<td class="alignleft">
                <?php
					if ($row['type'] == 'Deposit') {
						echo $row['description'];
					} elseif ($row['type'] == 'Payment') {
						echo "- Service Purchased from Purcahse balance";
					} elseif ($row['type'] == 'Cancelled') {
						echo "Payment Cancelled";	
					}
				?>
                </td>
                <td><?php echo get_date($row['datetime'],'j F, Y'); ?></td>
            </tr>
            <?php endwhile;  ?>
            <?php } else { ?>
            <tr>
            	 <td colspan="3" class="alignleft">
                 <?php if ($type == 'all') { 
				 			echo "No earnings so far."; 
				 		} else { 
				 			echo "No " . $type . ' payments to show.';
				 	} ?>
                 </td>
            </tr>
            <?php } ?>
        </table>
    </div><!-- .box -->


</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-shopping.php'); ?>
<?php include('footer.php');  ?>    