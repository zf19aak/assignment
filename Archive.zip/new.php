<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
include('includes/header_account.php');

$id_new_page = true;

if (isset($_POST['new_submit'])) { 

$user = get_loggedin_info();

$title = mres($_POST['title']);
$price = mres($_POST['price']);
$duration = mres($_POST['duration']);
$category = mres($_POST['category']);
if ($category != '5' && $category != 0) $sub_category = mres($_POST['sub_category']);
$description = mres($_POST['description']);
$tags = mres($_POST['tags']);
$instructions = mres($_POST['instructions']);
$datetime = date("Y-m-d H:i:s");

$extra_fast_ticked = mres($_POST['extra_fast_ticked']);
$extra_fast_price = mres($_POST['extra_fast_price']);
$extra_fast_duration = mres($_POST['extra_fast_duration']);

$extra_1_ticked = mres($_POST['extra_1_ticked']);
$extra_1_title = mres($_POST['extra_1_title']);
$extra_1_price = mres($_POST['extra_1_price']);
$extra_1_duration = mres($_POST['extra_1_duration']);

$extra_2_ticked = mres($_POST['extra_2_ticked']);
$extra_2_title = mres($_POST['extra_2_title']);
$extra_2_price = mres($_POST['extra_2_price']);
$extra_2_duration = mres($_POST['extra_2_duration']);

$extra_3_ticked = mres($_POST['extra_3_ticked']);
$extra_3_title = mres($_POST['extra_3_title']);
$extra_3_price = mres($_POST['extra_3_price']);
$extra_3_duration = mres($_POST['extra_3_duration']);

	if ($title == '') $error[] = "Title field is required";
	if (strlen($title) < 20 && $title != '') $error[] = "Title is too short! Minimum length is 20 characters";
	if (strlen($title) > 80) $error[] = "Title is too long! Maximum length is 80 characters";
	
	if ($price == '') $error[] = "Price field cannot be empty";
	if ($duration == '') $error[] = "Time Duration field cannot be empty";
	
	if (($duration < 1 || $duration > 10) && $duration != '') $error[] = "Time duration within 10 days";
	
	if ($category == 0) $error[] = "Please select a category";
	if ($category != '5' && $category != 0 && $sub_category == 0) $error[] = "Please select a sub category";
	
	if ($description == '') $error[] = "Description is required!";
	if (strlen($description) < 80 && $description != '') $error[] = "Description is too short! Minimum length is 80 characters";
	if (strlen($description) > 1200) $error[] = "Description is too long! Maximum length is 1200 characters";
	
	$total_tags = explode(',',$tags);
	if (count($total_tags) < 3 && $tags != '') $error[] = "Minimum 3 tags are required.";
	
	if ($instructions == '') $error[] = "Instructions for buyer is required!";
	if (strlen($instructions) > 500) $error[] = "instructions is too long! Maximum length is 500 characters";
	
	if (!in_array($price,allowed_prices($user['level']))) $error[] = "You are not allowed to set this service price.";
	

	// Image Processing
	
	$image_name = $_FILES["image"]["name"];
	$image_type = $_FILES["image"]["type"];
	
	$arr = explode(".", $image_name);
    $image_extension = strtolower(array_pop($arr));   
    
	if ($_FILES["image"]["error"] != 4) {
	
	$image_location = 'uploads/service-imgs/';
			
		if ((($image_type == "image/gif") || ($image_type == "image/jpeg") || ($image_type == "image/png") || ($image_type == "image/pjpeg"))) {
	
	  		if ($_FILES["image"]["error"] > 0) {
	    		$error[] = "Return Code: " . $_FILES["image"]["error"] . "<br>";
	    	} else {
				
				$storeimage =  $user['id'].'-service-img-' . substr(md5(date("ymdhis")),0,10);
				
				$image_info = getimagesize($_FILES["image"]["tmp_name"]);
				$image_width = $image_info[0];
				$image_height = $image_info[1];
  				
				if ($image_width < 640 || $image_height < 400) $error[] = "Minimum image size is 640 x 400 pixels";
				
				if ($image_width <= 640 && $image_height <= 400) {
					
					if (empty($error)) {
						move_uploaded_file($_FILES["image"]["tmp_name"], $image_location . $storeimage .'.'. $image_extension);
					}
					
				} else {
				
				if (empty($error)) {
				include('includes/class.upload.php');
			
				$foo = new Upload($_FILES["image"]);
				if ($foo->uploaded) {

				  $foo->file_new_name_body = $storeimage;
				  $foo->image_resize = true;
				  $foo->image_ratio_crop = true;
				  $foo->image_x = 640;
				  $foo->image_y = 400;
				  $foo->Process($image_location);
				  if ($foo->processed) {
				    $foo->Clean();
				  } else {
				    $error[] = 'error : ' . $foo->error;
				  }
				}
				
				}

				
				}
				
		    }
	  
		} else {
		  $error[] = "Invalid file";
		}
  
  } else { // image is not selected
	$storeimage = false;
  }
	
	// END Image Processing

if (!$storeimage) $error[] = 'Service image is required.';

if (!isset($sub_category)) $sub_category = 0;
	
if (empty($error)) {
	$query = mysql_query("INSERt INTO `services` (
		`user_id`,
		`title`,
		`price`,
		`duration`,
		`cat_id`,
		`sub_cat_id`,
		`description`,
		`tags`,
		`instructions`,
		`datetime`,
		`image`,
		`extra_fast_ticked`,
		`extra_fast_price`,
		`extra_fast_duration`,
		`extra_1_ticked`,
		`extra_1_title`,
		`extra_1_price`,
		`extra_1_duration`,
		`extra_2_ticked`,
		`extra_2_title`,
		`extra_2_price`,
		`extra_2_duration`,
		`extra_3_ticked`,
		`extra_3_title`,
		`extra_3_price`,
		`extra_3_duration`,
		`status`
	) VALUES (
		'".$user['id']."',
		'".$title."',
		'".$price."',
		'".$duration."',
		'".$category."',
		'".$sub_category."',
		'".$description."',
		'".$tags."',
		'".$instructions."',
		'".$datetime."',
		'".$storeimage.".".$image_extension."',
		'".$extra_fast_ticked."',
		'".$extra_fast_price."',
		'".$extra_fast_duration."',
		'".$extra_1_ticked."',
		'".$extra_1_title."',
		'".$extra_1_price."',
		'".$extra_1_duration."',
		'".$extra_2_ticked."',
		'".$extra_2_title."',
		'".$extra_2_price."',
		'".$extra_2_duration."',
		'".$extra_3_ticked."',
		'".$extra_3_title."',
		'".$extra_3_price."',
		'".$extra_3_duration."',
		'Pending'
	)");	
	
	if ($query){
		
		$_SESSION['service_pending'] = true;
		redirect($set['home'].'/my-services/');
		
	} else {
		$error[] = "Error inserting data into database" . mysql_error();
	}
	
}

} // if form submit

$page_title = "New Service";

include('header.php'); 
display_error(); display_notice(); display_message(); 
?>

<div class="side_content">
  <form action="<?php echo $set['home']; ?>/new/" method="post" enctype="multipart/form-data">
     <div class="box">
 
    	<h2>Create New Service <span class="right"><a href="<?php echo $set['home']; ?>/account/" class="new_button">Cancel</a></span></h2>
  		
        <table class="activate_form new_table">
            <tr>
  				<td class="label">Title:</td>
                <td class="field">
                     <input type="text" class="required input_title" name="title" required="required" value="<?php if (isset($title)) echo $title; ?>" placeholder="">
                     for 
                     <select class="required price_input" name="price">
                     <?php 
						foreach( allowed_prices($user['level']) as $single_price) {
							if (isset($price)) {
								if ($price == $single_price){
									$add_class = ' selected="selected"';
								} 
							} else {
								$add_class = '';	
							}
							echo "<option value='".$single_price."'".$add_class.">$".$single_price."</option>";
						} 
					?>
                     </select>
                     in
                     <select class="duration_input" name="duration">
                     	<option value="1">1 Day</option>
                        <?php for ($i = 2; $i<=10;$i++) {
							echo "<option value='".$i."'>".$i." Days</option>";
                         } ?>
                     </select>
                     <span class="inst">MIN 20 Characters / MAX 80 characters.</span>
                </td>
  			</tr>
            <tr>
  				<td class="label">Category:</td>
                <td class="field">
                     <select class="half_select choose_cat" name="category">
                     	<option value="0">Select A Category</option>
                     <?php 
					  if (isset($category)) {
							if ($category != 0)	$selected = $category;
					  } else {
							$selected  = " ";  
					  }
					  
					 	$cat_query = mysql_query("SELECT `id`,`name` FROM `categories` WHERE `parent` = 0 ORDER BY `position` ASC"); 
						while ($cat_row = mysql_fetch_array($cat_query)) {
							if ($selected == $cat_row['id']) {
								$add_selected = ' selected="selected"';
								if ($cat_row['id'] != 5) $show_child_cat = $selected;
									
							} else {
								$add_selected = '';
							}	
							echo "<option value='".$cat_row['id']."'".$add_selected.">".$cat_row['name']."</option> \n";
						}?>
                     </select> 
                     <span class="loading">Loading...</span>
                     <span class="sub_cat_wrap">
                     	<?php if (isset($show_child_cat)) {
							$query = mysql_query("SELECT `id`,`name` FROM `categories` WHERE `parent` = " . $show_child_cat);
							$output ='<select class="half_select required" name="sub_category">';
							$output .= '<option value="0">Select a Sub Category</option>';
								while ($sub_cat_row = mysql_fetch_array($query)) {
								
								if ($sub_category != 0 && $sub_category == $sub_cat_row['id']) {
									$add_selected = ' selected="selected"';
								} else {
									$add_selected = '';	
								}
								
								$output .= '<option value="'.$sub_cat_row['id'].'"'.$add_selected.'>'.$sub_cat_row['name'].'</option>';
								}
							$output .= '</select>';
							echo $output;
							 } ?>
                     </span>
                     <span class="inst">Please chose the category best suuitable for your service.</span>
                </td>
  			</tr>
            <tr>
  				<td class="label">Add Image:</td>
                <td class="field">
                     <input type="file" class="image" required="required" name="image" />
                     <span class="inst">Upload 640x400 Image size image to your service.</span>
                </td>
  			</tr>
            <tr>
  				<td class="label">Description:</td>
                <td class="field">
                     <textarea cols="20" rows="4" required="required" name="description"><?php if (isset($description)) echo $description; ?></textarea>
                     <span class="inst">Describe what you are offering. Explain in more detail what exactly you will deliver to the buyer.</span>
                </td>
  			</tr>
            <tr>
  				<td class="label">Tags:</td>
                <td class="field">
                     <input type="text" name="tags" required="required" value="<?php if (isset($tags)) echo $tags; ?>">
                     <span class="inst">Minimum three tags separated with commas</span>
                </td>
  			</tr>
            
            <tr>
  				<td class="label">Instructions <br> for buyer:</td>
                <td class="field">
                     <textarea cols="20" rows="2" required="required" name="instructions"><?php if (isset($instructions)) echo $instructions; ?></textarea>
                     <span class="inst">What do you need from buyer to start working?</span>
                </td>
  			</tr>
  		</table>
         <div class="clear"></div>
        
    </div><!-- .box -->
  
  	<div class="box">
    	<h2>Add Extras to your service</h2>
    	<table class="activate_form new_table">
        
        	<tr>
  				<td class="label">
                	<input type="hidden" name="extra_fast_ticked" value="0" checked="checked" />
                	<input type="checkbox" name="extra_fast_ticked" value="1" />
                </td>
                <td class="field">
                     I'll deliver this order extra fast, for 
                     <select class="required price_input" name="extra_fast_price">
                     <?php 
						foreach( allowed_prices($user['level']) as $single_price) {
							if (isset($price)) {
								if ($price == $single_price){
									$add_class = ' selected="selected"';
								} 
							} else {
									$add_class = '';	
								}
							echo "<option value='".$single_price."'".$add_class.">$".$single_price."</option>";
						} 
					?>
                     </select>
                     in
                     <select class="duration_input" name="extra_fast_duration">
                     	<option value="0">No Additional Time</option>
                        <?php for ($i = 1; $i<=10;$i++) {
							echo "<option value='".$i."'>".$i." Days</option>";
                         } ?>
                     </select>
                </td>
  			</tr>
        	<?php for ($a=1;$a<=3;$a++) { ?>
            <tr>
  				<td class="label">
                	<input type="hidden" name="extra_<?php echo $a; ?>_ticked" value="0" checked="checked" />
                	<input type="checkbox" name="extra_<?php echo $a; ?>_ticked" value="1" />
                </td>
                <td class="field">
                		<?php 
							$if_extra_title = ''; 
							if ($a == 1 && isset($extra_1_title)) $if_extra_title = $extra_1_title;
							if ($a == 2 && isset($extra_2_title)) $if_extra_title = $extra_2_title;
							if ($a == 3 && isset($extra_2_title)) $if_extra_title = $extra_3_title;
							if ($a == 4 && isset($extra_2_title)) $if_extra_title = $extra_4_title;
						?>
                     <input type="text" class="required input_title" name="extra_<?php echo $a; ?>_title" value="<?php if (isset($if_extra_title)) echo $if_extra_title; ?>" placeholder="">
                     for 
                     <select class="required price_input" name="extra_<?php echo $a; ?>_price">
                     <?php 
						foreach( allowed_prices($user['level']) as $single_price) {
							if (isset($price)) {
								if ($price == $single_price){
									$add_class = ' selected="selected"';
								} else {
									$add_class = '';	
								}
							} 
							echo "<option value='".$single_price."'".$add_class.">$".$single_price."</option>";
						} 
					?>
                     </select>
                     in
                     <select class="duration_input" name="extra_<?php echo $a; ?>_duration">
                     	<option value="0">No Additional Time</option>
                        <?php for ($i = 1; $i<=10;$i++) {
							echo "<option value='".$i."'>".$i." Days</option>";
                         } ?>
                     </select>
                </td>
  			</tr>
            <?php } ?>
            </table>
    </div><!-- .box -->
  	

    	<table class="activate_form new_table">
        	<tr>
  				<td class="submit_row" colspan="2"><input type="submit" name="new_submit" value="Post Service" /></td>
  			</tr>
        </table>

            </form> 
</div><!-- .side_content -->

<?php include('includes/sidebars/sidebar-account.php'); ?> 
<?php include('footer.php');  ?>    